const { sorguCalistir } = require('../db');

async function bildirimEkle(aliciId, yapanId, tur, postId = null, projeId = null) {
  if (aliciId === yapanId) return;

  await sorguCalistir(
    `INSERT INTO dbo.notifications (user_id, actor_id, type, post_id, project_id)
     VALUES (@aliciId, @yapanId, @tur, @postId, @projeId)`,
    { aliciId, yapanId, tur, postId, projeId }
  );
}

module.exports = { bildirimEkle };
