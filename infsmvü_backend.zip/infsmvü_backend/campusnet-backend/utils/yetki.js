const { sorguCalistir } = require('../db');

async function kulupYoneticisiMi(clubId, userId) {
  const sonuc = await sorguCalistir(
    'SELECT 1 AS var FROM dbo.club_members WHERE club_id = @clubId AND user_id = @userId AND is_admin = 1',
    { clubId, userId }
  );
  return sonuc.length > 0;
}

async function projeUyesiMi(projectId, userId) {
  const sonuc = await sorguCalistir(
    'SELECT 1 AS var FROM dbo.project_members WHERE project_id = @projectId AND user_id = @userId',
    { projectId, userId }
  );
  return sonuc.length > 0;
}

module.exports = { kulupYoneticisiMi, projeUyesiMi };
