function sayiOlmali(req, res, next, deger, ad) {
  if (!/^\d{1,9}$/.test(deger)) {
    return res.status(400).json({ mesaj: ad + ' geçerli bir sayı olmalı.' });
  }
  next();
}

module.exports = { sayiOlmali };
