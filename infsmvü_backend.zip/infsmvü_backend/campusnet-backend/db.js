const sql = require('mssql');
require('dotenv').config();

const sunucu = process.env.DB_SERVER || 'localhost';

const ayarlar = {
  server: sunucu,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  options: {
    encrypt: false,
    trustServerCertificate: true
  }
};

if (!sunucu.includes('\\')) {
  ayarlar.port = Number(process.env.DB_PORT) || 1433;
}

const havuz = new sql.ConnectionPool(ayarlar).connect();

havuz.catch((hata) => {
  console.error('Veritabanına bağlanılamadı:', hata.message);
});

async function sorguCalistir(sorgu, parametreler = {}) {
  const baglanti = await havuz;
  const istek = baglanti.request();

  for (const ad in parametreler) {
    const deger = parametreler[ad] === undefined ? null : parametreler[ad];
    istek.input(ad, deger);
  }

  const sonuc = await istek.query(sorgu);
  return sonuc.recordset || [];
}

module.exports = { sorguCalistir };
