const express = require('express');
const { sorguCalistir } = require('../db');
const { girisGerekli } = require('../middleware/auth');

const { sayiOlmali } = require('../utils/parametre');

const router = express.Router();
router.use(girisGerekli);
router.param('id', sayiOlmali);

router.get('/', async (req, res) => {
  const sadeceOkunmamis = req.query.unread === '1' ? 1 : 0;

  const liste = await sorguCalistir(
    `SELECT TOP 50 n.notification_id, n.type, n.post_id, n.project_id, n.is_read, n.created_at,
            a.user_id AS actor_id, a.first_name AS actor_first_name, a.last_name AS actor_last_name
     FROM dbo.notifications n
     LEFT JOIN dbo.users a ON a.user_id = n.actor_id
     WHERE n.user_id = @me AND (@sadeceOkunmamis = 0 OR n.is_read = 0)
     ORDER BY n.created_at DESC`,
    { me: req.kullanici.user_id, sadeceOkunmamis }
  );
  res.json(liste);
});

router.get('/unread-count', async (req, res) => {
  const sonuc = await sorguCalistir(
    'SELECT COUNT(*) AS adet FROM dbo.notifications WHERE user_id = @me AND is_read = 0',
    { me: req.kullanici.user_id }
  );
  res.json({ adet: sonuc[0].adet });
});

router.put('/read-all', async (req, res) => {
  await sorguCalistir(
    'UPDATE dbo.notifications SET is_read = 1 WHERE user_id = @me AND is_read = 0',
    { me: req.kullanici.user_id }
  );
  res.json({ mesaj: 'Tüm bildirimler okundu.' });
});

router.put('/:id/read', async (req, res) => {
  await sorguCalistir(
    'UPDATE dbo.notifications SET is_read = 1 WHERE notification_id = @id AND user_id = @me',
    { id: Number(req.params.id), me: req.kullanici.user_id }
  );
  res.json({ mesaj: 'Bildirim okundu.' });
});

module.exports = router;
