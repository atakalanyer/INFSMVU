const express = require('express');
const { sorguCalistir } = require('../db');
const { girisGerekli } = require('../middleware/auth');
const { kulupYoneticisiMi } = require('../utils/yetki');

const { sayiOlmali } = require('../utils/parametre');

const router = express.Router();
router.use(girisGerekli);
router.param('id', sayiOlmali);

router.get('/', async (req, res) => {
  const clubId = req.query.club_id ? Number(req.query.club_id) : null;

  const etkinlikler = await sorguCalistir(
    `SELECT e.event_id, e.title, e.location, e.starts_at, e.ends_at,
            c.club_id, c.name AS club_name,
            (SELECT COUNT(*) FROM dbo.event_attendees a WHERE a.event_id = e.event_id) AS attendee_count
     FROM dbo.events e
     JOIN dbo.clubs c ON c.club_id = e.club_id
     WHERE e.starts_at >= SYSDATETIME()
       AND (@clubId IS NULL OR e.club_id = @clubId)
     ORDER BY e.starts_at`,
    { clubId }
  );
  res.json(etkinlikler);
});

router.get('/:id', async (req, res) => {
  const id = Number(req.params.id);

  const etkinlik = await sorguCalistir(
    `SELECT e.event_id, e.title, e.description, e.location, e.starts_at, e.ends_at,
            c.club_id, c.name AS club_name,
            (SELECT COUNT(*) FROM dbo.event_attendees a WHERE a.event_id = e.event_id) AS attendee_count,
            (SELECT COUNT(*) FROM dbo.event_attendees a WHERE a.event_id = e.event_id AND a.user_id = @me) AS is_registered
     FROM dbo.events e
     JOIN dbo.clubs c ON c.club_id = e.club_id
     WHERE e.event_id = @id`,
    { id, me: req.kullanici.user_id }
  );

  if (etkinlik.length === 0) {
    return res.status(404).json({ mesaj: 'Etkinlik bulunamadı.' });
  }

  res.json(etkinlik[0]);
});

router.post('/', async (req, res) => {
  const { club_id, title, description, location, starts_at, ends_at } = req.body;
  const userId = req.kullanici.user_id;

  if (!club_id || !title || !starts_at) {
    return res.status(400).json({ mesaj: 'club_id, title ve starts_at zorunlu.' });
  }

  if (isNaN(new Date(starts_at)) || (ends_at && isNaN(new Date(ends_at)))) {
    return res.status(400).json({ mesaj: 'Tarih formatı hatalı.' });
  }

  if (ends_at && new Date(ends_at) < new Date(starts_at)) {
    return res.status(400).json({ mesaj: 'Bitiş tarihi başlangıçtan önce olamaz.' });
  }

  const yonetici = await kulupYoneticisiMi(club_id, userId);
  if (!yonetici && req.kullanici.role !== 'admin') {
    return res.status(403).json({ mesaj: 'Sadece kulüp yöneticisi etkinlik oluşturabilir.' });
  }

  const eklenen = await sorguCalistir(
    `INSERT INTO dbo.events (club_id, created_by, title, description, location, starts_at, ends_at)
     OUTPUT INSERTED.event_id
     VALUES (@club_id, @userId, @title, @description, @location, @starts_at, @ends_at)`,
    { club_id, userId, title, description, location, starts_at, ends_at }
  );

  res.status(201).json({ mesaj: 'Etkinlik oluşturuldu.', event_id: eklenen[0].event_id });
});

router.delete('/:id', async (req, res) => {
  const id = Number(req.params.id);

  const etkinlik = await sorguCalistir('SELECT club_id FROM dbo.events WHERE event_id = @id', { id });
  if (etkinlik.length === 0) {
    return res.status(404).json({ mesaj: 'Etkinlik bulunamadı.' });
  }

  const yonetici = await kulupYoneticisiMi(etkinlik[0].club_id, req.kullanici.user_id);
  if (!yonetici && req.kullanici.role !== 'admin') {
    return res.status(403).json({ mesaj: 'Yetkiniz yok.' });
  }

  await sorguCalistir('DELETE FROM dbo.events WHERE event_id = @id', { id });
  res.json({ mesaj: 'Etkinlik silindi.' });
});

router.post('/:id/register', async (req, res) => {
  const eventId = Number(req.params.id);
  const userId = req.kullanici.user_id;

  const etkinlik = await sorguCalistir('SELECT event_id FROM dbo.events WHERE event_id = @eventId', { eventId });
  if (etkinlik.length === 0) {
    return res.status(404).json({ mesaj: 'Etkinlik bulunamadı.' });
  }

  const mevcut = await sorguCalistir(
    'SELECT 1 AS var FROM dbo.event_attendees WHERE event_id = @eventId AND user_id = @userId',
    { eventId, userId }
  );
  if (mevcut.length > 0) {
    return res.status(409).json({ mesaj: 'Zaten kayıtlısınız.' });
  }

  await sorguCalistir(
    'INSERT INTO dbo.event_attendees (event_id, user_id) VALUES (@eventId, @userId)',
    { eventId, userId }
  );

  res.status(201).json({ mesaj: 'Etkinliğe kayıt oldunuz.' });
});

router.delete('/:id/register', async (req, res) => {
  await sorguCalistir(
    'DELETE FROM dbo.event_attendees WHERE event_id = @eventId AND user_id = @userId',
    { eventId: Number(req.params.id), userId: req.kullanici.user_id }
  );
  res.json({ mesaj: 'Kaydınız iptal edildi.' });
});

router.get('/:id/attendees', async (req, res) => {
  const liste = await sorguCalistir(
    `SELECT u.user_id, u.first_name, u.last_name, a.registered_at
     FROM dbo.event_attendees a
     JOIN dbo.users u ON u.user_id = a.user_id
     WHERE a.event_id = @id
     ORDER BY a.registered_at`,
    { id: Number(req.params.id) }
  );
  res.json(liste);
});

module.exports = router;
