const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { sorguCalistir } = require('../db');

const router = express.Router();

router.post('/register', async (req, res) => {
  const { password, first_name, last_name, student_no, department_id, degree, class_year } = req.body;
  const email = (req.body.email || '').trim().toLowerCase();
  const role = req.body.role || 'student';

  if (!email || !password || !first_name || !last_name) {
    return res.status(400).json({ mesaj: 'E-posta, şifre, ad ve soyad zorunludur.' });
  }

  if (typeof password !== 'string' || password.length < 6) {
    return res.status(400).json({ mesaj: 'Şifre en az 6 karakter olmalı.' });
  }

  if (!['student', 'academic', 'alumni'].includes(role)) {
    return res.status(400).json({ mesaj: 'Geçersiz rol.' });
  }

  if ((role === 'student' || role === 'alumni') && !email.endsWith('@stu.fsm.edu.tr')) {
    return res.status(400).json({ mesaj: 'Öğrenci ve mezunlar @stu.fsm.edu.tr uzantılı e-posta kullanmalı.' });
  }

  const mevcut = await sorguCalistir('SELECT user_id FROM dbo.users WHERE email = @email', { email });
  if (mevcut.length > 0) {
    return res.status(409).json({ mesaj: 'Bu e-posta zaten kayıtlı.' });
  }

  const sifreHash = await bcrypt.hash(password, 10);

  const eklenen = await sorguCalistir(
    `INSERT INTO dbo.users (student_no, email, password_hash, first_name, last_name, role, department_id, degree, class_year)
     OUTPUT INSERTED.user_id
     VALUES (@student_no, @email, @sifreHash, @first_name, @last_name, @role, @department_id, @degree, @class_year)`,
    {
      student_no: student_no || null,
      email,
      sifreHash,
      first_name,
      last_name,
      role,
      department_id: department_id || null,
      degree: degree || null,
      class_year: class_year || null
    }
  );

  const userId = eklenen[0].user_id;
  const token = crypto.randomBytes(20).toString('hex');

  await sorguCalistir('INSERT INTO dbo.profiles (user_id) VALUES (@userId)', { userId });

  await sorguCalistir(
    `INSERT INTO dbo.email_verifications (user_id, token, expires_at)
     VALUES (@userId, @token, DATEADD(HOUR, 24, SYSDATETIME()))`,
    { userId, token }
  );

  res.status(201).json({
    mesaj: 'Kayıt başarılı. E-posta doğrulaması gerekiyor.',
    user_id: userId,
    dogrulama_kodu: token
  });
});

router.get('/verify/:token', async (req, res) => {
  const token = req.params.token;

  const kayit = await sorguCalistir(
    `SELECT verification_id, user_id FROM dbo.email_verifications
     WHERE token = @token AND used_at IS NULL AND expires_at > SYSDATETIME()`,
    { token }
  );

  if (kayit.length === 0) {
    return res.status(400).json({ mesaj: 'Kod geçersiz veya süresi dolmuş.' });
  }

  await sorguCalistir('UPDATE dbo.users SET is_email_verified = 1 WHERE user_id = @userId', { userId: kayit[0].user_id });
  await sorguCalistir('UPDATE dbo.email_verifications SET used_at = SYSDATETIME() WHERE verification_id = @id', { id: kayit[0].verification_id });

  res.json({ mesaj: 'E-posta doğrulandı, giriş yapabilirsiniz.' });
});

router.post('/login', async (req, res) => {
  const email = (req.body.email || '').trim().toLowerCase();
  const password = req.body.password;

  if (!email || !password) {
    return res.status(400).json({ mesaj: 'E-posta ve şifre zorunludur.' });
  }

  const sonuc = await sorguCalistir('SELECT * FROM dbo.users WHERE email = @email', { email });
  const kullanici = sonuc[0];

  if (!kullanici) {
    return res.status(401).json({ mesaj: 'E-posta veya şifre hatalı.' });
  }

  const sifreDogru = await bcrypt.compare(password, kullanici.password_hash);
  if (!sifreDogru) {
    return res.status(401).json({ mesaj: 'E-posta veya şifre hatalı.' });
  }

  if (!kullanici.is_active) {
    return res.status(403).json({ mesaj: 'Hesabınız pasif durumda.' });
  }

  if (!kullanici.is_email_verified) {
    return res.status(403).json({ mesaj: 'Önce e-postanızı doğrulayın.' });
  }

  await sorguCalistir('UPDATE dbo.users SET last_login_at = SYSDATETIME() WHERE user_id = @id', { id: kullanici.user_id });

  const token = jwt.sign(
    { user_id: kullanici.user_id, role: kullanici.role },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );

  res.json({
    token,
    kullanici: {
      user_id: kullanici.user_id,
      first_name: kullanici.first_name,
      last_name: kullanici.last_name,
      email: kullanici.email,
      role: kullanici.role
    }
  });
});

module.exports = router;
