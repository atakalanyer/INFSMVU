const express = require('express');
const { sorguCalistir } = require('../db');
const { girisGerekli } = require('../middleware/auth');
const { bildirimEkle } = require('../utils/notify');
const { kulupYoneticisiMi, projeUyesiMi } = require('../utils/yetki');

const { sayiOlmali } = require('../utils/parametre');

const router = express.Router();
router.use(girisGerekli);
router.param('id', sayiOlmali);
router.param('commentId', sayiOlmali);

const postTurleri = ['project', 'announcement', 'event', 'general'];
const medyaTurleri = ['image', 'video', 'document', 'link'];

async function postGetir(id) {
  const sonuc = await sorguCalistir(
    'SELECT post_id, author_id FROM dbo.posts WHERE post_id = @id AND is_deleted = 0',
    { id }
  );
  return sonuc[0];
}

router.get('/', async (req, res) => {
  const sayfa = Math.max(Math.floor(Number(req.query.page)) || 1, 1);
  const limit = Math.min(Math.floor(Number(req.query.limit)) || 10, 50);
  const atla = (sayfa - 1) * limit;
  const type = req.query.type || null;

  const gonderiler = await sorguCalistir(
    `SELECT p.post_id, p.type, p.content, p.club_id, p.project_id, p.created_at,
            u.user_id AS author_id, u.first_name, u.last_name,
            (SELECT COUNT(*) FROM dbo.post_likes l WHERE l.post_id = p.post_id) AS like_count,
            (SELECT COUNT(*) FROM dbo.comments c WHERE c.post_id = p.post_id) AS comment_count,
            (SELECT COUNT(*) FROM dbo.post_likes l WHERE l.post_id = p.post_id AND l.user_id = @me) AS liked_by_me,
            (SELECT TOP 1 m.url FROM dbo.post_media m WHERE m.post_id = p.post_id ORDER BY m.sort_order) AS first_media_url
     FROM dbo.posts p
     JOIN dbo.users u ON u.user_id = p.author_id
     WHERE p.is_deleted = 0
       AND (@type IS NULL OR p.type = @type)
     ORDER BY p.created_at DESC
     OFFSET @atla ROWS FETCH NEXT @limit ROWS ONLY`,
    { me: req.kullanici.user_id, type, atla, limit }
  );
  res.json(gonderiler);
});

router.post('/', async (req, res) => {
  const { content, club_id, project_id, media } = req.body;
  const type = req.body.type || 'general';
  const userId = req.kullanici.user_id;

  if (!postTurleri.includes(type)) {
    return res.status(400).json({ mesaj: 'Geçersiz gönderi türü.' });
  }

  const medyaVar = Array.isArray(media) && media.length > 0;
  if (!content && !medyaVar) {
    return res.status(400).json({ mesaj: 'İçerik veya medya gerekli.' });
  }

  if (club_id) {
    const yonetici = await kulupYoneticisiMi(club_id, userId);
    if (!yonetici && req.kullanici.role !== 'admin') {
      return res.status(403).json({ mesaj: 'Kulüp adına sadece yönetici paylaşım yapabilir.' });
    }
  }

  if (project_id) {
    const uye = await projeUyesiMi(project_id, userId);
    if (!uye) {
      return res.status(403).json({ mesaj: 'Sadece proje üyeleri proje paylaşımı yapabilir.' });
    }
  }

  const eklenen = await sorguCalistir(
    `INSERT INTO dbo.posts (author_id, club_id, project_id, type, content)
     OUTPUT INSERTED.post_id
     VALUES (@userId, @club_id, @project_id, @type, @content)`,
    { userId, club_id, project_id, type, content }
  );

  const postId = eklenen[0].post_id;

  if (medyaVar) {
    for (let i = 0; i < media.length; i++) {
      const medyaTuru = media[i].type || 'image';

      if (!medyaTurleri.includes(medyaTuru) || !media[i].url) continue;

      await sorguCalistir(
        `INSERT INTO dbo.post_media (post_id, type, url, sort_order)
         VALUES (@postId, @medyaTuru, @url, @sira)`,
        { postId, medyaTuru, url: media[i].url, sira: i }
      );
    }
  }

  res.status(201).json({ mesaj: 'Gönderi paylaşıldı.', post_id: postId });
});

router.delete('/comments/:commentId', async (req, res) => {
  const commentId = Number(req.params.commentId);

  const yorum = await sorguCalistir('SELECT user_id FROM dbo.comments WHERE comment_id = @commentId', { commentId });
  if (yorum.length === 0) {
    return res.status(404).json({ mesaj: 'Yorum bulunamadı.' });
  }

  if (yorum[0].user_id !== req.kullanici.user_id && req.kullanici.role !== 'admin') {
    return res.status(403).json({ mesaj: 'Yetkiniz yok.' });
  }

  await sorguCalistir('DELETE FROM dbo.comments WHERE parent_comment_id = @commentId', { commentId });
  await sorguCalistir('DELETE FROM dbo.comments WHERE comment_id = @commentId', { commentId });

  res.json({ mesaj: 'Yorum silindi.' });
});

router.get('/:id', async (req, res) => {
  const id = Number(req.params.id);

  const gonderi = await sorguCalistir(
    `SELECT p.post_id, p.type, p.content, p.club_id, p.project_id, p.created_at,
            u.user_id AS author_id, u.first_name, u.last_name,
            (SELECT COUNT(*) FROM dbo.post_likes l WHERE l.post_id = p.post_id) AS like_count,
            (SELECT COUNT(*) FROM dbo.post_likes l WHERE l.post_id = p.post_id AND l.user_id = @me) AS liked_by_me
     FROM dbo.posts p
     JOIN dbo.users u ON u.user_id = p.author_id
     WHERE p.post_id = @id AND p.is_deleted = 0`,
    { id, me: req.kullanici.user_id }
  );

  if (gonderi.length === 0) {
    return res.status(404).json({ mesaj: 'Gönderi bulunamadı.' });
  }

  const medya = await sorguCalistir(
    'SELECT media_id, type, url FROM dbo.post_media WHERE post_id = @id ORDER BY sort_order',
    { id }
  );

  res.json({ ...gonderi[0], media: medya });
});

router.delete('/:id', async (req, res) => {
  const id = Number(req.params.id);
  const gonderi = await postGetir(id);

  if (!gonderi) {
    return res.status(404).json({ mesaj: 'Gönderi bulunamadı.' });
  }

  if (gonderi.author_id !== req.kullanici.user_id && req.kullanici.role !== 'admin') {
    return res.status(403).json({ mesaj: 'Sadece gönderi sahibi silebilir.' });
  }

  await sorguCalistir('UPDATE dbo.posts SET is_deleted = 1 WHERE post_id = @id', { id });
  res.json({ mesaj: 'Gönderi silindi.' });
});

router.post('/:id/like', async (req, res) => {
  const postId = Number(req.params.id);
  const userId = req.kullanici.user_id;

  const gonderi = await postGetir(postId);
  if (!gonderi) {
    return res.status(404).json({ mesaj: 'Gönderi bulunamadı.' });
  }

  const mevcut = await sorguCalistir(
    'SELECT 1 AS var FROM dbo.post_likes WHERE post_id = @postId AND user_id = @userId',
    { postId, userId }
  );
  if (mevcut.length > 0) {
    return res.status(409).json({ mesaj: 'Zaten beğendiniz.' });
  }

  await sorguCalistir(
    'INSERT INTO dbo.post_likes (post_id, user_id) VALUES (@postId, @userId)',
    { postId, userId }
  );

  await bildirimEkle(gonderi.author_id, userId, 'like', postId);
  res.status(201).json({ mesaj: 'Beğenildi.' });
});

router.delete('/:id/like', async (req, res) => {
  await sorguCalistir(
    'DELETE FROM dbo.post_likes WHERE post_id = @postId AND user_id = @userId',
    { postId: Number(req.params.id), userId: req.kullanici.user_id }
  );
  res.json({ mesaj: 'Beğeni kaldırıldı.' });
});

router.get('/:id/comments', async (req, res) => {
  const yorumlar = await sorguCalistir(
    `SELECT c.comment_id, c.parent_comment_id, c.content, c.created_at,
            u.user_id, u.first_name, u.last_name
     FROM dbo.comments c
     JOIN dbo.users u ON u.user_id = c.user_id
     WHERE c.post_id = @postId
     ORDER BY c.created_at`,
    { postId: Number(req.params.id) }
  );
  res.json(yorumlar);
});

router.post('/:id/comments', async (req, res) => {
  const postId = Number(req.params.id);
  const userId = req.kullanici.user_id;
  const { content, parent_comment_id } = req.body;

  if (!content || !content.trim()) {
    return res.status(400).json({ mesaj: 'Yorum boş olamaz.' });
  }

  const gonderi = await postGetir(postId);
  if (!gonderi) {
    return res.status(404).json({ mesaj: 'Gönderi bulunamadı.' });
  }

  let ustYorumId = null;

  if (parent_comment_id) {
    const ust = await sorguCalistir(
      'SELECT comment_id, parent_comment_id FROM dbo.comments WHERE comment_id = @id AND post_id = @postId',
      { id: parent_comment_id, postId }
    );

    if (ust.length === 0) {
      return res.status(404).json({ mesaj: 'Yanıtlanan yorum bulunamadı.' });
    }

    ustYorumId = ust[0].parent_comment_id || ust[0].comment_id;
  }

  const eklenen = await sorguCalistir(
    `INSERT INTO dbo.comments (post_id, user_id, parent_comment_id, content)
     OUTPUT INSERTED.comment_id
     VALUES (@postId, @userId, @ustYorumId, @content)`,
    { postId, userId, ustYorumId, content: content.trim() }
  );

  await bildirimEkle(gonderi.author_id, userId, 'comment', postId);
  res.status(201).json({ mesaj: 'Yorum eklendi.', comment_id: eklenen[0].comment_id });
});

module.exports = router;
