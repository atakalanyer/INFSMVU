const express = require('express');
const { sorguCalistir } = require('../db');
const { girisGerekli } = require('../middleware/auth');
const { bildirimEkle } = require('../utils/notify');

const { sayiOlmali } = require('../utils/parametre');

const router = express.Router();
router.use(girisGerekli);
router.param('id', sayiOlmali);
router.param('appId', sayiOlmali);
router.param('skillId', sayiOlmali);
router.param('userId', sayiOlmali);

const durumlar = ['open', 'in_progress', 'completed', 'closed'];

async function projeGetir(id) {
  const sonuc = await sorguCalistir('SELECT * FROM dbo.projects WHERE project_id = @id', { id });
  return sonuc[0];
}

router.get('/', async (req, res) => {
  const status = req.query.status || null;
  const category = req.query.category || null;
  const q = req.query.q ? '%' + req.query.q + '%' : null;

  const projeler = await sorguCalistir(
    `SELECT p.project_id, p.title, p.category, p.status, p.max_members, p.created_at,
            u.first_name + ' ' + u.last_name AS owner_name,
            (SELECT COUNT(*) FROM dbo.project_members pm WHERE pm.project_id = p.project_id) AS member_count
     FROM dbo.projects p
     JOIN dbo.users u ON u.user_id = p.owner_id
     WHERE (@status IS NULL OR p.status = @status)
       AND (@category IS NULL OR p.category = @category)
       AND (@q IS NULL OR p.title LIKE @q)
     ORDER BY p.created_at DESC`,
    { status, category, q }
  );
  res.json(projeler);
});

router.post('/', async (req, res) => {
  const { title, description, category, repo_url, skills } = req.body;
  const max_members = req.body.max_members || 5;
  const ownerId = req.kullanici.user_id;

  if (!title) {
    return res.status(400).json({ mesaj: 'Proje başlığı zorunlu.' });
  }

  const gelenYetenekler = Array.isArray(skills) ? skills : [];
  const temizListe = [];

  for (const yetenek of gelenYetenekler) {
    const skillId = Number(yetenek.skill_id);
    const minLevel = Number(yetenek.min_level) || 1;
    const tekrarVar = temizListe.some((x) => x.skillId === skillId);

    if (!Number.isInteger(skillId) || tekrarVar || minLevel < 1 || minLevel > 4) {
      return res.status(400).json({ mesaj: 'Gerekli yetenek listesi hatalı.' });
    }

    const kayit = await sorguCalistir('SELECT skill_id FROM dbo.skills WHERE skill_id = @skillId', { skillId });
    if (kayit.length === 0) {
      return res.status(404).json({ mesaj: 'Yetenek bulunamadı: ' + skillId });
    }

    temizListe.push({ skillId, minLevel });
  }

  const eklenen = await sorguCalistir(
    `INSERT INTO dbo.projects (owner_id, title, description, category, repo_url, max_members)
     OUTPUT INSERTED.project_id
     VALUES (@ownerId, @title, @description, @category, @repo_url, @max_members)`,
    { ownerId, title, description, category, repo_url, max_members }
  );

  const projectId = eklenen[0].project_id;

  await sorguCalistir(
    "INSERT INTO dbo.project_members (project_id, user_id, role) VALUES (@projectId, @ownerId, 'owner')",
    { projectId, ownerId }
  );

  for (const yetenek of temizListe) {
    await sorguCalistir(
      `INSERT INTO dbo.project_required_skills (project_id, skill_id, min_level)
       VALUES (@projectId, @skillId, @minLevel)`,
      { projectId, skillId: yetenek.skillId, minLevel: yetenek.minLevel }
    );
  }

  res.status(201).json({ mesaj: 'Proje oluşturuldu.', project_id: projectId });
});

router.put('/applications/:appId', async (req, res) => {
  const appId = Number(req.params.appId);
  const durum = req.body.status;

  if (!['accepted', 'rejected'].includes(durum)) {
    return res.status(400).json({ mesaj: "status 'accepted' veya 'rejected' olmalı." });
  }

  const sonuc = await sorguCalistir(
    `SELECT a.application_id, a.project_id, a.applicant_id, a.status, p.owner_id, p.max_members
     FROM dbo.project_applications a
     JOIN dbo.projects p ON p.project_id = a.project_id
     WHERE a.application_id = @appId`,
    { appId }
  );
  const basvuru = sonuc[0];

  if (!basvuru) {
    return res.status(404).json({ mesaj: 'Başvuru bulunamadı.' });
  }

  if (basvuru.owner_id !== req.kullanici.user_id) {
    return res.status(403).json({ mesaj: 'Sadece proje sahibi karar verebilir.' });
  }

  if (basvuru.status !== 'pending') {
    return res.status(400).json({ mesaj: 'Bu başvuru zaten sonuçlanmış.' });
  }

  if (durum === 'accepted') {
    const sayi = await sorguCalistir(
      'SELECT COUNT(*) AS adet FROM dbo.project_members WHERE project_id = @projectId',
      { projectId: basvuru.project_id }
    );

    if (sayi[0].adet >= basvuru.max_members) {
      return res.status(400).json({ mesaj: 'Takım dolu.' });
    }

    await sorguCalistir(
      "INSERT INTO dbo.project_members (project_id, user_id, role) VALUES (@projectId, @userId, 'member')",
      { projectId: basvuru.project_id, userId: basvuru.applicant_id }
    );
  }

  await sorguCalistir(
    'UPDATE dbo.project_applications SET status = @durum WHERE application_id = @appId',
    { durum, appId }
  );

  await bildirimEkle(basvuru.applicant_id, req.kullanici.user_id, 'application', null, basvuru.project_id);

  res.json({ mesaj: 'Başvuru güncellendi.' });
});

router.get('/:id', async (req, res) => {
  const id = Number(req.params.id);

  const proje = await sorguCalistir(
    `SELECT p.*, u.first_name + ' ' + u.last_name AS owner_name
     FROM dbo.projects p
     JOIN dbo.users u ON u.user_id = p.owner_id
     WHERE p.project_id = @id`,
    { id }
  );

  if (proje.length === 0) {
    return res.status(404).json({ mesaj: 'Proje bulunamadı.' });
  }

  const yetenekler = await sorguCalistir(
    `SELECT s.skill_id, s.name, r.min_level
     FROM dbo.project_required_skills r
     JOIN dbo.skills s ON s.skill_id = r.skill_id
     WHERE r.project_id = @id`,
    { id }
  );

  const uyeler = await sorguCalistir(
    `SELECT u.user_id, u.first_name, u.last_name, m.role
     FROM dbo.project_members m
     JOIN dbo.users u ON u.user_id = m.user_id
     WHERE m.project_id = @id`,
    { id }
  );

  res.json({ ...proje[0], required_skills: yetenekler, members: uyeler });
});

router.put('/:id', async (req, res) => {
  const id = Number(req.params.id);
  const proje = await projeGetir(id);

  if (!proje) {
    return res.status(404).json({ mesaj: 'Proje bulunamadı.' });
  }

  if (proje.owner_id !== req.kullanici.user_id && req.kullanici.role !== 'admin') {
    return res.status(403).json({ mesaj: 'Sadece proje sahibi düzenleyebilir.' });
  }

  const { title, description, category, status, repo_url, max_members } = req.body;

  if (status && !durumlar.includes(status)) {
    return res.status(400).json({ mesaj: 'Geçersiz durum.' });
  }

  await sorguCalistir(
    `UPDATE dbo.projects SET
       title = COALESCE(@title, title),
       description = COALESCE(@description, description),
       category = COALESCE(@category, category),
       status = COALESCE(@status, status),
       repo_url = COALESCE(@repo_url, repo_url),
       max_members = COALESCE(@max_members, max_members),
       updated_at = SYSDATETIME()
     WHERE project_id = @id`,
    { id, title, description, category, status, repo_url, max_members }
  );

  res.json({ mesaj: 'Proje güncellendi.' });
});

router.delete('/:id', async (req, res) => {
  const id = Number(req.params.id);
  const proje = await projeGetir(id);

  if (!proje) {
    return res.status(404).json({ mesaj: 'Proje bulunamadı.' });
  }

  if (proje.owner_id !== req.kullanici.user_id && req.kullanici.role !== 'admin') {
    return res.status(403).json({ mesaj: 'Sadece proje sahibi silebilir.' });
  }

  await sorguCalistir('DELETE FROM dbo.notifications WHERE project_id = @id', { id });
  await sorguCalistir('UPDATE dbo.posts SET project_id = NULL WHERE project_id = @id', { id });
  await sorguCalistir('DELETE FROM dbo.project_members WHERE project_id = @id', { id });
  await sorguCalistir('DELETE FROM dbo.project_applications WHERE project_id = @id', { id });
  await sorguCalistir('DELETE FROM dbo.projects WHERE project_id = @id', { id });

  res.json({ mesaj: 'Proje silindi.' });
});

router.post('/:id/skills', async (req, res) => {
  const projectId = Number(req.params.id);
  const skillId = Number(req.body.skill_id);
  const minLevel = Number(req.body.min_level) || 1;

  const proje = await projeGetir(projectId);
  if (!proje) {
    return res.status(404).json({ mesaj: 'Proje bulunamadı.' });
  }

  if (proje.owner_id !== req.kullanici.user_id) {
    return res.status(403).json({ mesaj: 'Sadece proje sahibi yetenek ekleyebilir.' });
  }

  if (!skillId || minLevel < 1 || minLevel > 4) {
    return res.status(400).json({ mesaj: 'skill_id ve 1-4 arası min_level gerekli.' });
  }

  await sorguCalistir(
    `UPDATE dbo.project_required_skills SET min_level = @minLevel
     WHERE project_id = @projectId AND skill_id = @skillId;
     IF @@ROWCOUNT = 0
       INSERT INTO dbo.project_required_skills (project_id, skill_id, min_level)
       VALUES (@projectId, @skillId, @minLevel);`,
    { projectId, skillId, minLevel }
  );

  res.json({ mesaj: 'Gerekli yetenek kaydedildi.' });
});

router.delete('/:id/skills/:skillId', async (req, res) => {
  const projectId = Number(req.params.id);
  const proje = await projeGetir(projectId);

  if (!proje) {
    return res.status(404).json({ mesaj: 'Proje bulunamadı.' });
  }

  if (proje.owner_id !== req.kullanici.user_id) {
    return res.status(403).json({ mesaj: 'Sadece proje sahibi silebilir.' });
  }

  await sorguCalistir(
    'DELETE FROM dbo.project_required_skills WHERE project_id = @projectId AND skill_id = @skillId',
    { projectId, skillId: Number(req.params.skillId) }
  );

  res.json({ mesaj: 'Gerekli yetenek silindi.' });
});

router.post('/:id/apply', async (req, res) => {
  const projectId = Number(req.params.id);
  const userId = req.kullanici.user_id;
  const mesaj = req.body.message;

  const proje = await projeGetir(projectId);
  if (!proje) {
    return res.status(404).json({ mesaj: 'Proje bulunamadı.' });
  }

  if (proje.status !== 'open') {
    return res.status(400).json({ mesaj: 'Bu proje başvuruya açık değil.' });
  }

  const uye = await sorguCalistir(
    'SELECT 1 AS var FROM dbo.project_members WHERE project_id = @projectId AND user_id = @userId',
    { projectId, userId }
  );
  if (uye.length > 0) {
    return res.status(400).json({ mesaj: 'Zaten bu projenin üyesisiniz.' });
  }

  const onceki = await sorguCalistir(
    'SELECT status FROM dbo.project_applications WHERE project_id = @projectId AND applicant_id = @userId',
    { projectId, userId }
  );

  if (onceki.length > 0) {
    if (onceki[0].status !== 'withdrawn') {
      return res.status(409).json({ mesaj: 'Bu projeye zaten başvurdunuz.' });
    }

    await sorguCalistir(
      `UPDATE dbo.project_applications SET status = 'pending', message = @mesaj, created_at = SYSDATETIME()
       WHERE project_id = @projectId AND applicant_id = @userId`,
      { projectId, userId, mesaj }
    );
  } else {
    await sorguCalistir(
      `INSERT INTO dbo.project_applications (project_id, applicant_id, message)
       VALUES (@projectId, @userId, @mesaj)`,
      { projectId, userId, mesaj }
    );
  }

  await bildirimEkle(proje.owner_id, userId, 'application', null, projectId);
  res.status(201).json({ mesaj: 'Başvurunuz gönderildi.' });
});

router.delete('/:id/apply', async (req, res) => {
  await sorguCalistir(
    `UPDATE dbo.project_applications SET status = 'withdrawn'
     WHERE project_id = @projectId AND applicant_id = @userId AND status = 'pending'`,
    { projectId: Number(req.params.id), userId: req.kullanici.user_id }
  );
  res.json({ mesaj: 'Başvuru geri çekildi.' });
});

router.get('/:id/applications', async (req, res) => {
  const projectId = Number(req.params.id);
  const proje = await projeGetir(projectId);

  if (!proje) {
    return res.status(404).json({ mesaj: 'Proje bulunamadı.' });
  }

  if (proje.owner_id !== req.kullanici.user_id) {
    return res.status(403).json({ mesaj: 'Sadece proje sahibi görebilir.' });
  }

  const basvurular = await sorguCalistir(
    `SELECT a.application_id, a.message, a.status, a.created_at,
            u.user_id, u.first_name, u.last_name
     FROM dbo.project_applications a
     JOIN dbo.users u ON u.user_id = a.applicant_id
     WHERE a.project_id = @projectId
     ORDER BY a.created_at DESC`,
    { projectId }
  );
  res.json(basvurular);
});

router.delete('/:id/members/:userId', async (req, res) => {
  const projectId = Number(req.params.id);
  const cikarilacakId = Number(req.params.userId);
  const proje = await projeGetir(projectId);

  if (!proje) {
    return res.status(404).json({ mesaj: 'Proje bulunamadı.' });
  }

  const kendisi = cikarilacakId === req.kullanici.user_id;
  const sahip = proje.owner_id === req.kullanici.user_id;

  if (!kendisi && !sahip) {
    return res.status(403).json({ mesaj: 'Yetkiniz yok.' });
  }

  if (cikarilacakId === proje.owner_id) {
    return res.status(400).json({ mesaj: 'Proje sahibi takımdan çıkarılamaz.' });
  }

  await sorguCalistir(
    'DELETE FROM dbo.project_members WHERE project_id = @projectId AND user_id = @cikarilacakId',
    { projectId, cikarilacakId }
  );

  res.json({ mesaj: 'Üye takımdan çıkarıldı.' });
});

router.get('/:id/matches', async (req, res) => {
  const projectId = Number(req.params.id);
  const proje = await projeGetir(projectId);

  if (!proje) {
    return res.status(404).json({ mesaj: 'Proje bulunamadı.' });
  }

  if (proje.owner_id !== req.kullanici.user_id) {
    return res.status(403).json({ mesaj: 'Sadece proje sahibi görebilir.' });
  }

  const adaylar = await sorguCalistir(
    `SELECT u.user_id, u.first_name, u.last_name, COUNT(*) AS eslesen_yetenek
     FROM dbo.project_required_skills prs
     JOIN dbo.user_skills us ON us.skill_id = prs.skill_id AND us.level >= prs.min_level
     JOIN dbo.users u ON u.user_id = us.user_id
     JOIN dbo.profiles p ON p.user_id = u.user_id AND p.is_open_to_team = 1
     WHERE prs.project_id = @projectId
       AND u.user_id NOT IN (SELECT user_id FROM dbo.project_members WHERE project_id = @projectId)
     GROUP BY u.user_id, u.first_name, u.last_name
     ORDER BY eslesen_yetenek DESC`,
    { projectId }
  );
  res.json(adaylar);
});

module.exports = router;
