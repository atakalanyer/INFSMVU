const express = require('express');
const { sorguCalistir } = require('../db');
const { girisGerekli } = require('../middleware/auth');
const { bildirimEkle } = require('../utils/notify');

const { sayiOlmali } = require('../utils/parametre');

const router = express.Router();
router.use(girisGerekli);
router.param('id', sayiOlmali);
router.param('skillId', sayiOlmali);

async function profilGetir(id) {
  const sonuc = await sorguCalistir(
    `SELECT u.user_id, u.student_no, u.email, u.first_name, u.last_name, u.role,
            u.degree, u.class_year, u.graduation_year, d.name AS department,
            p.bio, p.avatar_url, p.cover_url, p.github_url, p.linkedin_url,
            p.portfolio_url, p.is_open_to_team
     FROM dbo.users u
     LEFT JOIN dbo.departments d ON d.department_id = u.department_id
     LEFT JOIN dbo.profiles p ON p.user_id = u.user_id
     WHERE u.user_id = @id`,
    { id }
  );
  return sonuc[0];
}

async function yetenekleriGetir(id) {
  return sorguCalistir(
    `SELECT s.skill_id, s.name, s.category, us.level
     FROM dbo.user_skills us
     JOIN dbo.skills s ON s.skill_id = us.skill_id
     WHERE us.user_id = @id`,
    { id }
  );
}

router.get('/me', async (req, res) => {
  const id = req.kullanici.user_id;
  const profil = await profilGetir(id);
  const yetenekler = await yetenekleriGetir(id);
  res.json({ ...profil, skills: yetenekler });
});

router.put('/me', async (req, res) => {
  const id = req.kullanici.user_id;
  const { first_name, last_name, department_id, degree, class_year, graduation_year } = req.body;
  const { bio, avatar_url, cover_url, github_url, linkedin_url, portfolio_url, is_open_to_team } = req.body;

  await sorguCalistir(
    `UPDATE dbo.users SET
       first_name = COALESCE(@first_name, first_name),
       last_name = COALESCE(@last_name, last_name),
       department_id = COALESCE(@department_id, department_id),
       degree = COALESCE(@degree, degree),
       class_year = COALESCE(@class_year, class_year),
       graduation_year = COALESCE(@graduation_year, graduation_year)
     WHERE user_id = @id`,
    { id, first_name, last_name, department_id, degree, class_year, graduation_year }
  );

  await sorguCalistir(
    `UPDATE dbo.profiles SET
       bio = COALESCE(@bio, bio),
       avatar_url = COALESCE(@avatar_url, avatar_url),
       cover_url = COALESCE(@cover_url, cover_url),
       github_url = COALESCE(@github_url, github_url),
       linkedin_url = COALESCE(@linkedin_url, linkedin_url),
       portfolio_url = COALESCE(@portfolio_url, portfolio_url),
       is_open_to_team = COALESCE(@is_open_to_team, is_open_to_team),
       updated_at = SYSDATETIME()
     WHERE user_id = @id`,
    { id, bio, avatar_url, cover_url, github_url, linkedin_url, portfolio_url, is_open_to_team }
  );

  const profil = await profilGetir(id);
  res.json(profil);
});

router.get('/search', async (req, res) => {
  const q = req.query.q ? '%' + req.query.q + '%' : null;
  const skillId = req.query.skill_id ? Number(req.query.skill_id) : null;

  const kullanicilar = await sorguCalistir(
    `SELECT TOP 50 u.user_id, u.first_name, u.last_name, u.role, d.name AS department
     FROM dbo.users u
     LEFT JOIN dbo.departments d ON d.department_id = u.department_id
     WHERE u.is_active = 1
       AND (@q IS NULL OR u.first_name + ' ' + u.last_name LIKE @q)
       AND (@skillId IS NULL OR EXISTS (
             SELECT 1 FROM dbo.user_skills us
             WHERE us.user_id = u.user_id AND us.skill_id = @skillId))
     ORDER BY u.first_name`,
    { q, skillId }
  );
  res.json(kullanicilar);
});

router.post('/me/skills', async (req, res) => {
  const userId = req.kullanici.user_id;
  const skillId = Number(req.body.skill_id);
  const level = Number(req.body.level) || 1;

  if (!skillId || level < 1 || level > 4) {
    return res.status(400).json({ mesaj: 'skill_id ve 1-4 arası level gerekli.' });
  }

  const yetenek = await sorguCalistir('SELECT skill_id FROM dbo.skills WHERE skill_id = @skillId', { skillId });
  if (yetenek.length === 0) {
    return res.status(404).json({ mesaj: 'Yetenek bulunamadı.' });
  }

  await sorguCalistir(
    `UPDATE dbo.user_skills SET level = @level WHERE user_id = @userId AND skill_id = @skillId;
     IF @@ROWCOUNT = 0
       INSERT INTO dbo.user_skills (user_id, skill_id, level) VALUES (@userId, @skillId, @level);`,
    { userId, skillId, level }
  );

  res.json({ mesaj: 'Yetenek kaydedildi.' });
});

router.delete('/me/skills/:skillId', async (req, res) => {
  await sorguCalistir(
    'DELETE FROM dbo.user_skills WHERE user_id = @userId AND skill_id = @skillId',
    { userId: req.kullanici.user_id, skillId: Number(req.params.skillId) }
  );
  res.json({ mesaj: 'Yetenek silindi.' });
});

router.get('/:id', async (req, res) => {
  const id = Number(req.params.id);
  const profil = await profilGetir(id);

  if (!profil) {
    return res.status(404).json({ mesaj: 'Kullanıcı bulunamadı.' });
  }

  const yetenekler = await yetenekleriGetir(id);

  const sayilar = await sorguCalistir(
    `SELECT
       (SELECT COUNT(*) FROM dbo.follows WHERE following_id = @id) AS follower_count,
       (SELECT COUNT(*) FROM dbo.follows WHERE follower_id = @id) AS following_count,
       (SELECT COUNT(*) FROM dbo.follows WHERE follower_id = @me AND following_id = @id) AS is_following`,
    { id, me: req.kullanici.user_id }
  );

  res.json({ ...profil, skills: yetenekler, ...sayilar[0] });
});

router.post('/:id/follow', async (req, res) => {
  const hedefId = Number(req.params.id);
  const benimId = req.kullanici.user_id;

  if (hedefId === benimId) {
    return res.status(400).json({ mesaj: 'Kendinizi takip edemezsiniz.' });
  }

  const hedef = await sorguCalistir('SELECT user_id FROM dbo.users WHERE user_id = @hedefId', { hedefId });
  if (hedef.length === 0) {
    return res.status(404).json({ mesaj: 'Kullanıcı bulunamadı.' });
  }

  const mevcut = await sorguCalistir(
    'SELECT 1 AS var FROM dbo.follows WHERE follower_id = @benimId AND following_id = @hedefId',
    { benimId, hedefId }
  );
  if (mevcut.length > 0) {
    return res.status(409).json({ mesaj: 'Zaten takip ediyorsunuz.' });
  }

  await sorguCalistir(
    'INSERT INTO dbo.follows (follower_id, following_id) VALUES (@benimId, @hedefId)',
    { benimId, hedefId }
  );

  await bildirimEkle(hedefId, benimId, 'follow');
  res.status(201).json({ mesaj: 'Takip edildi.' });
});

router.delete('/:id/follow', async (req, res) => {
  await sorguCalistir(
    'DELETE FROM dbo.follows WHERE follower_id = @benimId AND following_id = @hedefId',
    { benimId: req.kullanici.user_id, hedefId: Number(req.params.id) }
  );
  res.json({ mesaj: 'Takip bırakıldı.' });
});

router.get('/:id/followers', async (req, res) => {
  const liste = await sorguCalistir(
    `SELECT u.user_id, u.first_name, u.last_name
     FROM dbo.follows f
     JOIN dbo.users u ON u.user_id = f.follower_id
     WHERE f.following_id = @id`,
    { id: Number(req.params.id) }
  );
  res.json(liste);
});

router.get('/:id/following', async (req, res) => {
  const liste = await sorguCalistir(
    `SELECT u.user_id, u.first_name, u.last_name
     FROM dbo.follows f
     JOIN dbo.users u ON u.user_id = f.following_id
     WHERE f.follower_id = @id`,
    { id: Number(req.params.id) }
  );
  res.json(liste);
});

module.exports = router;
