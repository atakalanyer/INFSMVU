const express = require('express');
const { sorguCalistir } = require('../db');

const router = express.Router();

router.get('/departments', async (req, res) => {
  const bolumler = await sorguCalistir('SELECT department_id, name, faculty FROM dbo.departments ORDER BY name');
  res.json(bolumler);
});

router.get('/skills', async (req, res) => {
  const yetenekler = await sorguCalistir('SELECT skill_id, name, category FROM dbo.skills ORDER BY category, name');
  res.json(yetenekler);
});

module.exports = router;
