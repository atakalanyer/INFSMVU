const jwt = require('jsonwebtoken');

function girisGerekli(req, res, next) {
  const baslik = req.headers.authorization || '';
  const token = baslik.startsWith('Bearer ') ? baslik.slice(7) : null;

  if (!token) {
    return res.status(401).json({ mesaj: 'Giriş yapmalısınız.' });
  }

  try {
    req.kullanici = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (hata) {
    res.status(401).json({ mesaj: 'Geçersiz veya süresi dolmuş token.' });
  }
}

function rolGerekli(...roller) {
  return (req, res, next) => {
    if (!roller.includes(req.kullanici.role)) {
      return res.status(403).json({ mesaj: 'Bu işlem için yetkiniz yok.' });
    }
    next();
  };
}

module.exports = { girisGerekli, rolGerekli };
