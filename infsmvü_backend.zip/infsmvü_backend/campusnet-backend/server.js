require('dotenv').config();
const express = require('express');
const cors = require('cors');

if (!process.env.JWT_SECRET) {
  console.error('.env dosyasında JWT_SECRET tanımlı değil.');
  process.exit(1);
}

const app = express();

app.use(cors());
app.use(express.json());
app.use((req, res, next) => {
  if (!req.body) req.body = {};
  next();
});

app.use('/api/auth', require('./routes/auth'));
app.use('/api/lookup', require('./routes/lookup'));
app.use('/api/users', require('./routes/users'));
app.use('/api/clubs', require('./routes/clubs'));
app.use('/api/projects', require('./routes/projects'));
app.use('/api/posts', require('./routes/posts'));
app.use('/api/events', require('./routes/events'));
app.use('/api/notifications', require('./routes/notifications'));

app.use((req, res) => {
  res.status(404).json({ mesaj: 'Böyle bir adres yok.' });
});

app.use((hata, req, res, next) => {
  console.error(hata);

  if (hata.number === 547) {
    return res.status(400).json({ mesaj: 'Geçersiz veri: ilişkili kayıt bulunamadı veya değer kurallara uymuyor.' });
  }

  if (hata.number === 2627 || hata.number === 2601) {
    return res.status(409).json({ mesaj: 'Bu kayıt zaten mevcut.' });
  }

  if ([220, 245, 8114, 8115, 8152].includes(hata.number)) {
    return res.status(400).json({ mesaj: 'Gönderilen değerlerden biri hatalı veya çok uzun.' });
  }

  const durum = hata.status || 500;
  const mesaj = durum === 500 ? 'Sunucu hatası oluştu.' : 'İstek hatalı. JSON formatını kontrol edin.';
  res.status(durum).json({ mesaj });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log('Sunucu çalışıyor: http://localhost:' + port);
});
