const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const express = require('express');
const cors = require('cors');

// Zorunlu ortam değişkenlerinin doğrulanması
const ZORUNLU_DEGISKENLER = ['JWT_SECRET', 'DB_NAME'];
const eksikler = ZORUNLU_DEGISKENLER.filter((k) => !process.env[k]);

if (eksikler.length > 0) {
  console.error('\n[HATA] .env dosyasında eksik zorunlu değişkenler var:');
  eksikler.forEach((e) => console.error(` - ${e}`));
  console.error('Lütfen backend/.env.example dosyasını .env olarak kopyalayıp değerleri doldurun.\n');
  process.exit(1);
}

const app = express();

app.use(cors());
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));

// Yüklenen poster ve avatarları statik olarak sun
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use((req, res, next) => {
  if (!req.body) req.body = {};
  next();
});

// API Rotaları
app.use('/api/auth', require('./routes/auth'));
app.use('/api/lookup', require('./routes/lookup'));
app.use('/api/users', require('./routes/users'));
app.use('/api/clubs', require('./routes/clubs'));
app.use('/api/projects', require('./routes/projects'));
app.use('/api/posts', require('./routes/posts'));
app.use('/api/events', require('./routes/events'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/admin', require('./routes/admin'));

// 404 Yakalayıcı
app.use((req, res) => {
  res.status(404).json({ mesaj: 'Böyle bir adres yok.' });
});

// Merkezi Hata Yakalayıcı
app.use((hata, req, res, next) => {
  console.error('[Sunucu Hatası]:', hata);

  if (hata.number === 547) {
    return res.status(400).json({ mesaj: 'Geçersiz veri: ilişkili kayıt bulunamadı veya kısıtlara uymuyor.' });
  }

  if (hata.number === 2627 || hata.number === 2601) {
    return res.status(409).json({ mesaj: 'Bu kayıt veritabanında zaten mevcut.' });
  }

  if ([220, 245, 8114, 8115, 8152].includes(hata.number)) {
    return res.status(400).json({ mesaj: 'Gönderilen değerlerden biri hatalı veya izin verilen boyutu aşıyor.' });
  }

  if (hata.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ mesaj: 'Yüklenen afiş boyutu en fazla 5 MB olabilir.' });
  }

  const durum = hata.status || 500;
  const mesaj = durum === 500 ? (hata.message || 'Sunucu hatası oluştu.') : hata.message;
  res.status(durum).json({ mesaj });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`\n========================================`);
  console.log(` INFSMVU Backend Sunucusu Çalışıyor `);
  console.log(` Adres: http://localhost:${port}`);
  console.log(` MSSQL Sunucu: ${process.env.DB_SERVER || 'localhost'}`);
  console.log(` Veritabanı: ${process.env.DB_NAME}`);
  console.log(`========================================\n`);
});
