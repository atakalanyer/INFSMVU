const { sorguCalistir } = require('../db');

async function yonetilenKulupler(userId) {
  return sorguCalistir(
    `SELECT c.club_id, c.name
     FROM dbo.club_members m
     JOIN dbo.clubs c ON c.club_id = m.club_id
     WHERE m.user_id = @userId AND m.is_admin = 1
     ORDER BY c.name`,
    { userId }
  );
}

function oturumKullanicisi(kullanici, kulupler) {
  return {
    user_id: kullanici.user_id,
    first_name: kullanici.first_name,
    last_name: kullanici.last_name,
    email: kullanici.email,
    role: kullanici.role,
    department: kullanici.department || null,
    is_club_representative: kullanici.role === 'club_admin' || kullanici.role === 'admin',
    managed_clubs: kulupler
  };
}

module.exports = { yonetilenKulupler, oturumKullanicisi };
