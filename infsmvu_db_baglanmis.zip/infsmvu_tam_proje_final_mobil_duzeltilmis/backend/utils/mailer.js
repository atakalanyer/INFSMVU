const nodemailer = require('nodemailer');

function temizleSmtpAyari(deger) {
  return deger ? String(deger).trim() : '';
}

function smtpAyarliMi() {
  const user = temizleSmtpAyari(process.env.SMTP_USER);
  const pass = temizleSmtpAyari(process.env.SMTP_PASS);
  return Boolean(user && pass);
}

function transporterOlustur() {
  const port = Number(process.env.SMTP_PORT || 587);
  // Gmail kullanıcı adındaki Türkçe karakterleri veya boşlukları temizle
  let user = temizleSmtpAyari(process.env.SMTP_USER);
  if (user.includes('infsmvü')) {
    user = user.replace(/infsmvü/g, 'infsmvu');
  }

  // Google App Password boşlukları içerebilir, boşlukları temizle
  const pass = temizleSmtpAyari(process.env.SMTP_PASS).replace(/\s+/g, '');

  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port,
    secure: port === 465,
    auth: {
      user,
      pass
    }
  });
}

async function epostaGonder({ to, subject, text, html }) {
  if (!smtpAyarliMi()) {
    return {
      ok: false,
      skipped: true,
      error: 'SMTP yapılandırılmamış. Lütfen SMTP_USER ve SMTP_PASS tanımlayın.'
    };
  }

  try {
    const transporter = transporterOlustur();
    let fromEmail = temizleSmtpAyari(process.env.MAIL_FROM || process.env.SMTP_USER);
    if (fromEmail.includes('infsmvü')) {
      fromEmail = fromEmail.replace(/infsmvü/g, 'infsmvu');
    }

    const bilgi = await transporter.sendMail({
      from: `"INFSMVU - FSMVÜ Proje Ağı" <${fromEmail}>`,
      to,
      subject,
      text,
      html
    });

    console.log(`[E-POSTA BAŞARILI] Kime: ${to} | Konu: ${subject} | MesajID: ${bilgi.messageId}`);
    return { ok: true, messageId: bilgi.messageId };
  } catch (hata) {
    console.error(`[E-POSTA HATASI] Kime: ${to} | Hata:`, hata.message);
    return { ok: false, error: hata.message || 'E-posta gönderilemedi.' };
  }
}

module.exports = { epostaGonder, smtpAyarliMi };
