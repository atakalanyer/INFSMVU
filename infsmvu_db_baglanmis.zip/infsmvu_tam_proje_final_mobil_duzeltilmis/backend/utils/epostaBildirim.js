const { sorguCalistir } = require('../db');
const { epostaGonder } = require('./mailer');

function tarihYaz(deger) {
  if (!deger) return '—';
  const tarih = new Date(deger);
  if (Number.isNaN(tarih.getTime())) return String(deger);
  return tarih.toLocaleString('tr-TR', { dateStyle: 'full', timeStyle: 'short' });
}

function etkinlikMetni(etkinlik) {
  return [
    `Etkinlik: ${etkinlik.title}`,
    `Kulüp: ${etkinlik.club_name || '—'}`,
    `Tarih: ${tarihYaz(etkinlik.starts_at)}`,
    `Yer: ${etkinlik.location || '—'}`,
    etkinlik.category ? `Kategori: ${etkinlik.category}` : null,
    '',
    etkinlik.description || ''
  ].filter((satir) => satir !== null).join('\n');
}

async function kayitAc(alici, etkinlik, kind, dedupeKey, subject) {
  try {
    const eklenen = await sorguCalistir(
      `INSERT INTO dbo.email_notifications
         (event_id, user_id, kind, dedupe_key, recipient_email, subject, status)
       OUTPUT INSERTED.email_notification_id
       VALUES (@eventId, @userId, @kind, @dedupeKey, @email, @subject, 'pending')`,
      {
        eventId: etkinlik.event_id,
        userId: alici.user_id,
        kind,
        dedupeKey,
        email: alici.email,
        subject
      }
    );
    return eklenen[0].email_notification_id;
  } catch (hata) {
    if (hata.number === 2627 || hata.number === 2601) return null;
    throw hata;
  }
}

async function durumuYaz(id, status, errorMessage) {
  await sorguCalistir(
    `UPDATE dbo.email_notifications
     SET status = @status,
         error_message = @errorMessage,
         sent_at = CASE WHEN @status = 'sent' THEN SYSDATETIME() ELSE sent_at END
     WHERE email_notification_id = @id`,
    {
      id,
      status,
      errorMessage: errorMessage ? String(errorMessage).slice(0, 500) : null
    }
  );
}

async function tekGonder({ alici, etkinlik, kind, dedupeKey, subject, text }) {
  const kayitId = await kayitAc(alici, etkinlik, kind, dedupeKey, subject);
  if (!kayitId) return { status: 'duplicate' };

  const sonuc = await epostaGonder({
    to: alici.email,
    subject,
    text,
    html: `<pre style="font-family:Segoe UI,sans-serif;white-space:pre-wrap">${text.replace(/</g, '&lt;')}</pre>`
  });

  if (sonuc.ok) {
    await durumuYaz(kayitId, 'sent', null);
    return { status: 'sent' };
  }

  const durum = sonuc.skipped ? 'skipped' : 'failed';
  await durumuYaz(kayitId, durum, sonuc.error);
  return { status: durum, error: sonuc.error };
}

async function topluGonder(isler) {
  const ozet = { sent: 0, failed: 0, skipped: 0, duplicate: 0 };
  for (const is of isler) {
    try {
      const sonuc = await tekGonder(is);
      ozet[sonuc.status] = (ozet[sonuc.status] || 0) + 1;
    } catch (hata) {
      ozet.failed += 1;
      console.error('E-posta bildirimi yazılamadı:', hata.message);
    }
  }
  return ozet;
}

async function yeniEtkinlikBildir(etkinlik) {
  const alicilar = await sorguCalistir(
    `SELECT user_id, email, first_name
     FROM dbo.users
     WHERE is_active = 1
       AND is_email_verified = 1
       AND role IN ('student', 'club_admin', 'alumni')
       AND user_id <> @olusturan`,
    { olusturan: etkinlik.created_by }
  );

  const subject = `Yeni etkinlik: ${etkinlik.title}`;
  return topluGonder(alicilar.map((alici) => ({
    alici,
    etkinlik,
    kind: 'new_event',
    dedupeKey: `event:${etkinlik.event_id}:published:user:${alici.user_id}`,
    subject,
    text: `Merhaba ${alici.first_name},\n\nKulübünüz yeni bir etkinlik yayınladı.\n\n${etkinlikMetni(etkinlik)}\n\nINFSMVU üzerinden kayıt olabilirsiniz.`
  })));
}

async function kayitOnayiBildir(etkinlik, alici) {
  const subject = `Kaydınız alındı: ${etkinlik.title}`;
  return topluGonder([{
    alici,
    etkinlik,
    kind: 'registration',
    dedupeKey: `event:${etkinlik.event_id}:registration:user:${alici.user_id}`,
    subject,
    text: `Merhaba ${alici.first_name},\n\nEtkinlik kaydınız oluşturuldu.\n\n${etkinlikMetni(etkinlik)}`
  }]);
}

async function guncellemeBildir(etkinlik, katilimcilar) {
  const damga = new Date(etkinlik.updated_at).getTime();
  const subject = `Etkinlik güncellendi: ${etkinlik.title}`;
  return topluGonder(katilimcilar.map((alici) => ({
    alici,
    etkinlik,
    kind: 'event_updated',
    dedupeKey: `event:${etkinlik.event_id}:updated:${damga}:user:${alici.user_id}`,
    subject,
    text: `Merhaba ${alici.first_name},\n\nKayıtlı olduğunuz etkinliğin bilgileri güncellendi.\n\n${etkinlikMetni(etkinlik)}`
  })));
}

async function iptalBildir(etkinlik, katilimcilar) {
  const subject = `Etkinlik iptal edildi: ${etkinlik.title}`;
  return topluGonder(katilimcilar.map((alici) => ({
    alici,
    etkinlik,
    kind: 'event_cancelled',
    dedupeKey: `event:${etkinlik.event_id}:cancelled:user:${alici.user_id}`,
    subject,
    text: `Merhaba ${alici.first_name},\n\nKayıtlı olduğunuz etkinlik iptal edildi.\n\n${etkinlikMetni(etkinlik)}`
  })));
}

module.exports = {
  yeniEtkinlikBildir,
  kayitOnayiBildir,
  guncellemeBildir,
  iptalBildir
};
