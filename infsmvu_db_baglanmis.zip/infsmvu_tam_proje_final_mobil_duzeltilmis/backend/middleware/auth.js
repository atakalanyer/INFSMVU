const jwt = require('jsonwebtoken');
const { sorguCalistir } = require('../db');

async function girisGerekli(req, res, next) {
  const baslik = req.headers.authorization || '';
  const token = baslik.startsWith('Bearer ') ? baslik.slice(7) : null;

  if (!token) {
    return res.status(401).json({ mesaj: 'Giriş yapmalısınız.' });
  }

  try {
    const cozulmus = jwt.verify(token, process.env.JWT_SECRET);
    const kayitlar = await sorguCalistir(
      `SELECT user_id, email, first_name, last_name, role, is_active
       FROM dbo.users
       WHERE user_id = @id`,
      { id: cozulmus.user_id }
    );
    const kullanici = kayitlar[0];

    if (!kullanici || !kullanici.is_active) {
      return res.status(401).json({ mesaj: 'Oturum geçersiz.' });
    }

    req.kullanici = {
      user_id: kullanici.user_id,
      email: kullanici.email,
      first_name: kullanici.first_name,
      last_name: kullanici.last_name,
      role: kullanici.role
    };
    next();
  } catch (hata) {
    if (hata.name === 'JsonWebTokenError' || hata.name === 'TokenExpiredError') {
      return res.status(401).json({ mesaj: 'Geçersiz veya süresi dolmuş token.' });
    }
    next(hata);
  }
}

function rolGerekli(...roller) {
  return (req, res, next) => {
    if (!roller.includes(req.kullanici.role)) {
      return res.status(403).json({ mesaj: 'Bu işlem için yetkiniz yok.' });
    }
    next();
  };
}

module.exports = { girisGerekli, rolGerekli };
