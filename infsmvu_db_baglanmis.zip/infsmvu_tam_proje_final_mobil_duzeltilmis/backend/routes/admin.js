const express = require('express');
const { sorguCalistir } = require('../db');
const { girisGerekli, rolGerekli } = require('../middleware/auth');

const router = express.Router();
router.use(girisGerekli, rolGerekli('admin'));

router.post('/club-representatives', async (req, res) => {
  const email = (req.body.email || '').trim().toLowerCase();
  const clubId = Number(req.body.club_id);
  const grant = req.body.grant !== false;

  if (!email || !Number.isInteger(clubId)) {
    return res.status(400).json({ mesaj: 'E-posta ve club_id zorunludur.' });
  }

  const kullanicilar = await sorguCalistir(
    'SELECT user_id, role FROM dbo.users WHERE email = @email',
    { email }
  );
  if (kullanicilar.length === 0) return res.status(404).json({ mesaj: 'Kullanıcı bulunamadı.' });
  if (kullanicilar[0].role === 'admin') {
    return res.status(400).json({ mesaj: 'Yönetici hesabının rolü bu ekrandan değiştirilemez.' });
  }

  const kulup = await sorguCalistir('SELECT club_id FROM dbo.clubs WHERE club_id = @clubId', { clubId });
  if (kulup.length === 0) return res.status(404).json({ mesaj: 'Kulüp bulunamadı.' });

  const userId = kullanicilar[0].user_id;

  if (grant) {
    await sorguCalistir(
      `UPDATE dbo.users SET role = 'club_admin' WHERE user_id = @userId`,
      { userId }
    );
    const uyelik = await sorguCalistir(
      'SELECT 1 AS var FROM dbo.club_members WHERE club_id = @clubId AND user_id = @userId',
      { clubId, userId }
    );
    if (uyelik.length === 0) {
      await sorguCalistir(
        'INSERT INTO dbo.club_members (club_id, user_id, is_admin) VALUES (@clubId, @userId, 1)',
        { clubId, userId }
      );
    } else {
      await sorguCalistir(
        'UPDATE dbo.club_members SET is_admin = 1 WHERE club_id = @clubId AND user_id = @userId',
        { clubId, userId }
      );
    }
    return res.json({ mesaj: 'Kulüp temsilcisi yetkisi verildi.' });
  }

  await sorguCalistir(
    'UPDATE dbo.club_members SET is_admin = 0 WHERE club_id = @clubId AND user_id = @userId',
    { clubId, userId }
  );
  const kalan = await sorguCalistir(
    'SELECT 1 AS var FROM dbo.club_members WHERE user_id = @userId AND is_admin = 1',
    { userId }
  );
  if (kalan.length === 0) {
    await sorguCalistir(`UPDATE dbo.users SET role = 'student' WHERE user_id = @userId AND role = 'club_admin'`, { userId });
  }
  res.json({ mesaj: 'Kulüp temsilcisi yetkisi kaldırıldı.' });
});

module.exports = router;
