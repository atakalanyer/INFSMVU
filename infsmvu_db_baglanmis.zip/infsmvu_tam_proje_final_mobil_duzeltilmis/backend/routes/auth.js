const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { sorguCalistir } = require('../db');
const { epostaGonder, smtpAyarliMi } = require('../utils/mailer');
const { yonetilenKulupler, oturumKullanicisi } = require('../utils/oturum');

const router = express.Router();

function kodUret() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

async function dogrulamaGonder(userId, email, ad) {
  const token = kodUret();
  await sorguCalistir(
    `UPDATE dbo.email_verifications SET used_at = SYSDATETIME()
     WHERE user_id = @userId AND used_at IS NULL`,
    { userId }
  );
  await sorguCalistir(
    `INSERT INTO dbo.email_verifications (user_id, token, expires_at)
     VALUES (@userId, @token, DATEADD(MINUTE, 15, SYSDATETIME()))`,
    { userId, token }
  );

  const sonuc = await epostaGonder({
    to: email,
    subject: 'INFSMVU doğrulama kodu',
    text: `Merhaba ${ad},\n\nHesabınızı doğrulamak için kodunuz: ${token}\nKod 15 dakika geçerlidir.`,
    html: `<p>Merhaba ${ad},</p><p>Hesabınızı doğrulamak için kodunuz: <strong>${token}</strong></p><p>Kod 15 dakika geçerlidir.</p>`
  });

  const gelistirmeKodu = !smtpAyarliMi() && process.env.ALLOW_DEV_EMAIL_CODE === 'true';
  return {
    gonderildi: sonuc.ok,
    hata: sonuc.ok ? null : sonuc.error,
    kod: gelistirmeKodu ? token : undefined
  };
}

router.post('/register', async (req, res) => {
  const { password, first_name, last_name, student_no, department_id, degree, class_year } = req.body;
  const email = (req.body.email || '').trim().toLowerCase();
  const istenenRol = req.body.role || 'student';

  if (['club_admin', 'admin', 'club_rep'].includes(istenenRol)) {
    return res.status(403).json({ mesaj: 'Kulüp temsilcisi rolü kayıttan verilemez. Bu yetkiyi yalnızca yönetici tanımlayabilir.' });
  }

  const role = istenenRol === 'academic' ? 'academic' : istenenRol === 'alumni' ? 'alumni' : 'student';

  if (!email || !password || !first_name || !last_name) {
    return res.status(400).json({ mesaj: 'E-posta, şifre, ad ve soyad zorunludur.' });
  }

  if (typeof password !== 'string' || password.length < 8 || !/[A-Za-zÇĞİÖŞÜçğıöşü]/.test(password) || !/\d/.test(password)) {
    return res.status(400).json({ mesaj: 'Şifre en az 8 karakter olmalı ve harf ile rakam içermelidir.' });
  }

  if ((role === 'student' || role === 'alumni') && !email.endsWith('@stu.fsm.edu.tr')) {
    return res.status(400).json({ mesaj: 'Öğrenci ve mezunlar @stu.fsm.edu.tr uzantılı e-posta kullanmalı.' });
  }

  if (role === 'academic' && !email.endsWith('@fsm.edu.tr')) {
    return res.status(400).json({ mesaj: 'Akademisyen hesapları @fsm.edu.tr uzantılı e-posta kullanmalı.' });
  }

  const mevcut = await sorguCalistir('SELECT user_id FROM dbo.users WHERE email = @email', { email });
  if (mevcut.length > 0) {
    return res.status(409).json({ mesaj: 'Bu e-posta zaten kayıtlı.' });
  }

  const sifreHash = await bcrypt.hash(password, 10);
  const eklenen = await sorguCalistir(
    `INSERT INTO dbo.users (student_no, email, password_hash, first_name, last_name, role, department_id, degree, class_year, is_email_verified)
     OUTPUT INSERTED.user_id
     VALUES (@student_no, @email, @sifreHash, @first_name, @last_name, @role, @department_id, @degree, @class_year, 0)`,
    {
      student_no: student_no || null,
      email,
      sifreHash,
      first_name,
      last_name,
      role,
      department_id: department_id || null,
      degree: degree || null,
      class_year: class_year || null
    }
  );

  const userId = eklenen[0].user_id;
  await sorguCalistir('INSERT INTO dbo.profiles (user_id) VALUES (@userId)', { userId });
  const posta = await dogrulamaGonder(userId, email, first_name);

  res.status(201).json({
    mesaj: posta.gonderildi
      ? 'Kayıt oluşturuldu. Doğrulama kodu e-postanıza gönderildi.'
      : 'Kayıt oluşturuldu. E-posta şu an gönderilemedi; geliştirme kodu yalnızca yerel ortamda döner.',
    user_id: userId,
    email_gonderildi: posta.gonderildi,
    dogrulama_kodu: posta.kod
  });
});

router.post('/resend', async (req, res) => {
  const email = (req.body.email || '').trim().toLowerCase();
  const kayit = await sorguCalistir(
    'SELECT user_id, first_name, is_email_verified FROM dbo.users WHERE email = @email',
    { email }
  );
  if (kayit.length === 0) return res.status(404).json({ mesaj: 'Hesap bulunamadı.' });
  if (kayit[0].is_email_verified) return res.status(400).json({ mesaj: 'E-posta zaten doğrulanmış.' });

  const son = await sorguCalistir(
    `SELECT TOP 1 created_at FROM dbo.email_verifications
     WHERE user_id = @userId AND used_at IS NULL
     ORDER BY verification_id DESC`,
    { userId: kayit[0].user_id }
  );
  if (son[0] && new Date(son[0].created_at).getTime() > Date.now() - 45000) {
    return res.status(429).json({ mesaj: 'Yeni kod için kısa bir süre bekleyin.' });
  }

  const posta = await dogrulamaGonder(kayit[0].user_id, email, kayit[0].first_name);
  res.json({
    mesaj: 'Doğrulama kodu hazırlandı.',
    email_gonderildi: posta.gonderildi,
    dogrulama_kodu: posta.kod
  });
});

router.post('/verify', async (req, res) => {
  const email = (req.body.email || '').trim().toLowerCase();
  const token = String(req.body.code || req.body.token || '').trim();

  const kayit = await sorguCalistir(
    `SELECT v.verification_id, v.user_id
     FROM dbo.email_verifications v
     JOIN dbo.users u ON u.user_id = v.user_id
     WHERE u.email = @email AND v.token = @token AND v.used_at IS NULL AND v.expires_at > SYSDATETIME()`,
    { email, token }
  );

  if (kayit.length === 0) {
    return res.status(400).json({ mesaj: 'Kod geçersiz veya süresi dolmuş.' });
  }

  await sorguCalistir('UPDATE dbo.users SET is_email_verified = 1 WHERE user_id = @userId', { userId: kayit[0].user_id });
  await sorguCalistir('UPDATE dbo.email_verifications SET used_at = SYSDATETIME() WHERE verification_id = @id', { id: kayit[0].verification_id });
  res.json({ mesaj: 'E-posta doğrulandı, giriş yapabilirsiniz.' });
});

router.get('/verify/:token', async (req, res) => {
  const token = req.params.token;
  const kayit = await sorguCalistir(
    `SELECT verification_id, user_id FROM dbo.email_verifications
     WHERE token = @token AND used_at IS NULL AND expires_at > SYSDATETIME()`,
    { token }
  );

  if (kayit.length === 0) {
    return res.status(400).json({ mesaj: 'Kod geçersiz veya süresi dolmuş.' });
  }

  await sorguCalistir('UPDATE dbo.users SET is_email_verified = 1 WHERE user_id = @userId', { userId: kayit[0].user_id });
  await sorguCalistir('UPDATE dbo.email_verifications SET used_at = SYSDATETIME() WHERE verification_id = @id', { id: kayit[0].verification_id });
  res.json({ mesaj: 'E-posta doğrulandı, giriş yapabilirsiniz.' });
});

router.post('/login', async (req, res) => {
  const email = (req.body.email || '').trim().toLowerCase();
  const password = req.body.password;

  if (!email || !password) {
    return res.status(400).json({ mesaj: 'E-posta ve şifre zorunludur.' });
  }

  const sonuc = await sorguCalistir(
    `SELECT u.*, d.name AS department
     FROM dbo.users u
     LEFT JOIN dbo.departments d ON d.department_id = u.department_id
     WHERE u.email = @email`,
    { email }
  );
  const kullanici = sonuc[0];

  if (!kullanici || !(await bcrypt.compare(password, kullanici.password_hash))) {
    return res.status(401).json({ mesaj: 'E-posta veya şifre hatalı.' });
  }

  if (!kullanici.is_active) {
    return res.status(403).json({ mesaj: 'Hesabınız pasif durumda.' });
  }

  if (!kullanici.is_email_verified) {
    return res.status(403).json({ mesaj: 'Önce e-postanızı doğrulayın.', dogrulama_gerekli: true });
  }

  await sorguCalistir('UPDATE dbo.users SET last_login_at = SYSDATETIME() WHERE user_id = @id', { id: kullanici.user_id });

  const token = jwt.sign(
    { user_id: kullanici.user_id },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
  const kulupler = await yonetilenKulupler(kullanici.user_id);

  res.json({
    token,
    kullanici: oturumKullanicisi(kullanici, kulupler)
  });
});

module.exports = router;
