const express = require('express');
const { sorguCalistir } = require('../db');
const { girisGerekli, rolGerekli } = require('../middleware/auth');
const { kulupYoneticisiMi } = require('../utils/yetki');

const { sayiOlmali } = require('../utils/parametre');

const router = express.Router();
router.use(girisGerekli);
router.param('id', sayiOlmali);

router.get('/', async (req, res) => {
  const kulupler = await sorguCalistir(
    `SELECT c.club_id, c.name, c.description, c.logo_url,
            (SELECT COUNT(*) FROM dbo.club_members m WHERE m.club_id = c.club_id) AS member_count
     FROM dbo.clubs c
     ORDER BY c.name`
  );
  res.json(kulupler);
});

router.get('/:id', async (req, res) => {
  const id = Number(req.params.id);

  const kulup = await sorguCalistir(
    `SELECT c.club_id, c.name, c.description, c.logo_url, c.created_at,
            u.first_name + ' ' + u.last_name AS advisor_name
     FROM dbo.clubs c
     LEFT JOIN dbo.users u ON u.user_id = c.advisor_id
     WHERE c.club_id = @id`,
    { id }
  );

  if (kulup.length === 0) {
    return res.status(404).json({ mesaj: 'Kulüp bulunamadı.' });
  }

  const uyeler = await sorguCalistir(
    `SELECT u.user_id, u.first_name, u.last_name, m.is_admin, m.joined_at
     FROM dbo.club_members m
     JOIN dbo.users u ON u.user_id = m.user_id
     WHERE m.club_id = @id
     ORDER BY m.is_admin DESC, u.first_name`,
    { id }
  );

  res.json({ ...kulup[0], members: uyeler });
});

router.post('/', rolGerekli('admin'), async (req, res) => {
  const { name, description, logo_url, advisor_id } = req.body;

  if (!name) {
    return res.status(400).json({ mesaj: 'Kulüp adı zorunlu.' });
  }

  const mevcut = await sorguCalistir('SELECT club_id FROM dbo.clubs WHERE name = @name', { name });
  if (mevcut.length > 0) {
    return res.status(409).json({ mesaj: 'Bu isimde bir kulüp zaten var.' });
  }

  const eklenen = await sorguCalistir(
    `INSERT INTO dbo.clubs (name, description, logo_url, advisor_id)
     OUTPUT INSERTED.club_id
     VALUES (@name, @description, @logo_url, @advisor_id)`,
    { name, description, logo_url, advisor_id }
  );

  const clubId = eklenen[0].club_id;

  await sorguCalistir(
    'INSERT INTO dbo.club_members (club_id, user_id, is_admin) VALUES (@clubId, @userId, 1)',
    { clubId, userId: req.kullanici.user_id }
  );

  res.status(201).json({ mesaj: 'Kulüp oluşturuldu.', club_id: clubId });
});

router.put('/:id', async (req, res) => {
  const id = Number(req.params.id);
  const yonetici = req.kullanici.role === 'club_admin' && await kulupYoneticisiMi(id, req.kullanici.user_id);

  if (!yonetici && req.kullanici.role !== 'admin') {
    return res.status(403).json({ mesaj: 'Sadece kulüp temsilcisi düzenleyebilir.' });
  }

  const { name, description, logo_url } = req.body;

  await sorguCalistir(
    `UPDATE dbo.clubs SET
       name = COALESCE(@name, name),
       description = COALESCE(@description, description),
       logo_url = COALESCE(@logo_url, logo_url)
     WHERE club_id = @id`,
    { id, name, description, logo_url }
  );

  res.json({ mesaj: 'Kulüp güncellendi.' });
});

router.post('/:id/join', async (req, res) => {
  const clubId = Number(req.params.id);
  const userId = req.kullanici.user_id;

  const kulup = await sorguCalistir('SELECT club_id FROM dbo.clubs WHERE club_id = @clubId', { clubId });
  if (kulup.length === 0) {
    return res.status(404).json({ mesaj: 'Kulüp bulunamadı.' });
  }

  const mevcut = await sorguCalistir(
    'SELECT 1 AS var FROM dbo.club_members WHERE club_id = @clubId AND user_id = @userId',
    { clubId, userId }
  );
  if (mevcut.length > 0) {
    return res.status(409).json({ mesaj: 'Zaten üyesiniz.' });
  }

  await sorguCalistir(
    'INSERT INTO dbo.club_members (club_id, user_id) VALUES (@clubId, @userId)',
    { clubId, userId }
  );

  res.status(201).json({ mesaj: 'Kulübe katıldınız.' });
});

router.delete('/:id/leave', async (req, res) => {
  await sorguCalistir(
    'DELETE FROM dbo.club_members WHERE club_id = @clubId AND user_id = @userId',
    { clubId: Number(req.params.id), userId: req.kullanici.user_id }
  );
  res.json({ mesaj: 'Kulüpten ayrıldınız.' });
});

module.exports = router;
