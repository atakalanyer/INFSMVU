const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { sorguCalistir } = require('../db');
const { girisGerekli } = require('../middleware/auth');
const { etkinlikYonetebilirMi } = require('../utils/yetki');
const { sayiOlmali } = require('../utils/parametre');
const {
  yeniEtkinlikBildir,
  kayitOnayiBildir,
  guncellemeBildir,
  iptalBildir
} = require('../utils/epostaBildirim');

const KATEGORILER = [
  'Hackathon & Yarışma',
  'Çalıştay',
  'Seminer & Konferans',
  'Sergi & Fuar',
  'Girişimcilik',
  'Workshop',
  'Sosyal',
  'Spor',
  'Kültür'
];

const uploadDir = path.join(__dirname, '..', 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, file, cb) => {
      const uzanti = path.extname(file.originalname).toLowerCase();
      const ad = `${Date.now()}-${Math.random().toString(16).slice(2)}${uzanti}`;
      cb(null, ad);
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype)) {
      const hata = new Error('Yalnızca JPG, PNG veya WEBP poster yüklenebilir.');
      hata.status = 400;
      return cb(hata);
    }
    cb(null, true);
  }
});

const router = express.Router();
router.use(girisGerekli);
router.param('id', sayiOlmali);

function metin(deger, enFazla) {
  if (deger === undefined || deger === null) return null;
  const temiz = String(deger).trim();
  if (!temiz) return null;
  return temiz.slice(0, enFazla);
}

function tarihCoz(deger) {
  if (!deger) return null;
  const tarih = new Date(deger);
  if (Number.isNaN(tarih.getTime())) return null;
  return tarih;
}

function kapasiteCoz(deger) {
  if (deger === undefined || deger === null || deger === '') return null;
  const sayi = Number(deger);
  if (!Number.isInteger(sayi) || sayi < 1 || sayi > 10000) return undefined;
  return sayi;
}

function govdeOku(body) {
  const title = metin(body.title, 200);
  const description = metin(body.description, 8000);
  const location = metin(body.location, 200);
  const category = metin(body.category, 80);
  const startsAt = tarihCoz(body.starts_at);
  const endsAt = body.ends_at ? tarihCoz(body.ends_at) : null;
  const capacity = kapasiteCoz(body.capacity);
  const status = body.status || 'published';
  const clubId = Number(body.club_id);

  const hatalar = [];
  if (!title) hatalar.push('Etkinlik başlığı zorunludur.');
  if (!description) hatalar.push('Açıklama zorunludur.');
  if (!location) hatalar.push('Konum zorunludur.');
  if (!Number.isInteger(clubId) || clubId < 1) hatalar.push('Kulüp seçilmelidir.');
  if (!startsAt) hatalar.push('Geçerli bir başlangıç tarihi girin.');
  if (body.ends_at && !endsAt) hatalar.push('Bitiş tarihi hatalı.');
  if (startsAt && endsAt && endsAt < startsAt) hatalar.push('Bitiş tarihi başlangıçtan önce olamaz.');
  if (category && !KATEGORILER.includes(category)) hatalar.push('Geçersiz kategori.');
  if (capacity === undefined) hatalar.push('Kontenjan 1 ile 10000 arasında bir tam sayı olmalı.');
  if (!['draft', 'published', 'cancelled'].includes(status)) hatalar.push('Geçersiz kayıt durumu.');

  return {
    hatalar,
    deger: {
      club_id: clubId,
      title,
      description,
      location,
      category,
      starts_at: startsAt,
      ends_at: endsAt,
      capacity,
      status
    }
  };
}

const ETKINLIK_SEC = `
  SELECT e.event_id, e.club_id, e.created_by, e.title, e.description, e.location,
         e.category, e.poster_url, e.capacity, e.status, e.starts_at, e.ends_at,
         e.created_at, e.updated_at,
         c.name AS club_name,
         u.first_name + ' ' + u.last_name AS creator_name,
         (SELECT COUNT(*) FROM dbo.event_attendees a WHERE a.event_id = e.event_id) AS attendee_count,
         (SELECT COUNT(*) FROM dbo.event_attendees a WHERE a.event_id = e.event_id AND a.user_id = @me) AS is_registered,
         CASE
           WHEN @rol = 'admin' THEN 1
           WHEN @rol = 'club_admin' AND EXISTS (
             SELECT 1 FROM dbo.club_members m
             WHERE m.club_id = e.club_id AND m.user_id = @me AND m.is_admin = 1
           ) THEN 1
           ELSE 0
         END AS can_manage
  FROM dbo.events e
  JOIN dbo.clubs c ON c.club_id = e.club_id
  JOIN dbo.users u ON u.user_id = e.created_by
`;

function kayitDurumu(etkinlik) {
  if (etkinlik.status === 'cancelled') return 'cancelled';
  if (etkinlik.status !== 'published') return 'closed';
  if (new Date(etkinlik.starts_at) < new Date()) return 'closed';
  if (etkinlik.capacity && Number(etkinlik.attendee_count) >= Number(etkinlik.capacity)) return 'full';
  return 'open';
}

function zenginlestir(etkinlik) {
  return {
    ...etkinlik,
    is_registered: Number(etkinlik.is_registered) > 0,
    attendee_count: Number(etkinlik.attendee_count),
    registration_status: kayitDurumu(etkinlik),
    can_manage: Number(etkinlik.can_manage) === 1
  };
}

async function etkinlikGetir(id, kullanici) {
  const kayitlar = await sorguCalistir(
    `${ETKINLIK_SEC} WHERE e.event_id = @id`,
    { id, me: kullanici.user_id, rol: kullanici.role }
  );
  return kayitlar[0] || null;
}

async function katilimcilariGetir(eventId) {
  return sorguCalistir(
    `SELECT u.user_id, u.first_name, u.last_name, u.email, a.registered_at
     FROM dbo.event_attendees a
     JOIN dbo.users u ON u.user_id = a.user_id
     WHERE a.event_id = @eventId
     ORDER BY a.registered_at`,
    { eventId }
  );
}

function onemliDegisti(onceki, yeni) {
  const alanlar = ['title', 'description', 'location', 'category', 'capacity'];
  if (alanlar.some((alan) => String(onceki[alan] ?? '') !== String(yeni[alan] ?? ''))) return true;
  const onceBas = new Date(onceki.starts_at).getTime();
  const yeniBas = new Date(yeni.starts_at).getTime();
  if (onceBas !== yeniBas) return true;
  const onceBit = onceki.ends_at ? new Date(onceki.ends_at).getTime() : null;
  const yeniBit = yeni.ends_at ? new Date(yeni.ends_at).getTime() : null;
  return onceBit !== yeniBit;
}

router.get('/categories', (_req, res) => {
  res.json(KATEGORILER);
});

router.get('/', async (req, res) => {
  const clubId = req.query.club_id ? Number(req.query.club_id) : null;
  const category = metin(req.query.category, 80);
  const when = ['upcoming', 'past', 'all'].includes(req.query.when) ? req.query.when : 'all';
  const mine = req.query.mine === '1';
  const q = metin(req.query.q, 80);
  const like = q ? `%${q.replace(/[%_[\]]/g, '')}%` : null;

  const etkinlikler = await sorguCalistir(
    `${ETKINLIK_SEC}
     WHERE (@clubId IS NULL OR e.club_id = @clubId)
       AND (@category IS NULL OR e.category = @category)
       AND (
         e.status IN ('published', 'cancelled')
         OR e.created_by = @me
         OR EXISTS (
           SELECT 1 FROM dbo.club_members m
           WHERE m.club_id = e.club_id AND m.user_id = @me AND m.is_admin = 1
             AND @rol = 'club_admin'
         )
       )
       AND (
         @when = 'all'
         OR (@when = 'upcoming' AND e.starts_at >= SYSDATETIME())
         OR (@when = 'past' AND e.starts_at < SYSDATETIME())
       )
       AND (
         @mine = 0
         OR EXISTS (
           SELECT 1 FROM dbo.event_attendees a
           WHERE a.event_id = e.event_id AND a.user_id = @me
         )
       )
       AND (
         @like IS NULL
         OR e.title LIKE @like
         OR e.description LIKE @like
         OR c.name LIKE @like
         OR e.location LIKE @like
       )
     ORDER BY e.starts_at`,
    {
      clubId,
      category,
      when,
      mine: mine ? 1 : 0,
      like,
      me: req.kullanici.user_id,
      rol: req.kullanici.role
    }
  );

  res.json(etkinlikler.map((etkinlik) => zenginlestir(etkinlik)));
});

router.get('/:id', async (req, res) => {
  const etkinlik = await etkinlikGetir(Number(req.params.id), req.kullanici);
  if (!etkinlik) return res.status(404).json({ mesaj: 'Etkinlik bulunamadı.' });

  const taslak = etkinlik.status === 'draft';
  const gorebilir = !taslak || await etkinlikYonetebilirMi(etkinlik.club_id, req.kullanici);
  if (!gorebilir) return res.status(404).json({ mesaj: 'Etkinlik bulunamadı.' });

  const cevap = zenginlestir(etkinlik);
  if (cevap.can_manage) {
    cevap.attendees = await katilimcilariGetir(etkinlik.event_id);
  }
  res.json(cevap);
});

router.post('/', upload.single('poster'), async (req, res) => {
  const { hatalar, deger } = govdeOku(req.body);
  if (hatalar.length) {
    return res.status(400).json({ mesaj: hatalar[0], hatalar });
  }

  const yetkili = await etkinlikYonetebilirMi(deger.club_id, req.kullanici);
  if (!yetkili) {
    return res.status(403).json({ mesaj: 'Sadece kulüp temsilcisi kendi kulübü için etkinlik oluşturabilir.' });
  }

  const posterUrl = req.file ? `/uploads/${req.file.filename}` : null;
  const eklenen = await sorguCalistir(
    `INSERT INTO dbo.events
       (club_id, created_by, title, description, location, category, poster_url, capacity, status, starts_at, ends_at)
     OUTPUT INSERTED.event_id
     VALUES
       (@club_id, @userId, @title, @description, @location, @category, @posterUrl, @capacity, @status, @starts_at, @ends_at)`,
    { ...deger, userId: req.kullanici.user_id, posterUrl }
  );

  const etkinlik = await etkinlikGetir(eklenen[0].event_id, req.kullanici);
  let eposta = null;
  if (etkinlik.status === 'published') {
    try {
      eposta = await yeniEtkinlikBildir(etkinlik);
    } catch (hata) {
      console.error('Yeni etkinlik e-postası başarısız:', hata.message);
      eposta = { failed: 1 };
    }
  }

  res.status(201).json({
    mesaj: 'Etkinlik kaydedildi.',
    event: zenginlestir(etkinlik),
    eposta
  });
});

router.put('/:id', upload.single('poster'), async (req, res) => {
  const id = Number(req.params.id);
  const onceki = await etkinlikGetir(id, req.kullanici);
  if (!onceki) return res.status(404).json({ mesaj: 'Etkinlik bulunamadı.' });

  const yetkili = await etkinlikYonetebilirMi(onceki.club_id, req.kullanici);
  if (!yetkili) return res.status(403).json({ mesaj: 'Bu etkinliği düzenleme yetkiniz yok.' });

  const birlesik = {
    club_id: req.body.club_id ?? onceki.club_id,
    title: req.body.title ?? onceki.title,
    description: req.body.description ?? onceki.description,
    location: req.body.location ?? onceki.location,
    category: req.body.category ?? onceki.category,
    starts_at: req.body.starts_at ?? onceki.starts_at,
    ends_at: req.body.ends_at ?? onceki.ends_at,
    capacity: req.body.capacity === undefined || req.body.capacity === '' ? onceki.capacity : req.body.capacity,
    status: req.body.status ?? onceki.status
  };
  const { hatalar, deger } = govdeOku(birlesik);
  if (hatalar.length) return res.status(400).json({ mesaj: hatalar[0], hatalar });

  if (!(await etkinlikYonetebilirMi(deger.club_id, req.kullanici))) {
    return res.status(403).json({ mesaj: 'Etkinliği başka bir kulübe taşıyamazsınız.' });
  }

  const posterUrl = req.file ? `/uploads/${req.file.filename}` : onceki.poster_url;
  await sorguCalistir(
    `UPDATE dbo.events SET
       club_id = @club_id,
       title = @title,
       description = @description,
       location = @location,
       category = @category,
       poster_url = @posterUrl,
       capacity = @capacity,
       status = @status,
       starts_at = @starts_at,
       ends_at = @ends_at,
       updated_at = SYSDATETIME()
     WHERE event_id = @id`,
    { ...deger, posterUrl, id }
  );

  const etkinlik = await etkinlikGetir(id, req.kullanici);
  let eposta = null;
  try {
    const katilimcilar = await katilimcilariGetir(id);
    if (onceki.status !== 'cancelled' && etkinlik.status === 'cancelled') {
      eposta = await iptalBildir(etkinlik, katilimcilar);
    } else if (etkinlik.status === 'published' && onceki.status === 'draft') {
      eposta = await yeniEtkinlikBildir(etkinlik);
    } else if (etkinlik.status === 'published' && onemliDegisti(onceki, etkinlik)) {
      eposta = await guncellemeBildir(etkinlik, katilimcilar);
    }
  } catch (hata) {
    console.error('Güncelleme e-postası başarısız:', hata.message);
    eposta = { failed: 1 };
  }

  const cevap = zenginlestir(etkinlik);
  cevap.attendees = await katilimcilariGetir(id);
  res.json({ mesaj: 'Etkinlik güncellendi.', event: cevap, eposta });
});

router.delete('/:id', async (req, res) => {
  const id = Number(req.params.id);
  const etkinlik = await etkinlikGetir(id, req.kullanici);
  if (!etkinlik) return res.status(404).json({ mesaj: 'Etkinlik bulunamadı.' });

  const yetkili = await etkinlikYonetebilirMi(etkinlik.club_id, req.kullanici);
  if (!yetkili) return res.status(403).json({ mesaj: 'Bu etkinliği silme yetkiniz yok.' });

  let eposta = null;
  try {
    if (etkinlik.status !== 'cancelled') {
      const katilimcilar = await katilimcilariGetir(id);
      eposta = await iptalBildir({ ...etkinlik, status: 'cancelled' }, katilimcilar);
    }
  } catch (hata) {
    console.error('İptal e-postası başarısız:', hata.message);
    eposta = { failed: 1 };
  }

  await sorguCalistir('DELETE FROM dbo.events WHERE event_id = @id', { id });
  res.json({ mesaj: 'Etkinlik silindi.', eposta });
});

router.post('/:id/register', async (req, res) => {
  const eventId = Number(req.params.id);
  const userId = req.kullanici.user_id;
  const etkinlik = await etkinlikGetir(eventId, req.kullanici);
  if (!etkinlik || etkinlik.status === 'draft') {
    return res.status(404).json({ mesaj: 'Etkinlik bulunamadı.' });
  }
  if (kayitDurumu(etkinlik) === 'cancelled') {
    return res.status(400).json({ mesaj: 'İptal edilen etkinliğe kayıt olunamaz.' });
  }
  if (kayitDurumu(etkinlik) === 'closed') {
    return res.status(400).json({ mesaj: 'Bu etkinliğin kayıtları kapalı.' });
  }
  if (kayitDurumu(etkinlik) === 'full') {
    return res.status(409).json({ mesaj: 'Kontenjan doldu.' });
  }

  const eklenen = await sorguCalistir(
    `INSERT INTO dbo.event_attendees (event_id, user_id)
     OUTPUT INSERTED.user_id
     SELECT @eventId, @userId
     WHERE NOT EXISTS (
       SELECT 1 FROM dbo.event_attendees WHERE event_id = @eventId AND user_id = @userId
     )
     AND EXISTS (
       SELECT 1 FROM dbo.events e
       WHERE e.event_id = @eventId
         AND e.status = 'published'
         AND e.starts_at >= SYSDATETIME()
         AND (e.capacity IS NULL OR (
           SELECT COUNT(*) FROM dbo.event_attendees a WHERE a.event_id = e.event_id
         ) < e.capacity)
     )`,
    { eventId, userId }
  );

  if (eklenen.length === 0) {
    return res.status(409).json({ mesaj: 'Kayıt oluşturulamadı. Kontenjan dolmuş veya zaten kayıtlı olabilirsiniz.' });
  }

  const guncel = await etkinlikGetir(eventId, req.kullanici);
  let eposta = null;
  try {
    eposta = await kayitOnayiBildir(guncel, {
      user_id: userId,
      email: req.kullanici.email,
      first_name: req.kullanici.first_name
    });
  } catch (hata) {
    console.error('Kayıt e-postası başarısız:', hata.message);
    eposta = { failed: 1 };
  }

  res.status(201).json({ mesaj: 'Etkinliğe kayıt oldunuz.', event: zenginlestir(guncel), eposta });
});

router.delete('/:id/register', async (req, res) => {
  await sorguCalistir(
    'DELETE FROM dbo.event_attendees WHERE event_id = @eventId AND user_id = @userId',
    { eventId: Number(req.params.id), userId: req.kullanici.user_id }
  );
  res.json({ mesaj: 'Kaydınız iptal edildi.' });
});

router.get('/:id/attendees', async (req, res) => {
  const etkinlik = await etkinlikGetir(Number(req.params.id), req.kullanici);
  if (!etkinlik) return res.status(404).json({ mesaj: 'Etkinlik bulunamadı.' });
  if (!(await etkinlikYonetebilirMi(etkinlik.club_id, req.kullanici))) {
    return res.status(403).json({ mesaj: 'Katılımcı listesini yalnızca kulüp temsilcisi görebilir.' });
  }
  res.json(await katilimcilariGetir(etkinlik.event_id));
});

module.exports = router;
