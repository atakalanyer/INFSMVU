/* =====================================================================
   FSMVU Kampus Sosyal Agi — Sema Guncelleme (Migration v2)
   Mevcut tablolara frontend'in ihtiyac duydugu eksik alanlari ekler.
   SSMS'te yeni bir sorgu penceresi acip tamamini F5 ile calistirin.
   ===================================================================== */

USE FSMVU_CampusNet;
GO

/* ---------------------------------------------------------------------
   1. dbo.projects tablosuna eksik alanlari ekle
      Frontend beklentileri: summary, goal, project_type, technologies,
      deliverables, looking_for (JSON verisi olarak)
   --------------------------------------------------------------------- */

-- summary: Kisa proje ozeti (kart uzerinde gosterilir)
IF COL_LENGTH('dbo.projects', 'summary') IS NULL
BEGIN
    ALTER TABLE dbo.projects ADD summary NVARCHAR(500) NULL;
    PRINT 'projects.summary eklendi.';
END
GO

-- goal: Projenin amaci
IF COL_LENGTH('dbo.projects', 'goal') IS NULL
BEGIN
    ALTER TABLE dbo.projects ADD goal NVARCHAR(MAX) NULL;
    PRINT 'projects.goal eklendi.';
END
GO

-- project_type: Proje turu (TEKNOFEST, Bitirme Projesi, Akademik, Girisim)
IF COL_LENGTH('dbo.projects', 'project_type') IS NULL
BEGIN
    ALTER TABLE dbo.projects ADD project_type NVARCHAR(80) NULL;
    PRINT 'projects.project_type eklendi.';
END
GO

-- technologies: Virgul ayirmali teknoloji listesi veya JSON dizisi
IF COL_LENGTH('dbo.projects', 'technologies') IS NULL
BEGIN
    ALTER TABLE dbo.projects ADD technologies NVARCHAR(MAX) NULL;
    PRINT 'projects.technologies eklendi.';
END
GO

-- deliverables: Beklenen ciktilar (JSON dizisi)
IF COL_LENGTH('dbo.projects', 'deliverables') IS NULL
BEGIN
    ALTER TABLE dbo.projects ADD deliverables NVARCHAR(MAX) NULL;
    PRINT 'projects.deliverables eklendi.';
END
GO

-- looking_for: Aranan roller (JSON dizisi)
IF COL_LENGTH('dbo.projects', 'looking_for') IS NULL
BEGIN
    ALTER TABLE dbo.projects ADD looking_for NVARCHAR(MAX) NULL;
    PRINT 'projects.looking_for eklendi.';
END
GO

-- image_url: Proje gorsel URL'si
IF COL_LENGTH('dbo.projects', 'image_url') IS NULL
BEGIN
    ALTER TABLE dbo.projects ADD image_url VARCHAR(500) NULL;
    PRINT 'projects.image_url eklendi.';
END
GO

-- tags: Yetenek/teknoloji etiketleri (JSON dizisi)
IF COL_LENGTH('dbo.projects', 'tags') IS NULL
BEGIN
    ALTER TABLE dbo.projects ADD tags NVARCHAR(MAX) NULL;
    PRINT 'projects.tags eklendi.';
END
GO

/* ---------------------------------------------------------------------
   2. dbo.profiles tablosuna eksik alanlari ekle
   --------------------------------------------------------------------- */

-- headline: Profil basligi (ornegin "Full-stack gelistirici · FSMVU")
IF COL_LENGTH('dbo.profiles', 'headline') IS NULL
BEGIN
    ALTER TABLE dbo.profiles ADD headline NVARCHAR(200) NULL;
    PRINT 'profiles.headline eklendi.';
END
GO

/* ---------------------------------------------------------------------
   3. Indeksler (performans iyilestirme)
   --------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_projects_owner' AND object_id = OBJECT_ID('dbo.projects'))
BEGIN
    CREATE INDEX IX_projects_owner ON dbo.projects(owner_id);
    PRINT 'IX_projects_owner indeksi eklendi.';
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_projects_type' AND object_id = OBJECT_ID('dbo.projects'))
BEGIN
    CREATE INDEX IX_projects_type ON dbo.projects(project_type);
    PRINT 'IX_projects_type indeksi eklendi.';
END
GO

PRINT '--- Migration v2 tamamlandi. ---';
GO
