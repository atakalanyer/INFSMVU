require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const bcrypt = require('bcryptjs');
const { sorguCalistir } = require('../db');

const PAROLA = 'Fsm12345';

async function kullaniciEkle(kisi) {
  const mevcut = await sorguCalistir('SELECT user_id FROM dbo.users WHERE email = @email', { email: kisi.email });
  if (mevcut.length) return mevcut[0].user_id;

  const bolum = await sorguCalistir('SELECT department_id FROM dbo.departments WHERE name = @name', { name: kisi.department });
  const sifreHash = await bcrypt.hash(PAROLA, 10);
  const eklenen = await sorguCalistir(
    `INSERT INTO dbo.users
       (email, password_hash, first_name, last_name, role, department_id, degree, class_year, is_email_verified, is_active)
     OUTPUT INSERTED.user_id
     VALUES
       (@email, @sifreHash, @first_name, @last_name, @role, @department_id, @degree, @class_year, 1, 1)`,
    {
      email: kisi.email,
      sifreHash,
      first_name: kisi.first_name,
      last_name: kisi.last_name,
      role: kisi.role,
      department_id: bolum[0] ? bolum[0].department_id : null,
      degree: kisi.degree || null,
      class_year: kisi.class_year || null
    }
  );
  const userId = eklenen[0].user_id;
  await sorguCalistir('INSERT INTO dbo.profiles (user_id, bio) VALUES (@userId, @bio)', {
    userId,
    bio: kisi.bio
  });
  return userId;
}

async function main() {
  const ogrenci = await kullaniciEkle({
    email: 'elif.kaya@stu.fsm.edu.tr',
    first_name: 'Elif',
    last_name: 'Kaya',
    role: 'student',
    department: 'Bilgisayar Programcılığı',
    degree: 'on_lisans',
    class_year: 2,
    bio: 'FSMVÜ öğrencisi'
  });

  const temsilci = await kullaniciEkle({
    email: 'mehmetali.demir@stu.fsm.edu.tr',
    first_name: 'Mehmet Ali',
    last_name: 'Demir',
    role: 'club_admin',
    department: 'Bilgisayar Mühendisliği',
    degree: 'lisans',
    class_year: 3,
    bio: 'Bilişim kulübü temsilcisi'
  });

  const akademisyen = await kullaniciEkle({
    email: 'zeynep.aydin@fsm.edu.tr',
    first_name: 'Zeynep',
    last_name: 'Aydın',
    role: 'academic',
    department: 'Bilgisayar Mühendisliği',
    bio: 'Kulüp danışmanı'
  });

  await kullaniciEkle({
    email: 'admin@fsm.edu.tr',
    first_name: 'Sistem',
    last_name: 'Yöneticisi',
    role: 'admin',
    department: 'Bilgisayar Mühendisliği',
    bio: 'Yerel yönetici hesabı. Kulüp temsilcisi yetkisi yalnızca bu hesapla verilir.'
  });

  const kulupler = await sorguCalistir(
    `SELECT club_id FROM dbo.clubs WHERE name = @name`,
    { name: 'Bilişim ve Yazılım Kulübü' }
  );
  let clubId = kulupler[0] && kulupler[0].club_id;
  if (!clubId) {
    const eklenen = await sorguCalistir(
      `INSERT INTO dbo.clubs (name, description, advisor_id)
       OUTPUT INSERTED.club_id
       VALUES (@name, @description, @advisor)`,
      {
        name: 'Bilişim ve Yazılım Kulübü',
        description: 'FSMVÜ öğrencilerine yönelik teknik etkinlikler düzenler.',
        advisor: akademisyen
      }
    );
    clubId = eklenen[0].club_id;
  }

  const uyelik = await sorguCalistir(
    'SELECT 1 AS var FROM dbo.club_members WHERE club_id = @clubId AND user_id = @userId',
    { clubId, userId: temsilci }
  );
  if (!uyelik.length) {
    await sorguCalistir(
      'INSERT INTO dbo.club_members (club_id, user_id, is_admin) VALUES (@clubId, @userId, 1)',
      { clubId, userId: temsilci }
    );
  }

  const etkinlik = await sorguCalistir(
    `SELECT event_id FROM dbo.events WHERE title = @title`,
    { title: 'Kampüs Yazılım Buluşması' }
  );
  if (!etkinlik.length) {
    const baslangic = new Date();
    baslangic.setDate(baslangic.getDate() + 14);
    baslangic.setHours(14, 0, 0, 0);
    const bitis = new Date(baslangic.getTime() + 2 * 60 * 60 * 1000);
    await sorguCalistir(
      `INSERT INTO dbo.events
         (club_id, created_by, title, description, location, category, capacity, status, starts_at, ends_at)
       VALUES
         (@clubId, @userId, @title, @description, @location, @category, @capacity, 'published', @starts, @ends)`,
      {
        clubId,
        userId: temsilci,
        title: 'Kampüs Yazılım Buluşması',
        description: 'Öğrenci projeleri, kulüp duyuruları ve dönem etkinlik takvimi konuşulacak.',
        location: 'Haliç Yerleşkesi, Konferans Salonu',
        category: 'Seminer & Konferans',
        capacity: 80,
        starts: baslangic,
        ends: bitis
      }
    );
  }

  console.log('Örnek hesaplar hazır. Parola:', PAROLA);
  console.log('Öğrenci:', ogrenci, 'Temsilci:', temsilci, 'Kulüp:', clubId);
  process.exit(0);
}

main().catch((hata) => {
  console.error(hata);
  process.exit(1);
});
