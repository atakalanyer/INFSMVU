const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const sql = require('mssql');

(async () => {
  const config = {
    server: 'localhost',
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    options: {
      encrypt: false,
      trustServerCertificate: true
    }
  };

  try {
    const pool = await sql.connect(config);
    console.log('Connected to FSMVU_CampusNet successfully!');
    
    // Check tables
    const tables = await pool.request().query(`
      SELECT TABLE_NAME 
      FROM INFORMATION_SCHEMA.TABLES 
      WHERE TABLE_TYPE = 'BASE TABLE'
      ORDER BY TABLE_NAME
    `);
    console.log('Existing Tables:', tables.recordset.map(t => t.TABLE_NAME));

    // Check columns of dbo.projects
    const projCols = await pool.request().query(`
      SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_NAME = 'projects'
      ORDER BY ORDINAL_POSITION
    `);
    console.log('\nColumns of dbo.projects:');
    console.table(projCols.recordset);

    // Check users count
    const users = await pool.request().query('SELECT COUNT(*) AS total_users FROM dbo.users');
    console.log('Users count:', users.recordset[0].total_users);

    await pool.close();
  } catch (err) {
    console.error('Error:', err.message);
  }
})();
