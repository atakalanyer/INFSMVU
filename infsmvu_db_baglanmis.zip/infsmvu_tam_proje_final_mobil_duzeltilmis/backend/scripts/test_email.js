const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const { epostaGonder } = require('../utils/mailer');

(async () => {
  console.log('Sending live test email via Gmail SMTP...');
  const res = await epostaGonder({
    to: 'infsmvu@gmail.com',
    subject: 'INFSMVU - Canlı Test Bildirimi',
    text: 'Bu bir test e-postasıdır. INFSMVU Gmail SMTP entegrasyonu başarıyla doğrulanmıştır!',
    html: '<h3>INFSMVU - FSMVÜ Proje Ağı</h3><p>Bu bir test e-postasıdır. <b>Gmail SMTP entegrasyonu başarıyla doğrulanmıştır!</b></p>'
  });
  console.log('Sonuç:', res);
})();
