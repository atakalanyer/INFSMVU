const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
const sql = require('mssql');

const serversToTry = [
  'localhost\\SQLEXPRESS',
  '.\\SQLEXPRESS',
  '127.0.0.1\\SQLEXPRESS',
  'localhost'
];

(async () => {
  for (const s of serversToTry) {
    console.log('\nTrying server:', s);
    const config = {
      server: s,
      database: process.env.DB_NAME,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      options: {
        encrypt: false,
        trustServerCertificate: true
      }
    };
    try {
      const pool = await sql.connect(config);
      console.log('SUCCESS! Connected to:', s);
      const res = await pool.request().query('SELECT DB_NAME() AS current_db');
      console.log('DB Name query:', res.recordset);
      await pool.close();
      break;
    } catch (err) {
      console.log('FAILED to connect to', s, ':', err.message);
    }
  }
})();
