# FSMVÜ Proje Ağı — Frontend

Fatih Sultan Mehmet Vakıf Üniversitesi öğrencileri ve akademisyenleri için proje iş birliği ve akademik ağ platformunun
**web arayüzü** (masaüstü / tablet / mobil tarayıcıya duyarlı). React + Vite, düz modern CSS, React Router.

## Çalıştırma

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # üretim derlemesi (dist/)
```

## Demo hesaplar (parola: `Fsm12345`)

| Rol              | E-posta                          |
| ---------------- | -------------------------------- |
| Öğrenci          | elif.kaya@stu.fsm.edu.tr         |
| Kulüp Temsilcisi | mehmetali.demir@stu.fsm.edu.tr   |
| Akademisyen      | zeynep.aydin@fsm.edu.tr          |

Giriş ekranındaki "demo hesap" butonları e-postayı ve parolayı otomatik doldurur.
OTP kodu e-posta gönderilmediği için doğrulama ekranında gösterilir (simülasyon).

## Rotalar

| Yol                | Sayfa                                              |
| ------------------ | -------------------------------------------------- |
| `/giris`           | Giriş / Kayıt + OTP doğrulama                      |
| `/`                | Ana akış (Feed)                                    |
| `/kesfet`          | Keşfet & takım arkadaşı eşleşme filtreleri         |
| `/proje/:id`       | Proje detayı, takıma katıl / iletişime geç modalı  |
| `/profil`          | Kendi portfolyon (düzenlenebilir)                  |
| `/profil/:userId`  | Başka bir kullanıcının portfolyosu                 |
| `/yeni-proje`      | Yeni proje paylaşma formu + canlı kart önizlemesi  |

## Klasör yapısı

```
src/
├── main.jsx · App.jsx
├── styles/         global.css (tasarım token'ları, auth, layout, feed) · pages.css (keşfet, detay, profil, modal)
├── services/       mockData.js · authService.js
├── context/        AuthContext · PostsContext
├── hooks/          useProjectFilters.js   (filtreler URL'de tutulur)
├── utils/          validators.js · filterProjects.js · format.js
├── components/
│   ├── common/     Icon · Avatar · ProjectImage · RoleBadge · Modal · ProtectedRoute
│   ├── auth/       FormField · RoleSelector · OtpInput
│   ├── layout/     AppLayout · Sidebar · Topbar · BottomNav
│   ├── feed/       PostCard · CommentSection · RightPanel
│   ├── explore/    FilterPanel · ActiveFilters · ProjectCard
│   ├── project/    ApplyModal
│   └── profile/    EditProfileModal
└── pages/          AuthPage · FeedPage · ExplorePage · ProjectDetailPage · ProfilePage · NewProjectPage
```

## Backend'e geçiş

Tüm veri `src/services/mockData.js` ve `authService.js` üzerinden gelir. Kullanıcı etkileşimleri
(beğeni, kayıt, başvuru, paylaşılan projeler, profil düzenlemeleri) `localStorage`'da tutulur.
Gerçek API hazır olduğunda `authService.js` içindeki fonksiyonlar ve `PostsContext` içindeki veri okuma/yazma
noktaları değiştirilir; bileşenler aynı kalır.

## Not

Kişi, proje ve fakülte/bölüm verileri kurgusaldır. Görseller `picsum.photos` ve `i.pravatar.cc` üzerinden gelir;
erişilemezse baş harf avatarı ve gradyan yedekleri devreye girer.
