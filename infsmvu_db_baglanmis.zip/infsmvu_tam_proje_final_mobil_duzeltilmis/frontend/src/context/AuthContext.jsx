import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { toSessionUser } from '../services/authService';
import { usersApi } from '../services/api';

const SESSION_KEY = 'fsmvu_session_user';
const TOKEN_KEY = 'token';
const AuthContext = createContext(null);

function readSession() {
  try {
    return JSON.parse(localStorage.getItem(SESSION_KEY));
  } catch {
    return null;
  }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(readSession);
  const [userCache, setUserCache] = useState({});

  // Sayfa açıldığında token varsa backend'den güncel profili doğrula
  useEffect(() => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (!token) return;

    usersApi
      .getMe()
      .then((profile) => {
        const sessionUser = toSessionUser(profile);
        setUser(sessionUser);
        localStorage.setItem(SESSION_KEY, JSON.stringify(sessionUser));
      })
      .catch(() => {
        // Token geçersizse temizle
        localStorage.removeItem(TOKEN_KEY);
        localStorage.removeItem(SESSION_KEY);
        setUser(null);
      });
  }, []);

  const signIn = useCallback((account, token) => {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    const sessionUser = toSessionUser(account);
    setUser(sessionUser);
    localStorage.setItem(SESSION_KEY, JSON.stringify(sessionUser));
  }, []);

  const signOut = useCallback(() => {
    setUser(null);
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(SESSION_KEY);
  }, []);

  /** Profil alanlarını günceller (backend ve yerel oturum). */
  const updateProfile = useCallback(async (patch) => {
    try {
      const updated = await usersApi.updateMe(patch);
      const sessionUser = toSessionUser(updated);
      setUser(sessionUser);
      localStorage.setItem(SESSION_KEY, JSON.stringify(sessionUser));
      return sessionUser;
    } catch (err) {
      console.error('Profil güncellenemedi:', err);
      throw err;
    }
  }, []);

  /** Kullanıcı profili getirir; oturumdaki kullanıcı doğrudan döner veya backend'den çekilir. */
  const getUser = useCallback(
    async (id) => {
      const numericId = Number(id);
      if (user && (user.id === numericId || user.user_id === numericId)) {
        return user;
      }
      if (userCache[numericId]) {
        return userCache[numericId];
      }

      try {
        const fetched = await usersApi.getById(numericId);
        const transformed = toSessionUser(fetched);
        setUserCache((prev) => ({ ...prev, [numericId]: transformed }));
        return transformed;
      } catch {
        return null;
      }
    },
    [user, userCache]
  );

  const value = useMemo(
    () => ({
      user,
      isAuthenticated: Boolean(user && localStorage.getItem(TOKEN_KEY)),
      signIn,
      signOut,
      updateProfile,
      getUser,
    }),
    [user, signIn, signOut, updateProfile, getUser]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth, AuthProvider içinde kullanılmalıdır.');
  return ctx;
}
