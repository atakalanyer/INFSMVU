import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { projectsApi, postsApi } from '../services/api';
import { useAuth } from './AuthContext';

const SAVED_KEY = 'fsmvu_saved_projects';
const PostsContext = createContext(null);

function readSaved() {
  try {
    return JSON.parse(localStorage.getItem(SAVED_KEY)) || [];
  } catch {
    return [];
  }
}

/**
 * Backend'den gelen proje verisini frontend bileşenlerinin beklediği zengin formata dönüştürür.
 */
export function transformProject(p) {
  if (!p) return null;
  const id = p.project_id;
  const isRecruiting = p.status === 'open';

  return {
    id: String(id),
    project_id: id,
    title: p.title || 'Başlıksız Proje',
    summary: p.summary || p.description?.slice(0, 160) || 'Proje özeti bulunmuyor.',
    description: p.description || '',
    goal: p.goal || 'Proje amacı belirtilmemiş.',
    type: p.project_type || p.category || 'Bağımsız Girişim',
    category: p.category || 'Genel',
    status: isRecruiting ? 'Takım Arıyor' : p.status === 'in_progress' ? 'Devam Ediyor' : p.status === 'completed' ? 'Tamamlandı' : 'Kapalı',
    rawStatus: p.status,
    department: p.department || 'FSMVÜ',
    ownerId: p.owner_id,
    ownerName: p.owner_name || 'FSMVÜ Kullanıcısı',
    image: p.image_url || `https://picsum.photos/seed/fsm-proj-${id}/960/600`,
    tags: Array.isArray(p.tags) ? p.tags : [],
    technologies: Array.isArray(p.technologies) ? p.technologies : [],
    deliverables: Array.isArray(p.deliverables) ? p.deliverables : ['Çalışan prototip', 'Proje dokümantasyonu'],
    lookingFor: Array.isArray(p.looking_for) ? p.looking_for : [],
    team: Array.isArray(p.members)
      ? p.members.map((m) => ({
          userId: m.user_id,
          name: `${m.first_name} ${m.last_name}`,
          role: m.role === 'owner' ? 'Proje Sahibi' : m.role === 'advisor' ? 'Danışman' : 'Ekip Üyesi',
        }))
      : [{ userId: p.owner_id, role: 'Proje Sahibi', name: p.owner_name }],
    requiredSkills: Array.isArray(p.required_skills) ? p.required_skills : [],
    maxMembers: p.max_members || 5,
    memberCount: p.member_count || 1,
    likes: p.like_count || 0,
    comments: [],
    createdAt: p.created_at || new Date().toISOString(),
  };
}

export function PostsProvider({ children }) {
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [savedIds, setSavedIds] = useState(readSaved);
  const [likedIds, setLikedIds] = useState([]);
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    try {
      localStorage.setItem(SAVED_KEY, JSON.stringify(savedIds));
    } catch {
      /* ignore */
    }
  }, [savedIds]);

  const loadPosts = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await projectsApi.getAll();
      const list = Array.isArray(data) ? data.map(transformProject) : [];
      setPosts(list);
    } catch (err) {
      console.error('Projeler yüklenirken hata:', err);
      setError(err.message || 'Projeler yüklenemedi.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPosts();
  }, [loadPosts]);

  const toggleSave = useCallback((id) => {
    const stringId = String(id);
    setSavedIds((prev) =>
      prev.includes(stringId) ? prev.filter((x) => x !== stringId) : [...prev, stringId]
    );
  }, []);

  const toggleLike = useCallback(
    async (id) => {
      const stringId = String(id);
      const isCurrentlyLiked = likedIds.includes(stringId);

      // İyimser arayüz güncellemesi
      setLikedIds((prev) =>
        isCurrentlyLiked ? prev.filter((x) => x !== stringId) : [...prev, stringId]
      );
      setPosts((prev) =>
        prev.map((p) =>
          p.id === stringId ? { ...p, likes: Math.max(0, p.likes + (isCurrentlyLiked ? -1 : 1)) } : p
        )
      );

      try {
        if (isCurrentlyLiked) {
          await postsApi.unlike(id);
        } else {
          await postsApi.like(id);
        }
      } catch (err) {
        // Hata durumunda geri al
        console.warn('Beğeni işlemi başarısız:', err.message);
      }
    },
    [likedIds]
  );

  const addComment = useCallback(
    async (postId, content) => {
      if (!content || !content.trim()) return;
      try {
        await postsApi.addComment(postId, content.trim());
      } catch (err) {
        console.error('Yorum eklenemedi:', err);
        throw err;
      }
    },
    []
  );

  const sendApplication = useCallback(
    async ({ projectId, message, role }) => {
      const numericId = Number(projectId);
      const note = role ? `[Rol: ${role}] ${message || ''}` : message || '';
      const res = await projectsApi.apply(numericId, note);
      setApplications((prev) => [
        ...prev,
        { projectId: String(projectId), message: note, status: 'pending', applicantId: user?.id },
      ]);
      return res;
    },
    [user]
  );

  const hasApplied = useCallback(
    (projectId) => {
      const strId = String(projectId);
      return applications.some((a) => String(a.projectId) === strId);
    },
    [applications]
  );

  const value = useMemo(
    () => ({
      posts,
      loading,
      error,
      refreshPosts: loadPosts,
      savedIds,
      likedIds,
      isLiked: (id) => likedIds.includes(String(id)),
      isSaved: (id) => savedIds.includes(String(id)),
      toggleLike,
      toggleSave,
      addComment,
      sendApplication,
      hasApplied,
    }),
    [posts, loading, error, loadPosts, savedIds, likedIds, toggleLike, toggleSave, addComment, sendApplication, hasApplied]
  );

  return <PostsContext.Provider value={value}>{children}</PostsContext.Provider>;
}

export function usePosts() {
  const ctx = useContext(PostsContext);
  if (!ctx) throw new Error('usePosts, PostsProvider içinde kullanılmalıdır.');
  return ctx;
}
