import { ROLES } from '../services/mockData';

/**
 * Kurumsal e-posta kuralları
 *  - Öğrenci ve Kulüp Temsilcisi → @stu.fsm.edu.tr
 *  - Akademisyen                 → @fsm.edu.tr
 * Alt alan adı (stu.) zorunlu/yasaktır; iki uzantı birbirine karıştırılamaz.
 */
const LOCAL_PART = '[a-z0-9]+(?:[._-][a-z0-9]+)*';

export const STUDENT_EMAIL_REGEX = new RegExp(`^${LOCAL_PART}@stu\\.fsm\\.edu\\.tr$`, 'i');
export const ACADEMIC_EMAIL_REGEX = new RegExp(`^${LOCAL_PART}@fsm\\.edu\\.tr$`, 'i');

export const requiredDomainForRole = (role) =>
  role === ROLES.ACADEMIC ? '@fsm.edu.tr' : '@stu.fsm.edu.tr';

/** E-posta uzantısından rol grubunu tahmin eder: 'student' | 'academic' | null */
export function detectRoleGroupFromEmail(email = '') {
  const value = email.trim();
  if (STUDENT_EMAIL_REGEX.test(value)) return 'student';
  if (ACADEMIC_EMAIL_REGEX.test(value)) return 'academic';
  return null;
}

/** @returns {{ valid: boolean, message: string }} */
export function validateInstitutionalEmail(email, role) {
  const value = (email || '').trim();

  if (!value) return { valid: false, message: 'E-posta adresi zorunludur.' };
  if (!value.includes('@')) return { valid: false, message: 'Geçerli bir e-posta adresi girin.' };

  const group = detectRoleGroupFromEmail(value);
  const expectedGroup = role === ROLES.ACADEMIC ? 'academic' : 'student';

  if (group === expectedGroup) return { valid: true, message: '' };

  if (group === null) {
    return {
      valid: false,
      message: `Yalnızca kurumsal e-posta kabul edilir (${requiredDomainForRole(role)}).`,
    };
  }

  // Uzantı geçerli ama seçilen role uymuyor
  return {
    valid: false,
    message:
      role === ROLES.ACADEMIC
        ? 'Akademisyen hesapları için @fsm.edu.tr uzantısı gerekir.'
        : 'Öğrenci ve kulüp temsilcisi hesapları için @stu.fsm.edu.tr uzantısı gerekir.',
  };
}

export function validatePassword(password) {
  if (!password) return { valid: false, message: 'Parola zorunludur.' };
  if (password.length < 8) return { valid: false, message: 'Parola en az 8 karakter olmalıdır.' };
  if (!/[A-Za-zÇĞİÖŞÜçğıöşü]/.test(password) || !/\d/.test(password)) {
    return { valid: false, message: 'Parola en az bir harf ve bir rakam içermelidir.' };
  }
  return { valid: true, message: '' };
}

export function validateFullName(name) {
  const value = (name || '').trim();
  if (value.length < 3 || !value.includes(' ')) {
    return { valid: false, message: 'Ad ve soyadınızı birlikte girin.' };
  }
  return { valid: true, message: '' };
}
