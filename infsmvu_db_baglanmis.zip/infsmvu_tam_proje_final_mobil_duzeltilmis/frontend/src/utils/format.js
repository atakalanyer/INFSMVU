/** "3 saat önce" gibi göreli zaman metni üretir. */
export function timeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return 'şimdi';
  if (minutes < 60) return `${minutes} dk önce`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} sa önce`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days} gün önce`;
  const weeks = Math.floor(days / 7);
  if (weeks < 5) return `${weeks} hf önce`;
  return new Date(iso).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long' });
}

/** İsimden baş harfleri çıkarır (unvanları atlar). */
export function getInitials(name = '') {
  const skip = new Set(['prof.', 'doç.', 'dr.', 'öğr.', 'üyesi']);
  const parts = name
    .split(' ')
    .filter(Boolean)
    .filter((p) => !skip.has(p.toLocaleLowerCase('tr-TR')));
  const first = parts[0]?.[0] || '';
  const last = parts.length > 1 ? parts[parts.length - 1][0] : '';
  return (first + last).toLocaleUpperCase('tr-TR');
}

/** Sayıyı 1,2 B / 3,4 K biçiminde kısaltır. */
export function compactNumber(n) {
  if (n >= 1000) return `${(n / 1000).toFixed(1).replace('.', ',')} B`;
  return String(n);
}

/** İsimden sabit bir renk indeksi üretir (avatar yedek rengi). */
export function colorFromString(value = '') {
  const palette = ['#1a2a44', '#2b6cb0', '#0f766e', '#4a5fc1', '#7a4fb5', '#b45309', '#0e7490'];
  let hash = 0;
  for (let i = 0; i < value.length; i += 1) hash = (hash * 31 + value.charCodeAt(i)) >>> 0;
  return palette[hash % palette.length];
}
