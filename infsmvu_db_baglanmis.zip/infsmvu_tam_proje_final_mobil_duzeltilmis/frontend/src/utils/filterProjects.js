import { FACULTIES } from '../services/mockData';

export const EMPTY_FILTERS = {
  query: '',
  skills: [],
  faculty: '',
  department: '',
  types: [],
  recruitingOnly: false,
};

const norm = (value = '') => value.toLocaleLowerCase('tr-TR');

/** Bir projenin eşleşme havuzu: etiketler + aranan rollerin yetenekleri. */
export function projectSkillPool(project = {}) {
  const tags = Array.isArray(project.tags) ? project.tags : [];
  const lookingFor = Array.isArray(project.lookingFor) ? project.lookingFor : [];
  return new Set([
    ...tags,
    ...lookingFor.flatMap((r) => (Array.isArray(r.skills) ? r.skills : []))
  ]);
}

export function countActiveFilters(filters) {
  return (
    (filters.query?.trim() ? 1 : 0) +
    (filters.skills?.length || 0) +
    (filters.faculty ? 1 : 0) +
    (filters.department ? 1 : 0) +
    (filters.types?.length || 0) +
    (filters.recruitingOnly ? 1 : 0)
  );
}

/**
 * Eşleşme algoritması:
 *  1) Arama: başlık, özet, etiket, teknoloji ve aranan rollerde anlık metin araması
 *  2) Proje türü: seçilenlerden herhangi biri
 *  3) Fakülte / Bölüm: bölüm seçiliyse bölüm, yoksa fakültedeki bölümlerden biri
 *  4) Yetenek: seçilenlerden en az biri eşleşmeli; daha çok eşleşen proje üstte sıralanır
 */
export function filterProjects(projects = [], filters = EMPTY_FILTERS) {
  const q = norm(filters.query?.trim());
  const facultyDepartments = filters.faculty
    ? FACULTIES.find((f) => f.name === filters.faculty)?.departments || []
    : null;

  const results = [];

  for (const project of projects) {
    if (!project) continue;

    const tags = Array.isArray(project.tags) ? project.tags : [];
    const tech = Array.isArray(project.technologies) ? project.technologies : [];
    const lookingFor = Array.isArray(project.lookingFor) ? project.lookingFor : [];

    if (q) {
      const haystack = norm(
        [
          project.title || '',
          project.summary || '',
          ...tags,
          ...tech,
          ...lookingFor.flatMap((r) => [r.role || '', ...(Array.isArray(r.skills) ? r.skills : [])]),
        ].join(' | ')
      );
      if (!haystack.includes(q)) continue;
    }

    if (filters.types?.length > 0 && !filters.types.includes(project.type)) continue;

    if (filters.department) {
      if (project.department !== filters.department) continue;
    } else if (facultyDepartments && !facultyDepartments.includes(project.department)) {
      continue;
    }

    // recruitingOnly kontrolü (hem frontend string 'Takım Arıyor' hem de backend 'open' desteklenir)
    if (filters.recruitingOnly) {
      const isRecruiting = project.rawStatus === 'open' || project.status === 'Takım Arıyor';
      if (!isRecruiting) continue;
    }

    const pool = projectSkillPool(project);
    const matched = (filters.skills || []).filter((s) => pool.has(s));
    if (filters.skills?.length > 0 && matched.length === 0) continue;

    results.push({ project, matched });
  }

  return results.sort(
    (a, b) =>
      b.matched.length - a.matched.length ||
      new Date(b.project.createdAt || 0).getTime() - new Date(a.project.createdAt || 0).getTime()
  );
}
