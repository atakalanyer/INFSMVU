import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { projectsApi } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostsContext';
import FormField from '../components/auth/FormField';
import Icon from '../components/common/Icon';
import ProjectCard from '../components/explore/ProjectCard';

const PROJECT_TYPES = [
  'TEKNOFEST',
  'Bitirme Projesi',
  'Akademik/Kongre Çalışması',
  'Bağımsız Girişim',
];

const SKILL_SUGGESTIONS = [
  'Flutter',
  'React',
  'Node.js',
  'Python',
  'SQL',
  'UI/UX',
  'Gömülü Sistemler',
  'Veri Analizi',
  'Siber Güvenlik',
  'Makine Öğrenmesi',
];

export default function NewProjectPage() {
  const { user } = useAuth();
  const { refreshPosts } = usePosts();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    title: '',
    summary: '',
    description: '',
    goal: '',
    type: PROJECT_TYPES[0],
    category: 'Mühendislik & Yazılım',
    status: 'open',
    max_members: 5,
    repo_url: '',
    tags: [],
    technologies: '',
    roles: [{ role: '', skill: SKILL_SUGGESTIONS[0], count: 1 }],
  });

  const [tagInput, setTagInput] = useState('');
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState('');

  const set = (key, value) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  };

  const addTag = (tag) => {
    const clean = tag.trim();
    if (!clean || form.tags.includes(clean) || form.tags.length >= 6) return;
    set('tags', [...form.tags, clean]);
    setTagInput('');
  };

  const removeTag = (tag) => {
    set('tags', form.tags.filter((t) => t !== tag));
  };

  const updateRole = (index, patch) => {
    setForm((f) => ({
      ...f,
      roles: f.roles.map((r, i) => (i === index ? { ...r, ...patch } : r)),
    }));
  };

  const addRole = () => {
    if (form.roles.length < 5) {
      set('roles', [...form.roles, { role: '', skill: SKILL_SUGGESTIONS[0], count: 1 }]);
    }
  };

  const removeRole = (index) => {
    set('roles', form.roles.filter((_, i) => i !== index));
  };

  const validate = () => {
    const next = {};
    if (form.title.trim().length < 5) next.title = 'Başlık en az 5 karakter olmalıdır.';
    if (form.summary.trim().length < 15) next.summary = 'Kısa özet en az 15 karakter olmalıdır.';
    if (form.description.trim().length < 30) next.description = 'Açıklama en az 30 karakter olmalıdır.';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError('');
    if (submitting || !validate()) return;
    setSubmitting(true);

    try {
      const techList = form.technologies
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);

      const lookingForList = form.roles
        .filter((r) => r.role.trim())
        .map((r) => ({
          role: r.role.trim(),
          skills: [r.skill],
          count: Math.max(1, Number(r.count) || 1),
        }));

      const payload = {
        title: form.title.trim(),
        summary: form.summary.trim(),
        description: form.description.trim(),
        goal: form.goal.trim(),
        project_type: form.type,
        category: form.category,
        status: form.status,
        max_members: Number(form.max_members) || 5,
        repo_url: form.repo_url.trim() || null,
        tags: form.tags,
        technologies: techList,
        deliverables: ['Proje raporu', 'Çalışır prototip'],
        looking_for: lookingForList,
      };

      const res = await projectsApi.create(payload);
      await refreshPosts();
      navigate(`/proje/${res.project_id}`);
    } catch (err) {
      console.error('Proje kaydedilemedi:', err);
      setServerError(err.message || 'Proje kaydedilirken bir hata oluştu.');
    } finally {
      setSubmitting(false);
    }
  };

  // Canlı kart önizlemesi
  const previewProject = {
    id: 'preview',
    title: form.title || 'Proje Başlığı',
    summary: form.summary || 'Proje kısa özeti kart üzerinde burada görüntülenecektir.',
    type: form.type,
    status: form.status === 'open' ? 'Takım Arıyor' : 'Devam Ediyor',
    department: user?.department || 'FSMVÜ',
    tags: form.tags,
    lookingFor: form.roles.filter((r) => r.role.trim()),
    image: `https://picsum.photos/seed/fsmvu-preview/960/600`,
    ownerName: user?.name || 'Siz',
    likes: 0,
  };

  return (
    <div className="new-project">
      <header className="explore__head">
        <div>
          <h1>Yeni Proje Paylaş</h1>
          <p>
            Bitirme tezinizi, TEKNOFEST ekibinizi veya bağımsız girişiminizi yayınlayın;
            ihtiyacınız olan yeteneklere sahip takım arkadaşları ile hemen eşleşin.
          </p>
        </div>
      </header>

      {serverError && (
        <div className="alert alert--danger card" style={{ padding: '12px 16px', color: '#c00', marginBottom: '20px' }}>
          {serverError}
        </div>
      )}

      <div className="new-project__layout" style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: '24px' }}>
        <form className="card new-project__form" onSubmit={handleSubmit} noValidate>
          <FormField
            id="np-title"
            label="Proje Başlığı"
            maxLength={110}
            placeholder="Örn: Kampüs İçi Otonom Taşıma Robotu"
            value={form.title}
            error={errors.title}
            onChange={(e) => set('title', e.target.value)}
          />

          <FormField
            id="np-summary"
            label="Kısa Özet (Kart üzerinde görünür)"
            maxLength={180}
            placeholder="Projenizi 1-2 cümleyle özetleyin..."
            value={form.summary}
            error={errors.summary}
            onChange={(e) => set('summary', e.target.value)}
          />

          <div className="form-group" style={{ marginBottom: '16px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, marginBottom: '6px' }}>
              Detaylı Açıklama
            </label>
            <textarea
              rows={5}
              placeholder="Projenin amacı, mimarisi ve çözmek istediği sorun hakkında detaylar..."
              value={form.description}
              onChange={(e) => set('description', e.target.value)}
              style={{ width: '100%', padding: '10px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
            />
            {errors.description && <span style={{ color: '#c00', fontSize: '12px' }}>{errors.description}</span>}
          </div>

          <FormField
            id="np-goal"
            label="Projenin Temel Amacı"
            placeholder="Örn: TEKNOFEST 2026 Robotaksi kategorisinde birincilik..."
            value={form.goal}
            onChange={(e) => set('goal', e.target.value)}
          />

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
            <div>
              <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, marginBottom: '6px' }}>Proje Türü</label>
              <select
                value={form.type}
                onChange={(e) => set('type', e.target.value)}
                style={{ width: '100%', padding: '10px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
              >
                {PROJECT_TYPES.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, marginBottom: '6px' }}>Durum</label>
              <select
                value={form.status}
                onChange={(e) => set('status', e.target.value)}
                style={{ width: '100%', padding: '10px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
              >
                <option value="open">Takım Arıyor (Açık İlan)</option>
                <option value="in_progress">Geliştirme Aşamasında</option>
                <option value="completed">Tamamlandı</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
            <FormField
              id="np-max"
              type="number"
              label="Maksimum Takım Büyüklüğü"
              min="1"
              max="20"
              value={form.max_members}
              onChange={(e) => set('max_members', e.target.value)}
            />

            <FormField
              id="np-repo"
              label="GitHub / Proje Bağlantısı"
              placeholder="https://github.com/..."
              value={form.repo_url}
              onChange={(e) => set('repo_url', e.target.value)}
            />
          </div>

          {/* Teknolojiler */}
          <FormField
            id="np-tech"
            label="Kullanılan Teknolojiler (Virgülle ayırın)"
            placeholder="React, ROS2, Python, OpenCV, Docker"
            value={form.technologies}
            onChange={(e) => set('technologies', e.target.value)}
          />

          {/* Etiketler */}
          <div style={{ marginBottom: '16px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, marginBottom: '6px' }}>
              Etiketler (En fazla 6 adet)
            </label>
            <div style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
              <input
                type="text"
                placeholder="Örn: YapayZeka, GömülüSistem"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addTag(tagInput); } }}
                style={{ flex: 1, padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
              />
              <button type="button" className="btn btn--outline btn--sm" onClick={() => addTag(tagInput)}>
                Ekle
              </button>
            </div>
            <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
              {form.tags.map((t) => (
                <span
                  key={t}
                  style={{
                    background: '#e2e8f0',
                    padding: '4px 10px',
                    borderRadius: '999px',
                    fontSize: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                  }}
                >
                  #{t}
                  <button type="button" onClick={() => removeTag(t)} style={{ border: 'none', background: 'none', cursor: 'pointer', fontWeight: 'bold' }}>✕</button>
                </span>
              ))}
            </div>
          </div>

          {/* Aranan Roller */}
          <div style={{ marginBottom: '24px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
              <label style={{ fontSize: '13px', fontWeight: 600 }}>Aranan Roller &amp; Yetenekler</label>
              {form.roles.length < 5 && (
                <button type="button" className="btn btn--outline btn--sm" onClick={addRole}>
                  + Rol Ekle
                </button>
              )}
            </div>

            {form.roles.map((r, i) => (
              <div key={i} style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr 60px 30px', gap: '8px', alignItems: 'center', marginBottom: '8px' }}>
                <input
                  type="text"
                  placeholder="Rol (Örn: Mobil Geliştirici)"
                  value={r.role}
                  onChange={(e) => updateRole(i, { role: e.target.value })}
                  style={{ padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                />
                <select
                  value={r.skill}
                  onChange={(e) => updateRole(i, { skill: e.target.value })}
                  style={{ padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                >
                  {SKILL_SUGGESTIONS.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
                <input
                  type="number"
                  min="1"
                  max="5"
                  value={r.count}
                  onChange={(e) => updateRole(i, { count: e.target.value })}
                  style={{ padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                />
                {form.roles.length > 1 && (
                  <button type="button" onClick={() => removeRole(i)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#c00' }}>✕</button>
                )}
              </div>
            ))}
          </div>

          <button type="submit" className="btn btn--primary" style={{ width: '100%', padding: '12px' }} disabled={submitting}>
            {submitting ? 'Proje Yayınlanıyor...' : 'Projeyi Yayınla'}
          </button>
        </form>

        {/* Canlı Önizleme */}
        <aside>
          <div style={{ position: 'sticky', top: '90px' }}>
            <h3 style={{ fontSize: '14px', color: '#64748b', marginBottom: '10px' }}>CANLI KART ÖNİZLEMESİ</h3>
            <ProjectCard project={previewProject} />
          </div>
        </aside>
      </div>
    </div>
  );
}
