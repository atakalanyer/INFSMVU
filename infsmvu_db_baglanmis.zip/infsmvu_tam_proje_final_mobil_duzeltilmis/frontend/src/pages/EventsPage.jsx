import { useState, useEffect, useMemo, useCallback } from 'react';
import { eventsApi, lookupApi } from '../services/api';
import { useAuth } from '../context/AuthContext';
import Icon from '../components/common/Icon';

export default function EventsPage() {
  const { user } = useAuth();
  const [events, setEvents] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filtreler
  const [selectedCategory, setSelectedCategory] = useState('Tümü');
  const [whenFilter, setWhenFilter] = useState('all');
  const [search, setSearch] = useState('');

  // Modal durumları
  const [activeModalEvent, setActiveModalEvent] = useState(null);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [actionError, setActionError] = useState('');

  // Yeni etkinlik formu
  const [newEvent, setNewEvent] = useState({
    club_id: '',
    title: '',
    description: '',
    location: '',
    category: '',
    capacity: 100,
    starts_at: '',
    ends_at: '',
  });
  const [posterFile, setPosterFile] = useState(null);

  // Kullanıcı yetkileri
  const isClubRepOrAdmin = user?.role === 'club_admin' || user?.role === 'admin';
  const managedClubs = user?.managed_clubs || [];

  const loadEvents = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [eventsData, catData] = await Promise.all([
        eventsApi.getAll({ when: whenFilter }),
        eventsApi.getCategories().catch(() => []),
      ]);
      setEvents(Array.isArray(eventsData) ? eventsData : []);
      if (Array.isArray(catData) && catData.length > 0) {
        setCategories(['Tümü', ...catData]);
        if (!newEvent.category) setNewEvent((prev) => ({ ...prev, category: catData[0] }));
      }
    } catch (err) {
      console.error('Etkinlikler yüklenemedi:', err);
      setError(err.message || 'Etkinlikler yüklenirken bir hata oluştu.');
    } finally {
      setLoading(false);
    }
  }, [whenFilter, newEvent.category]);

  useEffect(() => {
    loadEvents();
  }, [loadEvents]);

  // İlk yönetilen kulübü varsayılan yap
  useEffect(() => {
    if (managedClubs.length > 0 && !newEvent.club_id) {
      setNewEvent((prev) => ({ ...prev, club_id: managedClubs[0].club_id }));
    }
  }, [managedClubs, newEvent.club_id]);

  const filteredEvents = useMemo(() => {
    return events.filter((e) => {
      const matchCategory = selectedCategory === 'Tümü' || e.category === selectedCategory;
      const matchSearch =
        !search.trim() ||
        e.title?.toLowerCase().includes(search.toLowerCase()) ||
        e.description?.toLowerCase().includes(search.toLowerCase()) ||
        e.club_name?.toLowerCase().includes(search.toLowerCase()) ||
        e.location?.toLowerCase().includes(search.toLowerCase());
      return matchCategory && matchSearch;
    });
  }, [events, selectedCategory, search]);

  const handleRegister = async (eventId, isCurrentlyRegistered) => {
    setActionError('');
    try {
      if (isCurrentlyRegistered) {
        await eventsApi.unregister(eventId);
      } else {
        await eventsApi.register(eventId);
      }
      await loadEvents();
      if (activeModalEvent && activeModalEvent.event_id === eventId) {
        const updated = await eventsApi.getById(eventId);
        setActiveModalEvent(updated);
      }
    } catch (err) {
      setActionError(err.message || 'Kayıt işlemi başarısız oldu.');
    }
  };

  const handleCreateSubmit = async (e) => {
    e.preventDefault();
    setActionError('');
    setSubmitting(true);

    try {
      const formData = new FormData();
      formData.append('club_id', newEvent.club_id);
      formData.append('title', newEvent.title);
      formData.append('description', newEvent.description);
      formData.append('location', newEvent.location);
      formData.append('category', newEvent.category);
      formData.append('capacity', newEvent.capacity);
      formData.append('starts_at', newEvent.starts_at);
      if (newEvent.ends_at) formData.append('ends_at', newEvent.ends_at);
      if (posterFile) formData.append('poster', posterFile);

      await eventsApi.create(formData);
      setCreateModalOpen(false);
      setNewEvent({
        club_id: managedClubs[0]?.club_id || '',
        title: '',
        description: '',
        location: '',
        category: categories[1] || '',
        capacity: 100,
        starts_at: '',
        ends_at: '',
      });
      setPosterFile(null);
      await loadEvents();
    } catch (err) {
      setActionError(err.message || 'Etkinlik oluşturulamadı.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteEvent = async (eventId) => {
    if (!window.confirm('Bu etkinliği silmek istediğinize emin misiniz?')) return;
    try {
      await eventsApi.delete(eventId);
      setActiveModalEvent(null);
      await loadEvents();
    } catch (err) {
      alert(err.message || 'Etkinlik silinemedi.');
    }
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '—';
    try {
      return new Date(dateStr).toLocaleString('tr-TR', {
        dateStyle: 'medium',
        timeStyle: 'short',
      });
    } catch {
      return String(dateStr);
    }
  };

  return (
    <div className="events-page">
      {/* Hero Banner */}
      <section className="events-hero card">
        <div className="events-hero__content">
          <span className="events-hero__tag">
            <Icon name="sparkles" size={16} /> Kampüs Yaşamı &amp; Fırsatlar
          </span>
          <h1>FSMVÜ Kampüs Etkinlikleri &amp; Çalıştaylar</h1>
          <p>
            Cevizlibağ, Haliç ve Üsküdar kampüslerindeki hackathonlar, TEKNOFEST atölyeleri, sektör seminerleri
            ve kulüp etkinliklerini takip edin; Gmail üzerinden anında bildirim alın!
          </p>

          <div style={{ marginTop: '20px', display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
            {isClubRepOrAdmin && (
              <button
                type="button"
                className="btn btn--primary"
                onClick={() => setCreateModalOpen(true)}
              >
                <Icon name="plus" size={18} /> Yeni Kulüp Etkinliği Yayınla
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Filtre ve Arama Çubuğu */}
      <div className="events-filters-bar card">
        <div className="events-search">
          <Icon name="search" size={18} />
          <input
            type="search"
            placeholder="Etkinlik başlığı, kulüp veya yerleşke ara..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="events-filters">
          <div className="filter-select-group">
            <label>Zaman:</label>
            <select value={whenFilter} onChange={(e) => setWhenFilter(e.target.value)}>
              <option value="all">Tüm Etkinlikler</option>
              <option value="upcoming">Yaklaşan Etkinlikler</option>
              <option value="past">Geçmiş Etkinlikler</option>
            </select>
          </div>

          <div className="filter-select-group">
            <label>Kategori:</label>
            <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {actionError && (
        <div className="alert alert--danger card" style={{ padding: '12px 16px', color: '#c00' }}>
          {actionError}
        </div>
      )}

      {/* Etkinlik Listesi */}
      {loading ? (
        <div className="card" style={{ textAlign: 'center', padding: '40px' }}>
          <p>Etkinlikler yükleniyor...</p>
        </div>
      ) : error ? (
        <div className="empty card">
          <p style={{ color: '#c00' }}>{error}</p>
          <button type="button" className="btn btn--outline btn--sm" onClick={loadEvents}>
            Tekrar Dene
          </button>
        </div>
      ) : filteredEvents.length === 0 ? (
        <div className="empty card">
          <span className="empty__icon">
            <Icon name="calendar" size={28} />
          </span>
          <h3>Etkinlik bulunamadı</h3>
          <p>Seçilen filtrelere uygun bir kampüs etkinliği mevcut değil.</p>
        </div>
      ) : (
        <div className="events-grid">
          {filteredEvents.map((ev) => {
            const isReg = ev.is_registered;
            const isFull = ev.registration_status === 'full';
            const isCancelled = ev.status === 'cancelled';

            return (
              <article key={ev.event_id} className="event-card card">
                {ev.poster_url && (
                  <div className="event-card__poster" style={{ height: '140px', overflow: 'hidden', borderRadius: '8px 8px 0 0' }}>
                    <img
                      src={ev.poster_url}
                      alt={ev.title}
                      style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                      onError={(e) => { e.target.style.display = 'none'; }}
                    />
                  </div>
                )}

                <div className="event-card__body" style={{ padding: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <span className="badge" style={{ fontSize: '11px', background: '#e2e8f0', padding: '2px 8px', borderRadius: '4px' }}>
                      {ev.category || 'Etkinlik'}
                    </span>
                    <span style={{ fontSize: '12px', color: isCancelled ? '#c00' : '#475569', fontWeight: 600 }}>
                      {isCancelled ? 'İPTAL EDİLDİ' : formatDate(ev.starts_at)}
                    </span>
                  </div>

                  <h3 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '6px' }}>{ev.title}</h3>
                  <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '10px' }}>
                    📍 {ev.location} · 🏛️ {ev.club_name}
                  </p>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '14px', paddingTop: '10px', borderTop: '1px solid #f1f5f9' }}>
                    <small style={{ color: '#64748b' }}>
                      Katılımcı: {ev.attendee_count} {ev.capacity ? `/ ${ev.capacity}` : ''}
                    </small>

                    <div style={{ display: 'flex', gap: '8px' }}>
                      <button
                        type="button"
                        className="btn btn--outline btn--sm"
                        onClick={() => setActiveModalEvent(ev)}
                      >
                        Detay
                      </button>

                      {!isCancelled && (
                        <button
                          type="button"
                          className={`btn btn--sm ${isReg ? 'btn--outline' : 'btn--primary'}`}
                          disabled={!isReg && isFull}
                          onClick={() => handleRegister(ev.event_id, isReg)}
                        >
                          {isReg ? 'İptal Et' : isFull ? 'Kontenjan Dolu' : 'Kayıt Ol'}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Detay Modalı */}
      {activeModalEvent && (
        <div className="modal-backdrop" onClick={() => setActiveModalEvent(null)}>
          <div className="modal-card card" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '600px', width: '90%' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h2>{activeModalEvent.title}</h2>
              <button type="button" className="icon-btn" onClick={() => setActiveModalEvent(null)}>✕</button>
            </div>

            {activeModalEvent.poster_url && (
              <img
                src={activeModalEvent.poster_url}
                alt=""
                style={{ width: '100%', maxHeight: '240px', objectFit: 'cover', borderRadius: '8px', marginBottom: '16px' }}
              />
            )}

            <div style={{ marginBottom: '16px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', fontSize: '13px' }}>
              <div><strong>Düzenleyen Kulüp:</strong> {activeModalEvent.club_name}</div>
              <div><strong>Kategori:</strong> {activeModalEvent.category}</div>
              <div><strong>Yerleşke / Konum:</strong> {activeModalEvent.location}</div>
              <div><strong>Başlangıç:</strong> {formatDate(activeModalEvent.starts_at)}</div>
              {activeModalEvent.ends_at && <div><strong>Bitiş:</strong> {formatDate(activeModalEvent.ends_at)}</div>}
              <div><strong>Kontenjan:</strong> {activeModalEvent.attendee_count} / {activeModalEvent.capacity || 'Sınırsız'}</div>
            </div>

            <p style={{ fontSize: '14px', lineHeight: '1.6', marginBottom: '20px', whiteSpace: 'pre-wrap' }}>
              {activeModalEvent.description}
            </p>

            {/* Kulüp temsilcisi için katılımcı listesi */}
            {activeModalEvent.can_manage && activeModalEvent.attendees && (
              <div style={{ marginTop: '16px', borderTop: '1px solid #e2e8f0', paddingTop: '16px' }}>
                <h4>Kayıtlı Katılımcılar ({activeModalEvent.attendees.length})</h4>
                <ul style={{ maxHeight: '120px', overflowY: 'auto', fontSize: '13px', paddingLeft: '20px' }}>
                  {activeModalEvent.attendees.map((a) => (
                    <li key={a.user_id}>
                      {a.first_name} {a.last_name} ({a.email})
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              {activeModalEvent.can_manage && (
                <button
                  type="button"
                  className="btn btn--outline btn--sm"
                  style={{ color: '#dc2626' }}
                  onClick={() => handleDeleteEvent(activeModalEvent.event_id)}
                >
                  Etkinliği Sil
                </button>
              )}
              <button
                type="button"
                className={`btn btn--sm ${activeModalEvent.is_registered ? 'btn--outline' : 'btn--primary'}`}
                onClick={() => handleRegister(activeModalEvent.event_id, activeModalEvent.is_registered)}
              >
                {activeModalEvent.is_registered ? 'Kaydı İptal Et' : 'Etkinliğe Kayıt Ol'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Kulüp Temsilcisi Etkinlik Oluşturma Modalı */}
      {createModalOpen && (
        <div className="modal-backdrop" onClick={() => setCreateModalOpen(false)}>
          <div className="modal-card card" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '540px', width: '90%' }}>
            <h2>Yeni Kulüp Etkinliği Yayınla</h2>
            <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '16px' }}>
              Etkinlik kaydedildiğinde öğrencilere otomatik Gmail bildirim e-postası iletilecektir.
            </p>

            <form onSubmit={handleCreateSubmit}>
              <div className="form-group" style={{ marginBottom: '12px' }}>
                <label style={{ fontSize: '13px', fontWeight: 600 }}>Düzenleyen Kulüp</label>
                <select
                  value={newEvent.club_id}
                  onChange={(e) => setNewEvent({ ...newEvent, club_id: e.target.value })}
                  required
                  style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                >
                  {managedClubs.map((c) => (
                    <option key={c.club_id} value={c.club_id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div className="form-group" style={{ marginBottom: '12px' }}>
                <label style={{ fontSize: '13px', fontWeight: 600 }}>Etkinlik Başlığı</label>
                <input
                  type="text"
                  value={newEvent.title}
                  onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                  placeholder="Örn: TEKNOFEST Atölyesi & Bilgilendirme"
                  required
                  style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                />
              </div>

              <div className="form-group" style={{ marginBottom: '12px' }}>
                <label style={{ fontSize: '13px', fontWeight: 600 }}>Açıklama</label>
                <textarea
                  value={newEvent.description}
                  onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                  rows={4}
                  required
                  style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
                <div>
                  <label style={{ fontSize: '13px', fontWeight: 600 }}>Yerleşke / Konum</label>
                  <input
                    type="text"
                    value={newEvent.location}
                    onChange={(e) => setNewEvent({ ...newEvent, location: e.target.value })}
                    placeholder="Haliç Yerleşkesi D-101"
                    required
                    style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: '13px', fontWeight: 600 }}>Kategori</label>
                  <select
                    value={newEvent.category}
                    onChange={(e) => setNewEvent({ ...newEvent, category: e.target.value })}
                    style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                  >
                    {categories.filter((c) => c !== 'Tümü').map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
                <div>
                  <label style={{ fontSize: '13px', fontWeight: 600 }}>Başlangıç Tarihi ve Saati</label>
                  <input
                    type="datetime-local"
                    value={newEvent.starts_at}
                    onChange={(e) => setNewEvent({ ...newEvent, starts_at: e.target.value })}
                    required
                    style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: '13px', fontWeight: 600 }}>Kontenjan</label>
                  <input
                    type="number"
                    min="1"
                    max="10000"
                    value={newEvent.capacity}
                    onChange={(e) => setNewEvent({ ...newEvent, capacity: e.target.value })}
                    style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                  />
                </div>
              </div>

              <div className="form-group" style={{ marginBottom: '16px' }}>
                <label style={{ fontSize: '13px', fontWeight: 600 }}>Etkinlik Afişi (JPG, PNG veya WEBP)</label>
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={(e) => setPosterFile(e.target.files[0] || null)}
                  style={{ display: 'block', marginTop: '6px' }}
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button type="button" className="btn btn--outline" onClick={() => setCreateModalOpen(false)}>
                  İptal
                </button>
                <button type="submit" className="btn btn--primary" disabled={submitting}>
                  {submitting ? 'Yayınlanıyor...' : 'Etkinliği Yayınla'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
