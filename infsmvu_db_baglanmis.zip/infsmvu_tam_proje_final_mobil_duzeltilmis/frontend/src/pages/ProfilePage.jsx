import { useEffect, useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { usersApi, projectsApi } from '../services/api';
import { toSessionUser } from '../services/authService';
import { transformProject } from '../context/PostsContext';
import Avatar from '../components/common/Avatar';
import Icon from '../components/common/Icon';
import RoleBadge from '../components/common/RoleBadge';
import ProjectCard from '../components/explore/ProjectCard';
import EditProfileModal from '../components/profile/EditProfileModal';

export default function ProfilePage() {
  const { userId } = useParams();
  const { user: currentUser } = useAuth();
  const [profile, setProfile] = useState(null);
  const [userProjects, setUserProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followersCount, setFollowersCount] = useState(0);

  const isMe = !userId || Number(userId) === currentUser?.id || Number(userId) === currentUser?.user_id;
  const targetId = isMe ? currentUser?.id : Number(userId);

  useEffect(() => {
    let mounted = true;
    setLoading(true);

    if (isMe && currentUser) {
      // Kendi güncel profilini çek
      usersApi
        .getMe()
        .then((data) => {
          if (!mounted) return;
          const transformed = toSessionUser(data);
          setProfile(transformed);
        })
        .catch(() => {
          if (mounted) setProfile(currentUser);
        })
        .finally(() => {
          if (mounted) setLoading(false);
        });
    } else if (userId) {
      // Başka kullanıcının profilini çek
      usersApi
        .getById(userId)
        .then((data) => {
          if (!mounted) return;
          const transformed = toSessionUser(data);
          setProfile(transformed);
          setIsFollowing(Boolean(data.is_following));
          setFollowersCount(Number(data.follower_count) || 0);
        })
        .catch((err) => {
          console.error(err);
        })
        .finally(() => {
          if (mounted) setLoading(false);
        });
    }

    // Kullanıcının projelerini çek
    projectsApi
      .getAll()
      .then((data) => {
        if (!mounted || !Array.isArray(data)) return;
        const filtered = data
          .filter((p) => p.owner_id === targetId)
          .map(transformProject);
        setUserProjects(filtered);
      })
      .catch(() => {});

    return () => {
      mounted = false;
    };
  }, [userId, isMe, currentUser, targetId]);

  const handleFollowToggle = async () => {
    if (!profile) return;
    try {
      if (isFollowing) {
        await usersApi.unfollow(profile.id);
        setIsFollowing(false);
        setFollowersCount((c) => Math.max(0, c - 1));
      } else {
        await usersApi.follow(profile.id);
        setIsFollowing(true);
        setFollowersCount((c) => c + 1);
      }
    } catch (err) {
      alert(err.message || 'İşlem başarısız.');
    }
  };

  if (loading) {
    return (
      <div className="card" style={{ padding: '60px', textAlign: 'center' }}>
        <p>Profil yükleniyor...</p>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="empty card">
        <span className="empty__icon">
          <Icon name="user" size={28} />
        </span>
        <h3>Kullanıcı Bulunamadı</h3>
        <p>İstenen profil mevcut değil veya silinmiş olabilir.</p>
        <Link to="/" className="btn btn--primary btn--sm">
          Akışa Dön
        </Link>
      </div>
    );
  }

  return (
    <div className="profile">
      <section className="card profile__header">
        {/* Kapak Görseli */}
        <div className="profile__cover" style={{ height: '180px', background: 'linear-gradient(135deg, #1f5a96 0%, #0d2744 100%)', position: 'relative' }}>
          {profile.cover && (
            <img
              src={profile.cover}
              alt=""
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              onError={(e) => { e.target.style.display = 'none'; }}
            />
          )}
        </div>

        <div className="profile__header-body" style={{ padding: '20px', position: 'relative' }}>
          <div className="profile__avatar" style={{ marginTop: '-60px', marginBottom: '14px' }}>
            <Avatar user={profile} size={110} />
          </div>

          <div className="profile__identity">
            <div className="profile__name-row" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <h1 style={{ fontSize: '24px', margin: 0 }}>{profile.name}</h1>
              <RoleBadge role={profile.role} />
            </div>

            <p className="profile__headline" style={{ color: '#475569', fontSize: '15px', marginTop: '4px' }}>
              {profile.headline}
            </p>

            <p className="profile__meta" style={{ fontSize: '13px', color: '#64748b', marginTop: '4px' }}>
              <Icon name="graduation" size={16} /> {profile.department}
              {profile.year ? ` · ${profile.year}` : ''}
              {profile.faculty ? ` · ${profile.faculty}` : ''}
            </p>

            {profile.bio && (
              <p style={{ marginTop: '12px', fontSize: '14px', lineHeight: '1.6', color: '#334155' }}>
                {profile.bio}
              </p>
            )}

            {/* Bağlantılar */}
            <div style={{ display: 'flex', gap: '14px', marginTop: '12px' }}>
              {profile.links?.github && (
                <a
                  href={profile.links.github}
                  target="_blank"
                  rel="noreferrer"
                  style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', color: '#1f5a96' }}
                >
                  <Icon name="github" size={16} /> GitHub
                </a>
              )}
              {profile.links?.linkedin && (
                <a
                  href={profile.links.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', color: '#1f5a96' }}
                >
                  <Icon name="linkedin" size={16} /> LinkedIn
                </a>
              )}
            </div>
          </div>

          <div className="profile__cta" style={{ position: 'absolute', top: '20px', right: '20px' }}>
            {isMe ? (
              <button type="button" className="btn btn--primary" onClick={() => setEditing(true)}>
                <Icon name="edit" size={18} /> Profili Düzenle
              </button>
            ) : (
              <div style={{ display: 'flex', gap: '8px' }}>
                <button
                  type="button"
                  className={`btn ${isFollowing ? 'btn--outline' : 'btn--primary'}`}
                  onClick={handleFollowToggle}
                >
                  {isFollowing ? 'Takibi Bırak' : 'Takip Et'}
                </button>
                <a className="btn btn--outline" href={`mailto:${profile.email}`}>
                  <Icon name="mail" size={18} /> E-posta
                </a>
              </div>
            )}
          </div>
        </div>

        {/* Yetenekler Bölümü */}
        {profile.skills && profile.skills.length > 0 && (
          <div style={{ padding: '0 20px 20px', borderTop: '1px solid #f1f5f9', paddingTop: '16px' }}>
            <h3 style={{ fontSize: '14px', color: '#64748b', marginBottom: '10px' }}>YETENEKLER &amp; UZMANLIKLAR</h3>
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
              {profile.skills.map((s) => (
                <span
                  key={s.skill_id}
                  style={{
                    background: '#f1f5f9',
                    color: '#1e293b',
                    padding: '6px 12px',
                    borderRadius: '999px',
                    fontSize: '13px',
                    fontWeight: 500,
                  }}
                >
                  {s.name} <small style={{ color: '#64748b' }}>(Lvl {s.level || 1})</small>
                </span>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Kullanıcının Projeleri */}
      <section style={{ marginTop: '24px' }}>
        <h2 style={{ fontSize: '18px', marginBottom: '16px' }}>
          {isMe ? 'Paylaştığım Projeler' : `${profile.name} Tarafından Paylaşılan Projeler`} ({userProjects.length})
        </h2>

        {userProjects.length === 0 ? (
          <div className="empty card">
            <p>Henüz paylaşılmış bir proje bulunmuyor.</p>
            {isMe && (
              <Link to="/yeni-proje" className="btn btn--primary btn--sm" style={{ marginTop: '10px' }}>
                Yeni Proje Paylaş
              </Link>
            )}
          </div>
        ) : (
          <div className="project-grid">
            {userProjects.map((p) => (
              <ProjectCard key={p.id} project={p} />
            ))}
          </div>
        )}
      </section>

      {/* Profil Düzenleme Modalı */}
      {isMe && (
        <EditProfileModal
          open={editing}
          onClose={() => setEditing(false)}
        />
      )}
    </div>
  );
}
