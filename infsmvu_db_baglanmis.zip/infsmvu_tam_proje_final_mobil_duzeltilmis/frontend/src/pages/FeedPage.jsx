import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostsContext';
import Avatar from '../components/common/Avatar';
import Icon from '../components/common/Icon';
import PostCard from '../components/feed/PostCard';
import RightPanel from '../components/feed/RightPanel';
import FsmvuLogo from '../components/common/FsmvuLogo';

const TABS = [
  { id: 'all', label: 'Tüm Projeler' },
  { id: 'recruiting', label: 'Takım Arayanlar' },
  { id: 'saved', label: 'Kaydedilenler' },
];

export default function FeedPage() {
  const { user } = useAuth();
  const { posts, loading, error, savedIds } = usePosts();
  const [tab, setTab] = useState('all');

  const visible = useMemo(() => {
    const sorted = [...posts].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    if (tab === 'recruiting') return sorted.filter((p) => p.rawStatus === 'open');
    if (tab === 'saved') return sorted.filter((p) => savedIds?.includes(String(p.id)));
    return sorted;
  }, [posts, tab, savedIds]);

  const firstName = (user?.name || user?.first_name || 'Öğrenci')
    .replace(/^(Prof\.|Doç\.|Dr\.|Öğr\.|Üyesi)\s*/gi, '')
    .split(' ')[0];

  return (
    <div className="feed-layout">
      <section className="feed-col" aria-label="Proje akışı">
        {/* Karşılama Alanı */}
        <div className="feed-welcome card">
          <div className="feed-welcome__badge">
            <FsmvuLogo size={46} showText={false} />
            <div>
              <span className="feed-welcome__sub">Fatih Sultan Mehmet Vakıf Üniversitesi</span>
              <h2>Hoş Geldin, {firstName}! 👋</h2>
            </div>
          </div>
          <p className="feed-welcome__desc">
            Cevizlibağ, Haliç ve Üsküdar kampüslerindeki projeleri incele, TEKNOFEST ve bitirme ekiplerine katıl,
            yaklaşan atölye ve çalıştayları takip et.
          </p>
          <div className="feed-welcome__quicklinks">
            <Link to="/etkinlikler" className="quicklink-chip">
              <Icon name="calendar" size={16} /> Kampüs Etkinlikleri
            </Link>
            <Link to="/kesfet" className="quicklink-chip">
              <Icon name="compass" size={16} /> Takım Arkadaşı Bul
            </Link>
            <Link to="/yeni-proje" className="quicklink-chip quicklink-chip--primary">
              <Icon name="plus" size={16} /> Yeni İlan Aç
            </Link>
          </div>
        </div>

        {/* Gönderi / Proje Paylaşma Çubuğu */}
        <div className="composer card">
          <Avatar user={user} size={46} />
          <Link to="/yeni-proje" className="composer__input">
            {firstName}, hangi projede takım arkadaşı arıyorsun?
          </Link>
          <Link to="/yeni-proje" className="btn btn--primary btn--sm">
            <Icon name="plus" size={18} /> Paylaş
          </Link>
        </div>

        {/* Sekmeler */}
        <div className="tabs" role="tablist" aria-label="Akış filtresi">
          {TABS.map((t) => (
            <button
              key={t.id}
              role="tab"
              aria-selected={tab === t.id}
              className={`tabs__item ${tab === t.id ? 'is-active' : ''}`}
              onClick={() => setTab(t.id)}
            >
              {t.label}
              {t.id === 'saved' && savedIds?.length > 0 && <span className="tabs__count">{savedIds.length}</span>}
            </button>
          ))}
        </div>

        {/* Liste */}
        {loading ? (
          <div className="card" style={{ padding: '40px', textAlign: 'center' }}>
            <p>Projeler yükleniyor...</p>
          </div>
        ) : error ? (
          <div className="empty card">
            <p style={{ color: '#c00' }}>{error}</p>
          </div>
        ) : visible.length === 0 ? (
          <div className="empty card">
            <span className="empty__icon">
              <Icon name={tab === 'saved' ? 'bookmark' : 'users'} size={28} />
            </span>
            <h3>{tab === 'saved' ? 'Henüz kaydedilen proje yok' : 'Proje bulunamadı'}</h3>
            <p>
              {tab === 'saved'
                ? 'Beğendiğin projelerde yer imi simgesine dokun; burada toplansın.'
                : 'İlk projeyi sen paylaşarak takımını kurmaya başlayabilirsin.'}
            </p>
            {tab !== 'all' ? (
              <button type="button" className="btn btn--outline btn--sm" onClick={() => setTab('all')}>
                Tüm Projeleri Gör
              </button>
            ) : (
              <Link to="/yeni-proje" className="btn btn--primary btn--sm">
                Yeni Proje Paylaş
              </Link>
            )}
          </div>
        ) : (
          visible.map((post) => <PostCard key={post.id} post={post} />)
        )}
      </section>

      <RightPanel />
    </div>
  );
}
