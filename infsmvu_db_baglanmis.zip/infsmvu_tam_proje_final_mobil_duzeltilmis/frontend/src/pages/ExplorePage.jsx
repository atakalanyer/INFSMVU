import { useMemo, useState } from 'react';
import { usePosts } from '../context/PostsContext';
import { useProjectFilters } from '../hooks/useProjectFilters';
import { countActiveFilters, filterProjects, projectSkillPool } from '../utils/filterProjects';
import Icon from '../components/common/Icon';
import FilterPanel from '../components/explore/FilterPanel';
import ActiveFilters from '../components/explore/ActiveFilters';
import ProjectCard from '../components/explore/ProjectCard';

const COMMON_SKILLS = [
  'Flutter',
  'React',
  'Node.js',
  'Python',
  'SQL',
  'UI/UX',
  'Gömülü Sistemler',
  'Veri Analizi',
  'Siber Güvenlik',
  'Makine Öğrenmesi',
];

export default function ExplorePage() {
  const { posts } = usePosts();
  const { filters, actions } = useProjectFilters();
  const [panelOpen, setPanelOpen] = useState(false);

  const results = useMemo(() => filterProjects(posts, filters), [posts, filters]);
  const activeCount = countActiveFilters(filters);

  // Her yetenek için proje sayısı
  const skillCounts = useMemo(() => {
    const counts = Object.fromEntries(COMMON_SKILLS.map((s) => [s, 0]));
    posts.forEach((p) => {
      const pool = projectSkillPool(p);
      pool.forEach((s) => {
        if (s in counts) counts[s] += 1;
      });
    });
    return counts;
  }, [posts]);

  return (
    <div className="explore">
      <header className="explore__head">
        <div>
          <h1>Keşfet &amp; Takım Arkadaşı Bul</h1>
          <p>Yeteneğine, bölümüne ve ilgi alanına uygun projeleri filtrele; doğru takımla eşleş.</p>
        </div>
      </header>

      <div className="explore__searchbar">
        <label className="search-input">
          <Icon name="search" size={19} />
          <input
            type="search"
            placeholder="Proje başlığı veya yetenek ara… (örn. Flutter, ROS, Siber Güvenlik)"
            value={filters.query}
            onChange={(e) => actions.setQuery(e.target.value)}
            aria-label="Proje veya yetenek ara"
          />
        </label>
        <button
          type="button"
          className="btn btn--outline explore__filter-toggle"
          aria-expanded={panelOpen}
          onClick={() => setPanelOpen((o) => !o)}
        >
          <Icon name="filter" size={18} /> Filtreler
          {activeCount > 0 && <span className="tabs__count tabs__count--dark">{activeCount}</span>}
        </button>
      </div>

      <ActiveFilters filters={filters} actions={actions} />

      <div className="explore__layout">
        <aside className={`explore__filters card ${panelOpen ? 'is-open' : ''}`} aria-label="Filtreler">
          <FilterPanel filters={filters} actions={actions} skillCounts={skillCounts} />
        </aside>

        <section className="explore__results" aria-live="polite">
          <p className="explore__count">
            <strong>{results.length}</strong> proje bulundu
            {filters.skills.length > 0 && ' · eşleşme sayısına göre sıralı'}
          </p>

          {results.length === 0 ? (
            <div className="empty card">
              <span className="empty__icon">
                <Icon name="search" size={28} />
              </span>
              <h3>Eşleşen ilan bulunamadı</h3>
              <p>
                Seçtiğin filtrelerle uyuşan bir proje yok. Bazı filtreleri kaldırmayı veya farklı bir anahtar kelime
                denemeyi dene.
              </p>
              <button type="button" className="btn btn--primary btn--sm" onClick={actions.clearAll}>
                Filtreleri Temizle
              </button>
            </div>
          ) : (
            <div className="project-grid">
              {results.map(({ project, matched }) => (
                <ProjectCard key={project.id} project={project} matchedSkills={matched} />
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
