import { useCallback, useEffect, useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  OTP_LENGTH,
  OTP_RESEND_SECONDS,
  checkCredentials,
  registerAccount,
  requestOtp,
  verifyOtp,
} from '../services/authService';
import { lookupApi } from '../services/api';
import {
  requiredDomainForRole,
  validateFullName,
  validateInstitutionalEmail,
  validatePassword,
} from '../utils/validators';
import Icon from '../components/common/Icon';
import FormField from '../components/auth/FormField';
import RoleSelector from '../components/auth/RoleSelector';
import OtpInput from '../components/auth/OtpInput';
import FsmvuLogo from '../components/common/FsmvuLogo';

const DEMO_ACCOUNTS = [
  { label: 'Öğrenci', email: 'elif.kaya@stu.fsm.edu.tr', role: 'student', password: 'Fsm12345' },
  { label: 'Kulüp Temsilcisi', email: 'mehmetali.demir@stu.fsm.edu.tr', role: 'club_admin', password: 'Fsm12345' },
  { label: 'Akademisyen', email: 'zeynep.aydin@fsm.edu.tr', role: 'academic', password: 'Fsm12345' },
];

const INITIAL_FORM = {
  name: '',
  email: '',
  password: '',
  department_id: '',
  role: 'student',
  class_year: 1,
  consent: false,
};

export default function AuthPage() {
  const { isAuthenticated, signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const redirectTo = location.state?.from || '/';

  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [step, setStep] = useState('form'); // 'form' | 'otp' | 'success'
  const [form, setForm] = useState(INITIAL_FORM);
  const [departments, setDepartments] = useState([]);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);

  // OTP durumu
  const [devOtpCode, setDevOtpCode] = useState('');
  const [otpValue, setOtpValue] = useState('');
  const [otpError, setOtpError] = useState('');
  const [resendLeft, setResendLeft] = useState(0);

  // Bölümleri backend lookup servisinden al
  useEffect(() => {
    lookupApi
      .getDepartments()
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setDepartments(data);
          setForm((f) => ({ ...f, department_id: f.department_id || data[0].department_id }));
        }
      })
      .catch(() => {
        // Yedek bölümler
        setDepartments([
          { department_id: 1, name: 'Bilgisayar Programcılığı' },
          { department_id: 2, name: 'Bilgisayar Mühendisliği' },
          { department_id: 3, name: 'Grafik Tasarım' },
        ]);
        setForm((f) => ({ ...f, department_id: 1 }));
      });
  }, []);

  useEffect(() => {
    if (resendLeft <= 0) return undefined;
    const timer = setTimeout(() => setResendLeft((s) => s - 1), 1000);
    return () => clearTimeout(timer);
  }, [resendLeft]);

  const setField = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
    setFormError('');
  };

  const switchMode = (next) => {
    setMode(next);
    setStep('form');
    setErrors({});
    setFormError('');
    setOtpValue('');
    setOtpError('');
    setDevOtpCode('');
  };

  const fillDemo = (demo) => {
    setForm((prev) => ({
      ...prev,
      role: demo.role,
      email: demo.email,
      password: demo.password,
    }));
    setErrors({});
    setFormError('');
    if (mode !== 'login') setMode('login');
  };

  const validate = () => {
    const next = {};
    if (mode === 'register') {
      const nameCheck = validateFullName(form.name);
      if (!nameCheck.valid) next.name = nameCheck.message;
      if (!form.department_id) next.department = 'Bölümünüzü seçin.';
    }
    const emailCheck = validateInstitutionalEmail(form.email, form.role);
    if (!emailCheck.valid) next.email = emailCheck.message;

    if (mode === 'register') {
      const passCheck = validatePassword(form.password);
      if (!passCheck.valid) next.password = passCheck.message;
      if (!form.consent) next.consent = 'Devam etmek için onay vermelisiniz.';
    } else if (!form.password) {
      next.password = 'Parola zorunludur.';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (loading || !validate()) return;
    setLoading(true);
    setFormError('');

    try {
      if (mode === 'login') {
        const result = await checkCredentials({ email: form.email, password: form.password });
        signIn(result.account, result.token);
        navigate(redirectTo, { replace: true });
      } else {
        const result = await registerAccount({
          name: form.name,
          email: form.email,
          password: form.password,
          role: form.role,
          department_id: form.department_id,
          class_year: Number(form.class_year) || 1,
        });

        if (result.dogrulama_kodu) {
          setDevOtpCode(result.dogrulama_kodu);
        }
        setResendLeft(OTP_RESEND_SECONDS);
        setStep('otp');
      }
    } catch (err) {
      setFormError(err.message || 'İşlem sırasında bir hata oluştu.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = useCallback(
    async (code) => {
      if (loading) return;
      setLoading(true);
      setOtpError('');
      try {
        await verifyOtp({ email: form.email, code });
        setStep('success');

        // Otomatik giriş yap
        try {
          const loginResult = await checkCredentials({ email: form.email, password: form.password });
          setTimeout(() => {
            signIn(loginResult.account, loginResult.token);
            navigate(redirectTo, { replace: true });
          }, 1200);
        } catch {
          setTimeout(() => switchMode('login'), 1200);
        }
      } catch (err) {
        setOtpError(err.message || 'Kod geçersiz veya süresi dolmuş.');
      } finally {
        setLoading(false);
      }
    },
    [loading, form.email, form.password, signIn, navigate, redirectTo]
  );

  const handleOtpChange = (value) => {
    setOtpValue(value);
    setOtpError('');
    if (value.length === OTP_LENGTH) handleVerify(value);
  };

  const handleResend = async () => {
    if (resendLeft > 0 || loading) return;
    setLoading(true);
    setOtpError('');
    try {
      const res = await requestOtp(form.email);
      if (res.code) setDevOtpCode(res.code);
      setResendLeft(OTP_RESEND_SECONDS);
    } catch (err) {
      setOtpError(err.message || 'Kod gönderilemedi.');
    } finally {
      setLoading(false);
    }
  };

  if (isAuthenticated && step !== 'success') return <Navigate to="/" replace />;

  const domain = requiredDomainForRole(form.role);

  return (
    <div className="auth">
      {/* Sol Hero / Marka Alanı */}
      <aside className="auth__hero">
        <div className="auth__brand">
          <FsmvuLogo size={56} showText={false} />
          <div>
            <strong style={{ fontSize: '20px', letterSpacing: '-0.3px' }}>INFSMVU</strong>
            <small style={{ display: 'block', opacity: 0.9 }}>Fatih Sultan Mehmet Vakıf Üniversitesi</small>
          </div>
        </div>

        <div className="auth__hero-body">
          <div style={{ marginBottom: '24px' }}>
            <span style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              padding: '6px 14px',
              borderRadius: '999px',
              background: 'rgba(255,255,255,0.15)',
              fontSize: '12px',
              fontWeight: 600,
              backdropFilter: 'blur(4px)'
            }}>
              <Icon name="sparkles" size={14} /> FSMVÜ Akademik ve Sosyal İş Birliği Ağı
            </span>
          </div>
          <h1>Fikrini paylaş, doğru takımı kur.</h1>
          <p>
            Cevizlibağ, Haliç, Üsküdar ve Kandilli yerleşkelerindeki öğrenciler, kulüpler ve akademisyenler;
            TEKNOFEST, bitirme projeleri ve yarışmalar için tek çatı altında buluşuyor.
          </p>

          <div style={{ marginTop: '36px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'rgba(255,255,255,0.2)', display: 'grid', placeItems: 'center' }}>
                <Icon name="users" size={18} />
              </div>
              <span style={{ fontSize: '14px' }}>Yetenek ve seviye bazlı eşleşme algoritması</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'rgba(255,255,255,0.2)', display: 'grid', placeItems: 'center' }}>
                <Icon name="calendar" size={18} />
              </div>
              <span style={{ fontSize: '14px' }}>Kampüs çalıştayları ve Gmail bildirim otomasyonu</span>
            </div>
          </div>
        </div>

        <footer className="auth__hero-foot">
          <span>© 2026 Fatih Sultan Mehmet Vakıf Üniversitesi</span>
        </footer>
      </aside>

      {/* Sağ Form Alanı */}
      <main className="auth__panel">
        <div className="auth__card card">
          {/* Logo Başlığı */}
          <div style={{ textAlign: 'center', marginBottom: '20px' }}>
            <FsmvuLogo size={64} showText={true} />
          </div>

          {step === 'otp' ? (
            <div className="auth__step">
              <button type="button" className="link-btn" onClick={() => setStep('form')}>
                ← Bilgileri Değiştir
              </button>
              <h2>E-posta Doğrulama</h2>
              <p>
                <strong>{form.email}</strong> adresine gönderilen 6 haneli doğrulama kodunu girin.
              </p>

              {devOtpCode && (
                <div style={{
                  background: '#e8f4fd',
                  border: '1px solid #b8daff',
                  borderRadius: '8px',
                  padding: '12px',
                  margin: '16px 0',
                  color: '#004085',
                  fontSize: '13px'
                }}>
                  <strong>Geliştirme Kodu:</strong> {devOtpCode} (SMTP yapılandırılmadığında otomatik gösterilir)
                </div>
              )}

              <OtpInput
                length={OTP_LENGTH}
                value={otpValue}
                onChange={handleOtpChange}
                disabled={loading}
                error={otpError}
              />

              <div className="auth__resend" style={{ marginTop: '20px' }}>
                <button
                  type="button"
                  className="link-btn"
                  disabled={resendLeft > 0 || loading}
                  onClick={handleResend}
                >
                  {resendLeft > 0 ? `Tekrar kod iste (${resendLeft}s)` : 'Kodu Tekrar Gönder'}
                </button>
              </div>
            </div>
          ) : step === 'success' ? (
            <div className="auth__step" style={{ textAlign: 'center', padding: '30px 0' }}>
              <div style={{
                width: '64px',
                height: '64px',
                borderRadius: '50%',
                background: '#28a745',
                color: 'white',
                display: 'grid',
                placeItems: 'center',
                margin: '0 auto 16px'
              }}>
                <Icon name="check" size={32} />
              </div>
              <h2>Doğrulama Başarılı!</h2>
              <p>Hesabınız aktif edildi. Giriş yapılıyor...</p>
            </div>
          ) : (
            <>
              {/* Giriş / Kayıt Sekmeleri */}
              <div className="auth__tabs" role="tablist">
                <button
                  type="button"
                  role="tab"
                  aria-selected={mode === 'login'}
                  className={`auth__tab ${mode === 'login' ? 'is-active' : ''}`}
                  onClick={() => switchMode('login')}
                >
                  Giriş Yap
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={mode === 'register'}
                  className={`auth__tab ${mode === 'register' ? 'is-active' : ''}`}
                  onClick={() => switchMode('register')}
                >
                  Kayıt Ol
                </button>
              </div>

              {/* Demo Hesap Butonları (Hızlı Test İçin) */}
              <div style={{ marginBottom: '18px' }}>
                <small style={{ display: 'block', marginBottom: '8px', color: '#666', fontWeight: 600 }}>
                  Hızlı Demo Hesapları:
                </small>
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                  {DEMO_ACCOUNTS.map((d) => (
                    <button
                      key={d.label}
                      type="button"
                      className="btn btn--outline btn--sm"
                      style={{ fontSize: '11px', padding: '4px 10px' }}
                      onClick={() => fillDemo(d)}
                    >
                      {d.label}
                    </button>
                  ))}
                </div>
              </div>

              {formError && (
                <div className="alert alert--danger" style={{
                  background: '#f8d7da',
                  color: '#721c24',
                  border: '1px solid #f5c6cb',
                  padding: '10px 14px',
                  borderRadius: '6px',
                  marginBottom: '16px',
                  fontSize: '13px'
                }}>
                  {formError}
                </div>
              )}

              <form onSubmit={handleSubmit} noValidate>
                {mode === 'register' && (
                  <>
                    <RoleSelector
                      value={form.role}
                      onChange={(role) => setField('role', role)}
                    />

                    <FormField
                      id="name"
                      label="Ad Soyad"
                      placeholder="Ahmet Yılmaz"
                      value={form.name}
                      error={errors.name}
                      onChange={(e) => setField('name', e.target.value)}
                    />

                    <div className="form-field" style={{ marginBottom: '16px' }}>
                      <label htmlFor="dept" style={{ display: 'block', fontSize: '13px', fontWeight: 600, marginBottom: '6px' }}>
                        Bölüm
                      </label>
                      <select
                        id="dept"
                        value={form.department_id}
                        onChange={(e) => setField('department_id', Number(e.target.value))}
                        style={{
                          width: '100%',
                          padding: '10px 12px',
                          borderRadius: '8px',
                          border: '1px solid #cbd5e1',
                          fontSize: '14px'
                        }}
                      >
                        {departments.map((d) => (
                          <option key={d.department_id} value={d.department_id}>
                            {d.name} {d.faculty ? `(${d.faculty})` : ''}
                          </option>
                        ))}
                      </select>
                      {errors.department && (
                        <span style={{ color: '#dc2626', fontSize: '12px', marginTop: '4px', display: 'block' }}>
                          {errors.department}
                        </span>
                      )}
                    </div>
                  </>
                )}

                <FormField
                  id="email"
                  type="email"
                  label="Kurumsal E-posta"
                  placeholder={`ad.soyad${domain}`}
                  value={form.email}
                  error={errors.email}
                  onChange={(e) => setField('email', e.target.value)}
                />

                <FormField
                  id="password"
                  type="password"
                  label="Şifre"
                  placeholder="En az 8 karakter, harf ve rakam"
                  value={form.password}
                  error={errors.password}
                  onChange={(e) => setField('password', e.target.value)}
                />

                {mode === 'register' && (
                  <div style={{ margin: '14px 0' }}>
                    <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={form.consent}
                        onChange={(e) => setField('consent', e.target.checked)}
                      />
                      <span>FSMVÜ Kampüs Ağı Kullanım Koşulları'nı kabul ediyorum.</span>
                    </label>
                    {errors.consent && (
                      <span style={{ color: '#dc2626', fontSize: '12px', display: 'block', marginTop: '4px' }}>
                        {errors.consent}
                      </span>
                    )}
                  </div>
                )}

                <button
                  type="submit"
                  className="btn btn--primary"
                  style={{ width: '100%', marginTop: '12px', padding: '12px' }}
                  disabled={loading}
                >
                  {loading ? 'Lütfen bekleyin...' : mode === 'login' ? 'Giriş Yap' : 'Kayıt Ol ve Kod İste'}
                </button>
              </form>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
