import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { projectsApi } from '../services/api';
import { transformProject } from '../context/PostsContext';
import { useAuth } from '../context/AuthContext';
import { usePosts } from '../context/PostsContext';
import Avatar from '../components/common/Avatar';
import Icon from '../components/common/Icon';
import RoleBadge from '../components/common/RoleBadge';
import ApplyModal from '../components/project/ApplyModal';
import CommentSection from '../components/feed/CommentSection';

export default function ProjectDetailPage() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toggleLike, toggleSave, isLiked, isSaved } = usePosts();

  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState('');
  const [applications, setApplications] = useState([]);
  const [matchCandidates, setMatchCandidates] = useState([]);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    setError(null);

    projectsApi
      .getById(projectId)
      .then((data) => {
        if (!mounted) return;
        const transformed = transformProject(data);
        setProject(transformed);

        // Proje sahibi ise başvuruları ve eşleşen adayları getir
        if (user && user.id === transformed.ownerId) {
          projectsApi.getApplications(projectId).then(setApplications).catch(() => {});
          projectsApi.getMatches(projectId).then(setMatchCandidates).catch(() => {});
        }
      })
      .catch((err) => {
        if (!mounted) return;
        setError(err.message || 'Proje yüklenemedi.');
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, [projectId, user]);

  const handleApplicationDecision = async (appId, status) => {
    try {
      await projectsApi.decideApplication(appId, status);
      // Başvuru listesini tazele
      const refreshed = await projectsApi.getApplications(projectId);
      setApplications(refreshed);
      // Projeyi tazele (üye sayısı değişti)
      const proj = await projectsApi.getById(projectId);
      setProject(transformProject(proj));
    } catch (err) {
      alert(err.message || 'İşlem başarısız.');
    }
  };

  if (loading) {
    return (
      <div className="card" style={{ padding: '60px', textAlign: 'center' }}>
        <p>Proje yükleniyor...</p>
      </div>
    );
  }

  if (error || !project) {
    return (
      <div className="empty card">
        <span className="empty__icon">
          <Icon name="search" size={28} />
        </span>
        <h3>Proje Bulunamadı</h3>
        <p>{error || 'İstenen proje mevcut değil veya kaldırılmış olabilir.'}</p>
        <Link to="/" className="btn btn--primary btn--sm">
          Akışa Dön
        </Link>
      </div>
    );
  }

  const isOwner = user && user.id === project.ownerId;
  const isMember = project.team.some((m) => m.userId === user?.id);
  const liked = isLiked(project.id);
  const saved = isSaved(project.id);

  return (
    <div className="detail">
      <button type="button" className="link-btn detail__back" onClick={() => navigate(-1)}>
        ← Geri
      </button>

      <div className="detail__layout">
        <article className="detail__main">
          {/* Hero Görseli */}
          <div className="detail__hero" style={{ maxHeight: '360px', overflow: 'hidden', position: 'relative' }}>
            <img
              src={project.image}
              alt={project.title}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
            <span className="post-card__type">{project.type}</span>
            <span className={`post-card__status ${project.rawStatus === 'open' ? 'is-recruiting' : ''}`}>
              {project.status}
            </span>
          </div>

          <header className="detail__head">
            <h1>{project.title}</h1>
            <div className="detail__actions">
              <button
                type="button"
                className={`action-btn ${liked ? 'is-liked' : ''}`}
                onClick={() => toggleLike(project.id)}
              >
                <Icon name="heart" size={24} filled={liked} />
              </button>
              <button
                type="button"
                className={`action-btn ${saved ? 'is-saved' : ''}`}
                onClick={() => toggleSave(project.id)}
              >
                <Icon name="bookmark" size={24} filled={saved} />
              </button>
            </div>
          </header>

          <p className="detail__summary" style={{ fontSize: '16px', color: '#475569', marginBottom: '20px', fontStyle: 'italic' }}>
            {project.summary}
          </p>

          {/* Etiketler */}
          {project.tags.length > 0 && (
            <ul className="tag-list detail__tags">
              {project.tags.map((t) => (
                <li key={t}>
                  <Link to={`/kesfet?q=${encodeURIComponent(t)}`} className="tag">
                    #{t}
                  </Link>
                </li>
              ))}
            </ul>
          )}

          {/* Proje Amacı */}
          <section className="detail-section">
            <h2>
              <Icon name="target" size={20} /> Projenin Amacı
            </h2>
            <p className="detail-goal">{project.goal}</p>
          </section>

          {/* Detay Açıklama */}
          <section className="detail-section">
            <h2>Proje Hakkında</h2>
            <p style={{ whiteSpace: 'pre-wrap', lineHeight: '1.7' }}>{project.description}</p>
          </section>

          {/* Teknolojiler */}
          {project.technologies.length > 0 && (
            <section className="detail-section">
              <h2>Kullanılan Teknolojiler</h2>
              <ul className="tag-list tag-list--flush">
                {project.technologies.map((tech) => (
                  <li key={tech}>
                    <span className="tech-pill">{tech}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Beklenen Çıktılar */}
          {project.deliverables.length > 0 && (
            <section className="detail-section">
              <h2>Beklenen Çıktılar</h2>
              <ul className="deliverables">
                {project.deliverables.map((d) => (
                  <li key={d}>
                    <Icon name="check" size={18} /> {d}
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Mevcut Takım */}
          <section className="detail-section">
            <h2>
              <Icon name="users" size={20} /> Mevcut Takım ({project.team.length} / {project.maxMembers})
            </h2>
            <ul className="team-grid">
              {project.team.map((member) => (
                <li key={member.userId}>
                  <Link to={`/profil/${member.userId}`} className="team-member">
                    <Avatar user={{ name: member.name }} size={46} />
                    <div>
                      <strong>{member.name}</strong>
                      <small>{member.role}</small>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          </section>

          {/* Aranan Roller */}
          <section className="detail-section">
            <h2>
              <Icon name="briefcase" size={20} /> Aranan Roller
            </h2>
            {project.lookingFor.length === 0 ? (
              <p className="muted">Bu proje için şu anda açık bir rol ilanı bulunmuyor.</p>
            ) : (
              <ul className="role-cards">
                {project.lookingFor.map((r, i) => (
                  <li key={i} className="role-card">
                    <div>
                      <strong>{r.role}</strong>
                      <span>{r.count} kişi aranıyor</span>
                      <ul className="tag-list tag-list--flush">
                        {r.skills?.map((s) => (
                          <li key={s}>
                            <span className="tag">{s}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {!isOwner && !isMember && project.rawStatus === 'open' && (
                      <button
                        type="button"
                        className="btn btn--outline btn--sm"
                        onClick={() => {
                          setSelectedRole(r.role);
                          setModalOpen(true);
                        }}
                      >
                        Bu Role Başvur
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </section>

          {/* Proje Sahibi Yönetim Paneli: Başvurular & Eşleşen Öğrenciler */}
          {isOwner && (
            <section className="detail-section card" style={{ background: '#f8fafc', padding: '20px' }}>
              <h2>
                <Icon name="users" size={20} /> Takım Başvuruları ({applications.length})
              </h2>
              {applications.length === 0 ? (
                <p className="muted">Henüz bu projeye gelen bir başvuru yok.</p>
              ) : (
                <ul style={{ listStyle: 'none', padding: 0 }}>
                  {applications.map((app) => (
                    <li
                      key={app.application_id}
                      style={{
                        padding: '12px',
                        background: 'white',
                        borderRadius: '8px',
                        marginBottom: '8px',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                      }}
                    >
                      <div>
                        <strong>{app.first_name} {app.last_name}</strong>
                        <p style={{ margin: '4px 0', fontSize: '13px', color: '#475569' }}>{app.message}</p>
                        <small style={{ color: '#94a3b8' }}>Durum: {app.status}</small>
                      </div>

                      {app.status === 'pending' && (
                        <div style={{ display: 'flex', gap: '8px' }}>
                          <button
                            type="button"
                            className="btn btn--primary btn--sm"
                            onClick={() => handleApplicationDecision(app.application_id, 'accepted')}
                          >
                            Kabul Et
                          </button>
                          <button
                            type="button"
                            className="btn btn--outline btn--sm"
                            style={{ color: '#c00' }}
                            onClick={() => handleApplicationDecision(app.application_id, 'rejected')}
                          >
                            Reddet
                          </button>
                        </div>
                      )}
                    </li>
                  ))}
                </ul>
              )}

              {/* Eşleşme Algoritması Önerileri */}
              {matchCandidates.length > 0 && (
                <div style={{ marginTop: '24px' }}>
                  <h3>Yetenek Eşleşmesi Önerilen Öğrenciler</h3>
                  <p style={{ fontSize: '13px', color: '#64748b' }}>
                    Projenizin aradığı yeteneklerle profili en çok örtüşen FSMVÜ öğrencileri:
                  </p>
                  <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '10px' }}>
                    {matchCandidates.map((c) => (
                      <Link
                        key={c.user_id}
                        to={`/profil/${c.user_id}`}
                        style={{
                          background: 'white',
                          padding: '10px 14px',
                          borderRadius: '8px',
                          textDecoration: 'none',
                          border: '1px solid #e2e8f0',
                        }}
                      >
                        <strong>{c.first_name} {c.last_name}</strong>
                        <div style={{ fontSize: '12px', color: '#2563eb' }}>
                          {c.eslesen_yetenek} uyuşan yetenek
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </section>
          )}

          {/* Yorumlar Bölümü */}
          <CommentSection post={{ id: project.id, comments: [] }} />
        </article>
      </div>

      {/* Başvuru Modalı */}
      <ApplyModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        project={project}
        role={selectedRole}
      />
    </div>
  );
}
