import { Navigate, Route, Routes } from 'react-router-dom';
import ProtectedRoute from './components/common/ProtectedRoute';
import AppLayout from './components/layout/AppLayout';
import AuthPage from './pages/AuthPage';
import FeedPage from './pages/FeedPage';
import ExplorePage from './pages/ExplorePage';
import EventsPage from './pages/EventsPage';
import ProjectDetailPage from './pages/ProjectDetailPage';
import ProfilePage from './pages/ProfilePage';
import NewProjectPage from './pages/NewProjectPage';

export default function App() {
  return (
    <Routes>
      <Route path="/giris" element={<AuthPage />} />

      <Route
        element={
          <ProtectedRoute>
            <AppLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<FeedPage />} />
        <Route path="kesfet" element={<ExplorePage />} />
        <Route path="etkinlikler" element={<EventsPage />} />
        <Route path="proje/:projectId" element={<ProjectDetailPage />} />
        <Route path="profil" element={<ProfilePage />} />
        <Route path="profil/:userId" element={<ProfilePage />} />
        <Route path="yeni-proje" element={<NewProjectPage />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
