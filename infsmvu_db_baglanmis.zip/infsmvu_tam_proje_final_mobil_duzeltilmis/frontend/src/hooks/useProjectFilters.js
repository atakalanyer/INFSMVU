import { useCallback, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { FACULTIES } from '../services/mockData';
import { EMPTY_FILTERS } from '../utils/filterProjects';

/**
 * Filtre durumunu URL'de tutar (paylaşılabilir/yenilemeye dayanıklı):
 * ?q=...&skill=Backend&skill=Frontend&faculty=...&dept=...&type=TEKNOFEST&open=1
 */
export function useProjectFilters() {
  const [params, setParams] = useSearchParams();

  const filters = useMemo(
    () => ({
      query: params.get('q') || '',
      skills: params.getAll('skill'),
      faculty: params.get('faculty') || '',
      department: params.get('dept') || '',
      types: params.getAll('type'),
      recruitingOnly: params.get('open') === '1',
    }),
    [params]
  );

  const write = useCallback(
    (next) => {
      const p = new URLSearchParams();
      if (next.query) p.set('q', next.query);
      next.skills.forEach((s) => p.append('skill', s));
      if (next.faculty) p.set('faculty', next.faculty);
      if (next.department) p.set('dept', next.department);
      next.types.forEach((t) => p.append('type', t));
      if (next.recruitingOnly) p.set('open', '1');
      setParams(p, { replace: true });
    },
    [setParams]
  );

  const update = useCallback((patch) => write({ ...filters, ...patch }), [filters, write]);

  const toggleIn = (list, value) => (list.includes(value) ? list.filter((x) => x !== value) : [...list, value]);

  const actions = useMemo(
    () => ({
      setQuery: (query) => update({ query }),
      toggleSkill: (skill) => update({ skills: toggleIn(filters.skills, skill) }),
      toggleType: (type) => update({ types: toggleIn(filters.types, type) }),
      setRecruitingOnly: (recruitingOnly) => update({ recruitingOnly }),
      setFaculty: (faculty) => {
        // Seçili bölüm yeni fakülteye ait değilse sıfırla
        const departments = FACULTIES.find((f) => f.name === faculty)?.departments || [];
        const keepDepartment = !faculty || departments.includes(filters.department);
        update({ faculty, department: keepDepartment ? filters.department : '' });
      },
      setDepartment: (department) => update({ department }),
      clearAll: () => write(EMPTY_FILTERS),
    }),
    [filters, update, write]
  );

  return { filters, actions };
}
