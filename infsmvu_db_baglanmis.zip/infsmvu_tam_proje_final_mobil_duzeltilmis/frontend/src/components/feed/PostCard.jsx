import { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { usePosts } from '../../context/PostsContext';
import { timeAgo } from '../../utils/format';
import Avatar from '../common/Avatar';
import Icon from '../common/Icon';
import ProjectImage from '../common/ProjectImage';
import RoleBadge from '../common/RoleBadge';
import CommentSection from './CommentSection';

export default function PostCard({ post }) {
  const { isLiked, isSaved, toggleLike, toggleSave } = usePosts();
  const [showComments, setShowComments] = useState(false);
  const [burst, setBurst] = useState(false);
  const burstTimer = useRef(null);

  if (!post) return null;

  const liked = isLiked(post.id);
  const saved = isSaved(post.id);
  const isRecruiting = post.rawStatus === 'open' || post.status === 'Takım Arıyor';
  const openRolesCount = Array.isArray(post.lookingFor)
    ? post.lookingFor.reduce((sum, r) => sum + (Number(r.count) || 1), 0)
    : 0;

  // Görsele çift tıklayınca beğeni animasyonu
  const handleDoubleClick = () => {
    if (!liked) toggleLike(post.id);
    setBurst(true);
    clearTimeout(burstTimer.current);
    burstTimer.current = setTimeout(() => setBurst(false), 750);
  };

  const handleShare = async () => {
    const url = `${window.location.origin}/proje/${post.id}`;
    try {
      await navigator.clipboard.writeText(url);
      alert('Proje bağlantısı panoya kopyalandı!');
    } catch {
      /* ignore */
    }
  };

  return (
    <article className="post-card">
      <header className="post-card__header">
        <Link to={`/profil/${post.ownerId}`} className="post-card__author">
          <Avatar user={{ name: post.ownerName }} size={44} ring />
          <div>
            <strong>{post.ownerName}</strong>
            <span>{post.department}</span>
          </div>
        </Link>
        <div className="post-card__meta">
          <RoleBadge role="student" />
          <time dateTime={post.createdAt}>{timeAgo(post.createdAt)}</time>
        </div>
      </header>

      <div className="post-card__media" onDoubleClick={handleDoubleClick}>
        <ProjectImage project={post} />
        <span className="post-card__type">{post.type}</span>
        <span className={`post-card__status ${isRecruiting ? 'is-recruiting' : ''}`}>
          {isRecruiting && openRolesCount > 0 ? `${openRolesCount} kişi aranıyor` : post.status}
        </span>
        {burst && (
          <span className="post-card__burst" aria-hidden="true">
            <Icon name="heart" size={84} filled />
          </span>
        )}
      </div>

      <div className="post-card__actions">
        <div className="post-card__actions-left">
          <button
            type="button"
            className={`action-btn ${liked ? 'is-liked' : ''}`}
            onClick={() => toggleLike(post.id)}
            aria-pressed={liked}
            aria-label={liked ? 'Beğenmekten vazgeç' : 'Beğen'}
          >
            <Icon name="heart" size={25} filled={liked} />
          </button>
          <button
            type="button"
            className="action-btn"
            onClick={() => setShowComments((s) => !s)}
            aria-expanded={showComments}
            aria-label="Yorumlar"
          >
            <Icon name="comment" size={25} />
          </button>
          <button type="button" className="action-btn" onClick={handleShare} aria-label="Bağlantıyı kopyala">
            <Icon name="share" size={24} />
          </button>
        </div>

        <button
          type="button"
          className={`action-btn ${saved ? 'is-saved' : ''}`}
          onClick={() => toggleSave(post.id)}
          aria-pressed={saved}
          aria-label={saved ? 'Kaydedilenlerden çıkar' : 'Kaydet'}
        >
          <Icon name="bookmark" size={25} filled={saved} />
        </button>
      </div>

      <div className="post-card__body">
        <div className="post-card__likes">
          <strong>{post.likes} beğeni</strong>
        </div>

        <h3 className="post-card__title">
          <Link to={`/proje/${post.id}`}>{post.title}</Link>
        </h3>

        <p className="post-card__text">{post.summary}</p>

        {Array.isArray(post.tags) && post.tags.length > 0 && (
          <ul className="tag-list tag-list--flush">
            {post.tags.map((tag) => (
              <li key={tag}>
                <Link to={`/kesfet?q=${encodeURIComponent(tag)}`} className="tag">
                  #{tag}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>

      {showComments && <CommentSection post={post} />}
    </article>
  );
}
