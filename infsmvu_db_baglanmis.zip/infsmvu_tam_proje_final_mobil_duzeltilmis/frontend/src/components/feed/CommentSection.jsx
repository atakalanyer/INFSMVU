import { useEffect, useState } from 'react';
import { postsApi } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import Avatar from '../common/Avatar';
import Icon from '../common/Icon';

export default function CommentSection({ post }) {
  const { user } = useAuth();
  const [comments, setComments] = useState([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!post?.id) return;
    setLoading(true);
    postsApi
      .getComments(post.id)
      .then((data) => {
        setComments(Array.isArray(data) ? data : []);
      })
      .catch(() => {
        setComments([]);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [post?.id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!text.trim() || submitting) return;
    setSubmitting(true);

    try {
      await postsApi.addComment(post.id, text.trim());
      setText('');
      // Yorumları tazele
      const refreshed = await postsApi.getComments(post.id);
      setComments(Array.isArray(refreshed) ? refreshed : []);
    } catch (err) {
      alert(err.message || 'Yorum gönderilemedi.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="comment-section" style={{ marginTop: '20px', borderTop: '1px solid #f1f5f9', paddingTop: '16px' }}>
      <h3 style={{ fontSize: '15px', fontWeight: 600, marginBottom: '12px' }}>
        Yorumlar ({comments.length})
      </h3>

      {/* Yorum Yazma Formu */}
      <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '10px', marginBottom: '16px' }}>
        <Avatar user={user} size={36} />
        <input
          type="text"
          placeholder="Düşüncelerini veya sorularını paylaş..."
          value={text}
          onChange={(e) => setText(e.target.value)}
          style={{ flex: 1, padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '14px' }}
        />
        <button
          type="submit"
          className="btn btn--primary btn--sm"
          disabled={submitting || !text.trim()}
        >
          {submitting ? '...' : 'Gönder'}
        </button>
      </form>

      {/* Yorumlar Listesi */}
      {loading ? (
        <p style={{ fontSize: '13px', color: '#64748b' }}>Yorumlar yükleniyor...</p>
      ) : comments.length === 0 ? (
        <p style={{ fontSize: '13px', color: '#94a3b8' }}>Henüz yorum yapılmamış. İlk yorumu sen yaz!</p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {comments.map((c) => (
            <div key={c.comment_id} style={{ display: 'flex', gap: '10px', alignItems: 'flex-start' }}>
              <Avatar user={{ name: `${c.first_name} ${c.last_name}` }} size={32} />
              <div style={{ background: '#f8fafc', padding: '8px 12px', borderRadius: '8px', flex: 1 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2px' }}>
                  <strong style={{ fontSize: '13px' }}>{c.first_name} {c.last_name}</strong>
                  <small style={{ fontSize: '11px', color: '#94a3b8' }}>
                    {new Date(c.created_at).toLocaleDateString('tr-TR')}
                  </small>
                </div>
                <p style={{ margin: 0, fontSize: '13px', color: '#334155' }}>{c.content}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
