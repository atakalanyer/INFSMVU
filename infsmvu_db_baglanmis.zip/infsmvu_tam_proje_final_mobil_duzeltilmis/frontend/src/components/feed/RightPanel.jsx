import { useMemo, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FSMVU_EVENTS } from '../../services/mockData';
import { eventsApi } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { usePosts } from '../../context/PostsContext';
import Icon from '../common/Icon';

const ROLE_CARDS = {
  student: {
    title: 'Takımını Bul',
    text: 'Yeteneklerini profiline ekle; FSMVÜ projelerinde seninle eşleşen ilanlar öne çıksın.',
    cta: 'Projeleri Keşfet',
    to: '/kesfet',
    icon: 'sparkles',
  },
  club_admin: {
    title: 'Kulübün İçin Ekip Kur',
    text: 'Kulüp etkinliklerini yayınla, Cevizlibağ ve Haliç kampüslerinden öğrencileri davet et.',
    cta: 'Etkinlik Yayınla',
    to: '/etkinlikler',
    icon: 'calendar',
  },
  academic: {
    title: 'Akademik Danışmanlık',
    text: 'Öğrencilerin TEKNOFEST ve bitirme projelerine danışmanlık yapın veya proje başlatın.',
    cta: 'Projeleri İncele',
    to: '/kesfet',
    icon: 'users',
  },
};

export default function RightPanel() {
  const { user } = useAuth();
  const { posts } = usePosts();
  const [upcomingEvents, setUpcomingEvents] = useState([]);

  useEffect(() => {
    eventsApi
      .getAll({ when: 'upcoming' })
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setUpcomingEvents(data.slice(0, 3));
        } else {
          // Backend'de henüz etkinlik yoksa mock göster
          setUpcomingEvents(FSMVU_EVENTS.slice(0, 3));
        }
      })
      .catch(() => {
        setUpcomingEvents(FSMVU_EVENTS.slice(0, 3));
      });
  }, []);

  const trending = useMemo(() => {
    const counts = {};
    posts.forEach((p) => {
      if (Array.isArray(p.tags)) {
        p.tags.forEach((t) => {
          counts[t] = (counts[t] || 0) + 1;
        });
      }
    });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  }, [posts]);

  const card = ROLE_CARDS[user?.role] || ROLE_CARDS.student;

  return (
    <aside className="right-panel" aria-label="Yan panel">
      {/* 1. Rol Kartı */}
      <section className="card card--accent">
        <span className="card__icon">
          <Icon name={card.icon} size={20} />
        </span>
        <h3>{card.title}</h3>
        <p>{card.text}</p>
        <Link to={card.to} className="btn btn--light btn--sm">
          {card.cta}
        </Link>
      </section>

      {/* 2. Kampüs Etkinlikleri */}
      <section className="card events-card">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
          <h3 className="card__title" style={{ fontSize: '15px' }}>
            <Icon name="calendar" size={18} /> Kampüs Etkinlikleri
          </h3>
          <Link to="/etkinlikler" style={{ fontSize: '12px', fontWeight: '700', color: '#1f5a96' }}>
            Tümünü Gör →
          </Link>
        </div>

        <div className="events-list">
          {upcomingEvents.map((ev, i) => (
            <article key={ev.event_id || ev.id || i} className="event-item">
              <div className="event-item__top">
                <span className="event-item__badge">{ev.category || ev.badge || 'Etkinlik'}</span>
                <span className="event-item__date">
                  {ev.starts_at ? new Date(ev.starts_at).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' }) : ev.date}
                </span>
              </div>
              <h4 className="event-item__title">{ev.title}</h4>
              <p className="event-item__meta">
                <span>📍 {ev.location}</span>
                <small>Düzenleyen: {ev.club_name || ev.club}</small>
              </p>
            </article>
          ))}
        </div>
      </section>

      {/* 3. Gündemdeki Yetenekler */}
      <section className="card">
        <h3 className="card__title">
          <Icon name="trendingUp" size={18} /> Popüler Yetenekler
        </h3>
        <ul className="trend-list">
          {trending.length > 0 ? (
            trending.map(([tag, count]) => (
              <li key={tag}>
                <Link to={`/kesfet?q=${encodeURIComponent(tag)}`}>
                  <span>#{tag}</span>
                  <small>{count} proje</small>
                </Link>
              </li>
            ))
          ) : (
            <li style={{ fontSize: '13px', color: '#94a3b8' }}>Henüz etiket bulunmuyor.</li>
          )}
        </ul>
      </section>
    </aside>
  );
}
