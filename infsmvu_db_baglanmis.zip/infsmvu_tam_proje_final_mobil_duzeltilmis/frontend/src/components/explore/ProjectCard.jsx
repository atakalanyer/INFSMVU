import { Link } from 'react-router-dom';
import Icon from '../common/Icon';
import ProjectImage from '../common/ProjectImage';

export default function ProjectCard({ project, matchedSkills = [] }) {
  if (!project) return null;

  const isRecruiting = project.rawStatus === 'open' || project.status === 'Takım Arıyor';
  const openRolesCount = Array.isArray(project.lookingFor)
    ? project.lookingFor.reduce((sum, r) => sum + (Number(r.count) || 1), 0)
    : 0;

  return (
    <article className="project-card card">
      <Link to={`/proje/${project.id}`} className="project-card__image-link" tabIndex={-1}>
        <ProjectImage project={project} />
        <span className="project-card__type">{project.type}</span>
        <span className={`project-card__status ${isRecruiting ? 'is-recruiting' : ''}`}>
          {isRecruiting && openRolesCount > 0 ? `${openRolesCount} kişi aranıyor` : project.status}
        </span>
      </Link>

      <div className="project-card__body">
        <div className="project-card__meta">
          <span>{project.department || 'FSMVÜ'}</span>
          <span>·</span>
          <span>{project.ownerName || 'FSMVÜ'}</span>
        </div>

        <h3 className="project-card__title">
          <Link to={`/proje/${project.id}`}>{project.title}</Link>
        </h3>

        <p className="project-card__summary">{project.summary}</p>

        {/* Eşleşen yetenekler vurgusu */}
        {matchedSkills.length > 0 && (
          <div className="project-card__match">
            <Icon name="check" size={14} />
            <span>{matchedSkills.length} uyuşan yetenek: <strong>{matchedSkills.slice(0, 3).join(', ')}</strong></span>
          </div>
        )}

        {Array.isArray(project.tags) && project.tags.length > 0 && (
          <ul className="tag-list tag-list--flush">
            {project.tags.slice(0, 4).map((t) => (
              <li key={t}>
                <span className="tag">#{t}</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <footer className="project-card__foot">
        <div className="project-card__stats">
          <span>
            <Icon name="heart" size={16} /> {project.likes || 0}
          </span>
          <span>
            <Icon name="users" size={16} /> {project.memberCount || 1} / {project.maxMembers || 5} üye
          </span>
        </div>

        <Link to={`/proje/${project.id}`} className="btn btn--outline btn--sm">
          İncele →
        </Link>
      </footer>
    </article>
  );
}
