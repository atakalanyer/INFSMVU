import { DEPARTMENTS, FACULTIES, PROJECT_TYPES, SKILLS } from '../../services/mockData';
import Icon from '../common/Icon';

/**
 * Eşleşme filtreleri: yetenek (çoklu), fakülte/bölüm, proje türü (çoklu), takım arayanlar.
 * Tüm durum üst bileşendeki useProjectFilters hook'undan gelir.
 */
export default function FilterPanel({ filters, actions, skillCounts }) {
  const departmentOptions = filters.faculty
    ? (FACULTIES.find((f) => f.name === filters.faculty)?.departments || []).map((name) => ({ name }))
    : DEPARTMENTS;

  return (
    <div className="filter-panel">
      <section className="filter-group">
        <h3>Yetenek &amp; Teknoloji</h3>
        <p className="filter-group__hint">Birden fazla seçebilirsin; çok eşleşen projeler üstte çıkar.</p>
        <div className="chip-grid" role="group" aria-label="Yetenek filtresi">
          {SKILLS.map((skill) => {
            const active = filters.skills.includes(skill);
            return (
              <button
                key={skill}
                type="button"
                className={`filter-chip ${active ? 'is-active' : ''}`}
                aria-pressed={active}
                onClick={() => actions.toggleSkill(skill)}
              >
                {active && <Icon name="check" size={14} />}
                {skill}
                <small>{skillCounts[skill] || 0}</small>
              </button>
            );
          })}
        </div>
      </section>

      <section className="filter-group">
        <h3>Fakülte / Bölüm</h3>
        <label className="select-field">
          <span>Fakülte</span>
          <select value={filters.faculty} onChange={(e) => actions.setFaculty(e.target.value)}>
            <option value="">Tüm fakülteler</option>
            {FACULTIES.map((f) => (
              <option key={f.id} value={f.name}>
                {f.name}
              </option>
            ))}
          </select>
        </label>
        <label className="select-field">
          <span>Bölüm</span>
          <select value={filters.department} onChange={(e) => actions.setDepartment(e.target.value)}>
            <option value="">Tüm bölümler</option>
            {departmentOptions.map((d) => (
              <option key={d.name} value={d.name}>
                {d.name}
              </option>
            ))}
          </select>
        </label>
      </section>

      <section className="filter-group">
        <h3>Proje Türü</h3>
        <div className="check-list">
          {PROJECT_TYPES.map((type) => (
            <label key={type} className="check-row">
              <input
                type="checkbox"
                checked={filters.types.includes(type)}
                onChange={() => actions.toggleType(type)}
              />
              <span>{type}</span>
            </label>
          ))}
        </div>
      </section>

      <section className="filter-group">
        <label className="switch-row">
          <span>
            <strong>Sadece takım arayanlar</strong>
            <small>Açık pozisyonu olan projeler</small>
          </span>
          <input
            type="checkbox"
            role="switch"
            checked={filters.recruitingOnly}
            onChange={(e) => actions.setRecruitingOnly(e.target.checked)}
          />
        </label>
      </section>
    </div>
  );
}
