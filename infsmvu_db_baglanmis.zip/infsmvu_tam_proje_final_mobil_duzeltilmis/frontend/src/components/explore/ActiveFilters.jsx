import Icon from '../common/Icon';

/**
 * Aktif filtreleri çip olarak gösterir; tek tıkla kaldırır, "Filtreleri Temizle" ile sıfırlar.
 */
export default function ActiveFilters({ filters, actions }) {
  const chips = [];

  if (filters.query.trim()) {
    chips.push({ key: 'q', label: `Arama: “${filters.query.trim()}”`, remove: () => actions.setQuery('') });
  }
  filters.skills.forEach((s) =>
    chips.push({ key: `s-${s}`, label: s, remove: () => actions.toggleSkill(s) })
  );
  if (filters.faculty) {
    chips.push({ key: 'f', label: filters.faculty, remove: () => actions.setFaculty('') });
  }
  if (filters.department) {
    chips.push({ key: 'd', label: filters.department, remove: () => actions.setDepartment('') });
  }
  filters.types.forEach((t) => chips.push({ key: `t-${t}`, label: t, remove: () => actions.toggleType(t) }));
  if (filters.recruitingOnly) {
    chips.push({ key: 'o', label: 'Takım arayanlar', remove: () => actions.setRecruitingOnly(false) });
  }

  if (chips.length === 0) return null;

  return (
    <div className="active-filters" aria-label="Aktif filtreler">
      {chips.map((chip) => (
        <button key={chip.key} type="button" className="active-chip" onClick={chip.remove}>
          {chip.label}
          <Icon name="x" size={14} />
          <span className="sr-only"> filtresini kaldır</span>
        </button>
      ))}
      <button type="button" className="link-btn active-filters__clear" onClick={actions.clearAll}>
        Filtreleri Temizle
      </button>
    </div>
  );
}
