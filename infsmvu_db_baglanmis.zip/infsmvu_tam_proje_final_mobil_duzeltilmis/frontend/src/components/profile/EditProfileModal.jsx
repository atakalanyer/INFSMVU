import { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { usersApi, lookupApi } from '../../services/api';
import FormField from '../auth/FormField';
import Icon from '../common/Icon';

export default function EditProfileModal({ open, onClose }) {
  const { user, updateProfile } = useAuth();
  const [form, setForm] = useState({
    first_name: '',
    last_name: '',
    headline: '',
    bio: '',
    avatar_url: '',
    cover_url: '',
    github_url: '',
    linkedin_url: '',
    portfolio_url: '',
    is_open_to_team: true,
  });

  const [skills, setSkills] = useState([]);
  const [allSkills, setAllSkills] = useState([]);
  const [selectedSkillId, setSelectedSkillId] = useState('');
  const [skillLevel, setSkillLevel] = useState(2);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (user) {
      setForm({
        first_name: user.first_name || user.name?.split(' ')[0] || '',
        last_name: user.last_name || user.name?.split(' ').slice(1).join(' ') || '',
        headline: user.headline || '',
        bio: user.bio || '',
        avatar_url: user.avatar || user.avatar_url || '',
        cover_url: user.cover || user.cover_url || '',
        github_url: user.links?.github || '',
        linkedin_url: user.links?.linkedin || '',
        portfolio_url: user.links?.portfolio || '',
        is_open_to_team: user.is_open_to_team !== false,
      });
      setSkills(user.skills || []);
    }
  }, [user]);

  useEffect(() => {
    lookupApi.getSkills().then((res) => {
      if (Array.isArray(res) && res.length > 0) {
        setAllSkills(res);
        setSelectedSkillId(res[0].skill_id);
      }
    }).catch(() => {});
  }, []);

  if (!open) return null;

  const handleAddSkill = async () => {
    if (!selectedSkillId) return;
    try {
      await usersApi.addSkill(selectedSkillId, skillLevel);
      const chosen = allSkills.find((s) => s.skill_id === Number(selectedSkillId));
      if (chosen && !skills.some((s) => s.skill_id === chosen.skill_id)) {
        setSkills([...skills, { ...chosen, level: skillLevel }]);
      }
    } catch (err) {
      alert(err.message || 'Yetenek eklenemedi.');
    }
  };

  const handleRemoveSkill = async (skillId) => {
    try {
      await usersApi.removeSkill(skillId);
      setSkills(skills.filter((s) => s.skill_id !== skillId));
    } catch (err) {
      alert(err.message || 'Yetenek silinemedi.');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSaving(true);

    try {
      await updateProfile({
        ...form,
        is_open_to_team: form.is_open_to_team ? 1 : 0,
      });
      onClose();
    } catch (err) {
      setError(err.message || 'Profil güncellenemedi.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card card" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '580px', width: '90%', maxHeight: '90vh', overflowY: 'auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h2>Profili Düzenle</h2>
          <button type="button" className="icon-btn" onClick={onClose}>✕</button>
        </div>

        {error && (
          <div className="alert alert--danger" style={{ color: '#c00', fontSize: '13px', marginBottom: '12px' }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <FormField
              id="ep-fn"
              label="Ad"
              value={form.first_name}
              onChange={(e) => setForm({ ...form, first_name: e.target.value })}
            />
            <FormField
              id="ep-ln"
              label="Soyad"
              value={form.last_name}
              onChange={(e) => setForm({ ...form, last_name: e.target.value })}
            />
          </div>

          <FormField
            id="ep-head"
            label="Profil Başlığı / Ünvan"
            placeholder="Örn: Bilgisayar Mühendisliği 3. Sınıf · Mobil Geliştirici"
            value={form.headline}
            onChange={(e) => setForm({ ...form, headline: e.target.value })}
          />

          <div className="form-group" style={{ marginBottom: '16px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, marginBottom: '6px' }}>
              Biyografi &amp; Hakkımda
            </label>
            <textarea
              rows={3}
              placeholder="İlgi duyduğunuz alanlar, geçmiş TEKNOFEST tecrübeleriniz..."
              value={form.bio}
              onChange={(e) => setForm({ ...form, bio: e.target.value })}
              style={{ width: '100%', padding: '10px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
            />
          </div>

          <FormField
            id="ep-avatar"
            label="Profil Fotoğrafı URL"
            placeholder="https://..."
            value={form.avatar_url}
            onChange={(e) => setForm({ ...form, avatar_url: e.target.value })}
          />

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <FormField
              id="ep-gh"
              label="GitHub Profili"
              placeholder="https://github.com/..."
              value={form.github_url}
              onChange={(e) => setForm({ ...form, github_url: e.target.value })}
            />
            <FormField
              id="ep-li"
              label="LinkedIn Profili"
              placeholder="https://linkedin.com/in/..."
              value={form.linkedin_url}
              onChange={(e) => setForm({ ...form, linkedin_url: e.target.value })}
            />
          </div>

          {/* Yetenek Yönetimi */}
          <div style={{ borderTop: '1px solid #e2e8f0', paddingTop: '16px', marginTop: '16px', marginBottom: '16px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: 700, marginBottom: '8px' }}>
              Yetenekler &amp; Uzmanlık Seviyeniz
            </label>

            <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
              <select
                value={selectedSkillId}
                onChange={(e) => setSelectedSkillId(e.target.value)}
                style={{ flex: 1, padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
              >
                {allSkills.map((s) => (
                  <option key={s.skill_id} value={s.skill_id}>{s.name} ({s.category || 'Genel'})</option>
                ))}
              </select>

              <select
                value={skillLevel}
                onChange={(e) => setSkillLevel(Number(e.target.value))}
                style={{ width: '120px', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
              >
                <option value={1}>1 - Başlangıç</option>
                <option value={2}>2 - Orta</option>
                <option value={3}>3 - İleri</option>
                <option value={4}>4 - Uzman</option>
              </select>

              <button type="button" className="btn btn--outline btn--sm" onClick={handleAddSkill}>
                Ekle
              </button>
            </div>

            <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
              {skills.map((s) => (
                <span
                  key={s.skill_id}
                  style={{
                    background: '#e0f2fe',
                    color: '#0369a1',
                    padding: '4px 10px',
                    borderRadius: '999px',
                    fontSize: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                  }}
                >
                  {s.name} (Lvl {s.level || 1})
                  <button
                    type="button"
                    onClick={() => handleRemoveSkill(s.skill_id)}
                    style={{ border: 'none', background: 'none', cursor: 'pointer', fontWeight: 'bold' }}
                  >
                    ✕
                  </button>
                </span>
              ))}
            </div>
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={form.is_open_to_team}
                onChange={(e) => setForm({ ...form, is_open_to_team: e.target.checked })}
              />
              <span>Yeni projelere ve takım davetlerine açığım (Eşleşme aramasında görünür)</span>
            </label>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
            <button type="button" className="btn btn--outline" onClick={onClose} disabled={saving}>
              İptal
            </button>
            <button type="submit" className="btn btn--primary" disabled={saving}>
              {saving ? 'Kaydediliyor...' : 'Değişiklikleri Kaydet'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
