import { NavLink } from 'react-router-dom';
import Icon from '../common/Icon';

const ITEMS = [
  { to: '/', label: 'Akış', icon: 'home', end: true },
  { to: '/kesfet', label: 'Keşfet', icon: 'compass' },
  { to: '/etkinlikler', label: 'Etkinlik', icon: 'calendar' },
  { to: '/yeni-proje', label: 'Paylaş', icon: 'plus', primary: true },
  { to: '/profil', label: 'Profil', icon: 'user' },
];

export default function BottomNav() {
  return (
    <nav className="bottom-nav" aria-label="Alt gezinme">
      {ITEMS.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          end={item.end}
          className={({ isActive }) =>
            `bottom-nav__item ${item.primary ? 'bottom-nav__item--primary' : ''} ${isActive ? 'is-active' : ''}`
          }
        >
          <Icon name={item.icon} size={item.primary ? 24 : 22} />
          <span>{item.label}</span>
        </NavLink>
      ))}
    </nav>
  );
}
