import { useEffect, useRef, useState, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { notificationsApi } from '../../services/api';
import Icon from '../common/Icon';
import Avatar from '../common/Avatar';
import RoleBadge from '../common/RoleBadge';
import FsmvuLogo from '../common/FsmvuLogo';

export default function Topbar() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifications, setNotifications] = useState([]);
  const menuRef = useRef(null);
  const notifRef = useRef(null);

  const fetchUnread = useCallback(() => {
    notificationsApi
      .getUnreadCount()
      .then((res) => setUnreadCount(Number(res.adet) || 0))
      .catch(() => {});
  }, []);

  useEffect(() => {
    fetchUnread();
    const interval = setInterval(fetchUnread, 30000);
    return () => clearInterval(interval);
  }, [fetchUnread]);

  // Bildirim paneli açıldığında bildirimleri çek
  const toggleNotifications = async () => {
    const nextState = !notifOpen;
    setNotifOpen(nextState);
    if (nextState) {
      try {
        const list = await notificationsApi.getAll();
        setNotifications(Array.isArray(list) ? list : []);
      } catch (err) {
        console.error('Bildirimler yüklenemedi:', err);
      }
    }
  };

  const handleReadAll = async () => {
    try {
      await notificationsApi.readAll();
      setUnreadCount(0);
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: 1 })));
    } catch (err) {
      console.error(err);
    }
  };

  const handleNotificationClick = async (notif) => {
    try {
      if (!notif.is_read) {
        await notificationsApi.readOne(notif.notification_id);
        setUnreadCount((c) => Math.max(0, c - 1));
      }
      setNotifOpen(false);
      if (notif.project_id) {
        navigate(`/proje/${notif.project_id}`);
      } else if (notif.post_id) {
        navigate(`/`);
      } else if (notif.actor_id) {
        navigate(`/profil/${notif.actor_id}`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    const closeAll = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
      if (notifRef.current && !notifRef.current.contains(e.target)) setNotifOpen(false);
    };
    document.addEventListener('mousedown', closeAll);
    return () => document.removeEventListener('mousedown', closeAll);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    const q = query.trim();
    navigate(q ? `/kesfet?q=${encodeURIComponent(q)}` : '/kesfet');
  };

  const getNotifText = (n) => {
    const actor = `${n.actor_first_name || ''} ${n.actor_last_name || ''}`.trim() || 'Bir kullanıcı';
    switch (n.type) {
      case 'like':
        return `${actor} projenizi/gönderinizi beğendi.`;
      case 'comment':
        return `${actor} gönderinize yorum yaptı.`;
      case 'follow':
        return `${actor} sizi takip etmeye başladı.`;
      case 'application':
        return `${actor} projenize takım arkadaşı başvurusu yaptı!`;
      case 'announcement':
        return `Yeni bir kampüs duyurusu paylaşıldı.`;
      default:
        return 'Yeni bir bildirim aldınız.';
    }
  };

  return (
    <header className="topbar">
      <Link to="/" className="topbar__brand" aria-label="Ana sayfa">
        <FsmvuLogo size={34} showText={true} />
      </Link>

      <form className="topbar__search" onSubmit={handleSearch} role="search">
        <Icon name="search" size={18} />
        <input
          type="search"
          placeholder="FSMVÜ projeleri, yetenek veya kişi ara…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          aria-label="Ara"
        />
      </form>

      <div className="topbar__actions">
        {/* Bildirim Çanı */}
        <div className="notif-menu" ref={notifRef} style={{ position: 'relative' }}>
          <button
            type="button"
            className="icon-btn icon-btn--lg"
            aria-label="Bildirimler"
            onClick={toggleNotifications}
          >
            <Icon name="bell" size={21} />
            {unreadCount > 0 && (
              <span
                style={{
                  position: 'absolute',
                  top: '4px',
                  right: '4px',
                  background: '#dc2626',
                  color: 'white',
                  borderRadius: '999px',
                  fontSize: '10px',
                  fontWeight: 700,
                  padding: '2px 5px',
                  lineHeight: 1,
                }}
              >
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>

          {notifOpen && (
            <div
              className="card notif-dropdown"
              style={{
                position: 'absolute',
                right: 0,
                top: '48px',
                width: '320px',
                maxHeight: '400px',
                overflowY: 'auto',
                boxShadow: '0 10px 25px rgba(0,0,0,0.15)',
                zIndex: 1000,
                padding: '12px',
                borderRadius: '12px',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                <strong style={{ fontSize: '14px' }}>Bildirimler</strong>
                {unreadCount > 0 && (
                  <button
                    type="button"
                    className="link-btn"
                    style={{ fontSize: '12px' }}
                    onClick={handleReadAll}
                  >
                    Tümünü Okundu Say
                  </button>
                )}
              </div>

              {notifications.length === 0 ? (
                <p style={{ fontSize: '13px', color: '#64748b', textAlign: 'center', margin: '20px 0' }}>
                  Henüz bildiriminiz yok.
                </p>
              ) : (
                <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                  {notifications.map((n) => (
                    <li
                      key={n.notification_id}
                      onClick={() => handleNotificationClick(n)}
                      style={{
                        padding: '10px',
                        borderRadius: '8px',
                        marginBottom: '6px',
                        cursor: 'pointer',
                        background: n.is_read ? 'transparent' : '#f0f7ff',
                        borderLeft: n.is_read ? 'none' : '3px solid #1f5a96',
                        fontSize: '13px',
                      }}
                    >
                      <p style={{ margin: 0, fontWeight: n.is_read ? 400 : 600 }}>{getNotifText(n)}</p>
                      <small style={{ color: '#94a3b8', fontSize: '11px' }}>
                        {new Date(n.created_at).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                      </small>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>

        {/* Kullanıcı Menüsü */}
        <div className="user-menu" ref={menuRef}>
          <button
            type="button"
            className="user-menu__trigger"
            aria-haspopup="menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((o) => !o)}
          >
            <Avatar user={user} size={36} />
          </button>
          {menuOpen && (
            <div className="user-menu__panel" role="menu">
              <div className="user-menu__head">
                <strong>{user?.name}</strong>
                <span>{user?.email}</span>
                <RoleBadge role={user?.role} />
              </div>
              <Link to="/profil" role="menuitem" onClick={() => setMenuOpen(false)}>
                <Icon name="user" size={18} /> Profilim
              </Link>
              <button type="button" role="menuitem" onClick={signOut}>
                <Icon name="logout" size={18} /> Çıkış Yap
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
