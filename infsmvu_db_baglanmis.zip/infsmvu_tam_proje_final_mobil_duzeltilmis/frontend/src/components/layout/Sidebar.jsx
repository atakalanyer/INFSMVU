import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import Icon from '../common/Icon';
import Avatar from '../common/Avatar';
import RoleBadge from '../common/RoleBadge';
import FsmvuLogo from '../common/FsmvuLogo';

export const NAV_ITEMS = [
  { to: '/', label: 'Akış', icon: 'home', end: true },
  { to: '/kesfet', label: 'Keşfet', icon: 'compass' },
  { to: '/etkinlikler', label: 'Etkinlikler', icon: 'calendar' },
  { to: '/profil', label: 'Profilim', icon: 'user' },
];

export default function Sidebar() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <aside className="sidebar">
      <NavLink to="/" className="sidebar__brand" aria-label="FSMVÜ Proje Ağı ana sayfa">
        <FsmvuLogo size={42} showText={true} />
      </NavLink>

      <nav className="sidebar__nav" aria-label="Ana gezinme">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) => `nav-item ${isActive ? 'is-active' : ''}`}
          >
            <Icon name={item.icon} size={22} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <button type="button" className="btn btn--primary sidebar__cta" onClick={() => navigate('/yeni-proje')}>
        <Icon name="plus" size={20} />
        <span>Yeni Proje Paylaş</span>
      </button>

      <div className="sidebar__user">
        <Avatar user={user} size={40} />
        <div className="sidebar__user-info">
          <strong title={user?.name}>{user?.name}</strong>
          <RoleBadge role={user?.role} />
        </div>
        <button type="button" className="icon-btn" onClick={signOut} aria-label="Çıkış yap" title="Çıkış yap">
          <Icon name="logout" size={18} />
        </button>
      </div>
    </aside>
  );
}
