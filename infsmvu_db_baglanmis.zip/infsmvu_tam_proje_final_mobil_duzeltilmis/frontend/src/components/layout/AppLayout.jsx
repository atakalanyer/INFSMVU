import { Outlet, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import BottomNav from './BottomNav';
import SplashScreen from '../common/SplashScreen';

export default function AppLayout() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [pathname]);

  return (
    <div className="app-shell">
      <SplashScreen />
      <Sidebar />
      <div className="app-shell__content">
        <Topbar />
        <main className="app-main" id="main">
          <Outlet />
        </main>
      </div>
      <BottomNav />
    </div>
  );
}
