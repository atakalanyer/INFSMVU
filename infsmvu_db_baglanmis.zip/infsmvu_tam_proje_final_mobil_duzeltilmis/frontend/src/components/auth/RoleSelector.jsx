import { ROLES, ROLE_LABELS } from '../../services/mockData';
import Icon from '../common/Icon';

const OPTIONS = [
  { value: ROLES.STUDENT, icon: 'graduation', hint: '@stu.fsm.edu.tr' },
  { value: ROLES.CLUB_REP, icon: 'users', hint: '@stu.fsm.edu.tr' },
];

export default function RoleSelector({ value, onChange }) {
  return (
    <div className="role-selector" role="radiogroup" aria-label="Rol seçimi">
      {OPTIONS.map((opt) => (
        <button
          key={opt.value}
          type="button"
          role="radio"
          aria-checked={value === opt.value}
          className={`role-selector__item ${value === opt.value ? 'is-active' : ''}`}
          onClick={() => onChange(opt.value)}
        >
          <Icon name={opt.icon} size={20} />
          <strong>{ROLE_LABELS[opt.value]}</strong>
          <small>{opt.hint}</small>
        </button>
      ))}
    </div>
  );
}
