import { useState } from 'react';
import Icon from '../common/Icon';

/**
 * İkonlu, hata mesajlı ve (parola için) göster/gizle butonlu form alanı.
 * as: 'input' | 'select' | 'textarea'
 */
export default function FormField({
  id,
  label,
  icon,
  error,
  hint,
  type = 'text',
  as = 'input',
  children,
  ...inputProps
}) {
  const [visible, setVisible] = useState(false);
  const isPassword = type === 'password';
  const describedBy = error ? `${id}-error` : hint ? `${id}-hint` : undefined;
  const common = { id, 'aria-invalid': Boolean(error), 'aria-describedby': describedBy, ...inputProps };

  let control;
  if (as === 'select') control = <select {...common}>{children}</select>;
  else if (as === 'textarea') control = <textarea rows={4} {...common} />;
  else control = <input type={isPassword && visible ? 'text' : type} {...common} />;

  return (
    <div className={`field ${error ? 'field--error' : ''}`}>
      <label htmlFor={id} className="field__label">
        {label}
      </label>
      <div className={`field__control ${icon ? '' : 'field__control--plain'}`}>
        {icon && <Icon name={icon} size={18} className="field__icon" />}
        {control}
        {isPassword && (
          <button
            type="button"
            className="field__toggle"
            onClick={() => setVisible((v) => !v)}
            aria-label={visible ? 'Parolayı gizle' : 'Parolayı göster'}
          >
            <Icon name={visible ? 'eyeOff' : 'eye'} size={18} />
          </button>
        )}
      </div>
      {error ? (
        <p className="field__error" id={`${id}-error`} role="alert">
          {error}
        </p>
      ) : hint ? (
        <p className="field__hint" id={`${id}-hint`}>
          {hint}
        </p>
      ) : null}
    </div>
  );
}
