import { useEffect, useState } from 'react';
import FsmvuLogo from './FsmvuLogo';

export default function SplashScreen() {
  const [visible, setVisible] = useState(true);
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    // 1.1 sn sonra kaybolma animasyonu başlar, 1.6 sn'de tamamen kapanır
    const timer1 = setTimeout(() => setFadeOut(true), 1100);
    const timer2 = setTimeout(() => setVisible(false), 1600);
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, []);

  if (!visible) return null;

  return (
    <div className={`splash-screen ${fadeOut ? 'is-fading-out' : ''}`} aria-hidden="true">
      <div className="splash-screen__glow" />
      <div className="splash-screen__content">
        <div className="splash-screen__logo-wrap">
          <FsmvuLogo size={80} showText={false} light={true} />
        </div>
        <div className="splash-screen__text">
          <h1>FSMVÜ PROJE AĞI</h1>
          <p>Fatih Sultan Mehmet Vakıf Üniversitesi</p>
        </div>
        <div className="splash-screen__loader">
          <div className="splash-screen__progress" />
        </div>
      </div>
    </div>
  );
}
