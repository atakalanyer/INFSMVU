import { useState } from 'react';
import { colorFromString, getInitials } from '../../utils/format';

/**
 * Profil resmi; görsel yüklenemezse isim baş harfleriyle yedek avatar gösterir.
 */
export default function Avatar({ user, size = 40, ring = false, className = '' }) {
  const [failed, setFailed] = useState(false);
  const name = user?.name || `${user?.first_name || ''} ${user?.last_name || ''}`.trim() || '?';
  const avatarUrl = user?.avatar || user?.avatar_url;
  const showImage = avatarUrl && !failed;

  return (
    <span
      className={`avatar ${ring ? 'avatar--ring' : ''} ${className}`}
      style={{ width: size, height: size, fontSize: Math.max(11, size * 0.38) }}
    >
      {showImage ? (
        <img src={avatarUrl} alt={name} loading="lazy" onError={() => setFailed(true)} />
      ) : (
        <span className="avatar__fallback" style={{ background: colorFromString(name) }} aria-label={name}>
          {getInitials(name)}
        </span>
      )}
    </span>
  );
}
