const ROLE_MAP = {
  student: 'Öğrenci',
  club_admin: 'Kulüp Temsilcisi',
  club_rep: 'Kulüp Temsilcisi',
  academic: 'Akademisyen',
  admin: 'Yönetici',
  alumni: 'Mezun'
};

export default function RoleBadge({ role }) {
  const normalizedRole = role === 'club_rep' ? 'club_admin' : role;
  const label = ROLE_MAP[normalizedRole] || role || 'Öğrenci';
  return <span className={`role-badge role-badge--${normalizedRole}`}>{label}</span>;
}
