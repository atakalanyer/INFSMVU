export default function FsmvuLogo({ size = 38, showText = true, light = false }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none' }}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        style={{ flexShrink: 0, borderRadius: '12px', boxShadow: '0 4px 12px rgba(16, 27, 48, 0.25)' }}
      >
        <rect width="48" height="48" rx="12" fill={light ? "#ffffff" : "#101b30"} />
        <rect x="2" y="2" width="44" height="44" rx="10" stroke={light ? "#b89758" : "#800020"} strokeWidth="1.5" />
        {/* Geometric Seljuk / FSM Motif */}
        <path
          d="M24 8L30 14L36 20L30 26L24 32L18 26L12 20L18 14L24 8Z"
          stroke="#b89758"
          strokeWidth="1.6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M24 14L28 18L32 22L28 26L24 30L20 26L16 22L20 18L24 14Z"
          fill="#800020"
          stroke="#b89758"
          strokeWidth="1"
        />
        {/* FSM Monogram Core */}
        <text
          x="24"
          y="42"
          textAnchor="middle"
          fill={light ? "#101b30" : "#ffffff"}
          fontSize="9"
          fontWeight="800"
          letterSpacing="0.08em"
          fontFamily="system-ui, sans-serif"
        >
          FSMVÜ
        </text>
      </svg>
      {showText && (
        <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.15 }}>
          <span style={{
            fontSize: '15px',
            fontWeight: '800',
            letterSpacing: '-0.01em',
            color: light ? '#ffffff' : '#101b30'
          }}>
            FSMVÜ <span style={{ color: '#800020' }}>PROJE AĞI</span>
          </span>
          <span style={{
            fontSize: '11px',
            fontWeight: '500',
            color: light ? 'rgba(255,255,255,0.7)' : '#6b7a93',
            letterSpacing: '0.01em'
          }}>
            Fatih Sultan Mehmet Vakıf Üniv.
          </span>
        </div>
      )}
    </div>
  );
}
