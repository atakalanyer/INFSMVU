import { useState } from 'react';

/**
 * Proje görseli; yüklenemezse veya bulunamazsa FSMVÜ kurumsal renklerinde gradyan yedek gösterir.
 */
export default function ProjectImage({ project = {}, className = '', ...rest }) {
  const [failed, setFailed] = useState(false);
  const [from, to] = project.accent || ['#1a2a44', '#2b6cb0'];
  const imageUrl = project.image || project.image_url;

  if (failed || !imageUrl) {
    return (
      <div
        className={`project-image project-image--fallback ${className}`}
        style={{ background: `linear-gradient(135deg, ${from}, ${to})` }}
        role="img"
        aria-label={project.title || 'Proje Görseli'}
      >
        <span>{project.type || 'FSMVÜ Proje'}</span>
      </div>
    );
  }

  return (
    <img
      className={`project-image ${className}`}
      src={imageUrl}
      alt={project.title || 'Proje Görseli'}
      loading="lazy"
      onError={() => setFailed(true)}
      {...rest}
    />
  );
}
