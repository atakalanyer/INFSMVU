import { useState } from 'react';
import { usePosts } from '../../context/PostsContext';
import Icon from '../common/Icon';

export default function ApplyModal({ open, onClose, project, role }) {
  const { sendApplication } = usePosts();
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  if (!open || !project) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    try {
      await sendApplication({
        projectId: project.id,
        role,
        message: message.trim(),
      });
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        setMessage('');
        onClose();
      }, 1500);
    } catch (err) {
      setError(err.message || 'Başvuru gönderilirken bir hata oluştu.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card card" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '480px', width: '90%' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h2>Takıma Katılma Başvurusu</h2>
          <button type="button" className="icon-btn" onClick={onClose}>✕</button>
        </div>

        <p style={{ fontSize: '14px', color: '#475569', marginBottom: '14px' }}>
          <strong>{project.title}</strong> projesine
          {role ? <span> <strong>{role}</strong> rolü için</span> : null} başvuruyorsunuz.
        </p>

        {error && (
          <div className="alert alert--danger" style={{ color: '#c00', fontSize: '13px', marginBottom: '12px' }}>
            {error}
          </div>
        )}

        {success ? (
          <div style={{ textAlign: 'center', padding: '24px 0', color: '#16a34a' }}>
            <Icon name="check" size={40} />
            <h3 style={{ marginTop: '8px' }}>Başvurunuz İletildi!</h3>
            <p style={{ fontSize: '13px' }}>Proje sahibi başvurunuzu onayladığında bildirim alacaksınız.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="form-group" style={{ marginBottom: '16px' }}>
              <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, marginBottom: '6px' }}>
                Proje Sahibine Notunuz / Kendinizi Tanıtın:
              </label>
              <textarea
                rows={4}
                required
                placeholder="Bu projeye nasıl katkı sunabilirsiniz? Daha önceki deneyimleriniz neler?"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                style={{ width: '100%', padding: '10px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
              />
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
              <button type="button" className="btn btn--outline" onClick={onClose} disabled={submitting}>
                Vazgeç
              </button>
              <button type="submit" className="btn btn--primary" disabled={submitting}>
                {submitting ? 'Gönderiliyor...' : 'Başvuruyu Gönder'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
