import { authApi, usersApi } from './api';

const TOKEN_KEY = 'token';
const SESSION_KEY = 'fsmvu_session_user';

export const OTP_LENGTH = 6;
export const OTP_TTL_SECONDS = 900; // 15 dakika (backend ile uyumlu)
export const OTP_RESEND_SECONDS = 45;

export function toSessionUser(kullanici) {
  if (!kullanici) return null;
  return {
    id: kullanici.user_id,
    user_id: kullanici.user_id,
    name: `${kullanici.first_name || ''} ${kullanici.last_name || ''}`.trim(),
    first_name: kullanici.first_name,
    last_name: kullanici.last_name,
    email: kullanici.email,
    role: kullanici.role,
    department: kullanici.department || 'Bölüm Belirtilmedi',
    faculty: kullanici.faculty || '',
    degree: kullanici.degree,
    class_year: kullanici.class_year,
    year: kullanici.class_year ? `${kullanici.class_year}. Sınıf` : '',
    headline: kullanici.headline || `${kullanici.department || 'FSMVÜ'} Öğrencisi`,
    bio: kullanici.bio || '',
    avatar: kullanici.avatar_url || '',
    avatar_url: kullanici.avatar_url,
    cover: kullanici.cover_url || '',
    cover_url: kullanici.cover_url,
    links: {
      github: kullanici.github_url || '',
      linkedin: kullanici.linkedin_url || '',
      portfolio: kullanici.portfolio_url || '',
    },
    skills: kullanici.skills || [],
    is_club_representative: Boolean(kullanici.is_club_representative),
    managed_clubs: kullanici.managed_clubs || [],
  };
}

/**
 * Backend ile gerçek giriş doğrulaması yapar.
 */
export async function checkCredentials({ email, password }) {
  const res = await authApi.login(email, password);
  if (!res.token) {
    throw new Error('Geçersiz sunucu yanıtı: Token alınamadı.');
  }

  localStorage.setItem(TOKEN_KEY, res.token);
  const sessionUser = toSessionUser(res.kullanici);
  localStorage.setItem(SESSION_KEY, JSON.stringify(sessionUser));

  return {
    ok: true,
    account: sessionUser,
    token: res.token,
  };
}

/**
 * Backend ile gerçek kullanıcı kaydı oluşturur.
 */
export async function registerAccount({ name, email, password, role, department_id, class_year }) {
  const parts = (name || '').trim().split(' ');
  const first_name = parts[0] || name;
  const last_name = parts.slice(1).join(' ') || parts[0];

  const res = await authApi.register({
    email,
    password,
    first_name,
    last_name,
    role: role || 'student',
    department_id: department_id || 1,
    class_year: class_year || 1,
  });

  return {
    ok: true,
    user_id: res.user_id,
    mesaj: res.mesaj,
    email_gonderildi: res.email_gonderildi,
    dogrulama_kodu: res.dogrulama_kodu, // ALLOW_DEV_EMAIL_CODE=true ise döner
  };
}

/**
 * Backend üzerinden OTP kodunu tekrar ister.
 */
export async function requestOtp(email) {
  const res = await authApi.resend(email);
  return {
    ok: true,
    mesaj: res.mesaj,
    email_gonderildi: res.email_gonderildi,
    code: res.dogrulama_kodu,
  };
}

/**
 * Backend üzerinden e-posta OTP kodunu doğrular.
 */
export async function verifyOtp({ email, code }) {
  const res = await authApi.verify(email, code);
  return {
    ok: true,
    mesaj: res.mesaj,
  };
}

/**
 * Mevcut kullanıcının en güncel profilini backend'den çeker.
 */
export async function fetchCurrentProfile() {
  const profile = await usersApi.getMe();
  const sessionUser = toSessionUser(profile);
  localStorage.setItem(SESSION_KEY, JSON.stringify(sessionUser));
  return sessionUser;
}
