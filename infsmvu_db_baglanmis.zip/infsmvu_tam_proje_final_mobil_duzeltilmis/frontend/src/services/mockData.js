/**
 * FSMVÜ Proje Ağı — Mock veri katmanı
 * Backend hazır olana kadar tüm ekranlar bu dosyadan beslenir.
 * Kişi adları, projeler ve ünvanlar tamamen kurgusaldır.
 */

/* ------------------------------------------------------------------ */
/* Yardımcılar                                                         */
/* ------------------------------------------------------------------ */
const hoursAgo = (h) => new Date(Date.now() - h * 60 * 60 * 1000).toISOString();
const daysAgo = (d) => hoursAgo(d * 24);

/* ------------------------------------------------------------------ */
/* Sabitler                                                            */
/* ------------------------------------------------------------------ */
export const ROLES = {
  STUDENT: 'student',
  CLUB_REP: 'club_rep',
  ACADEMIC: 'academic',
};

export const ROLE_LABELS = {
  [ROLES.STUDENT]: 'Öğrenci',
  [ROLES.CLUB_REP]: 'Kulüp Temsilcisi',
  [ROLES.ACADEMIC]: 'Akademisyen',
};

export const EMAIL_DOMAINS = {
  student: 'stu.fsm.edu.tr',
  academic: 'fsm.edu.tr',
};

export const DEMO_PASSWORD = 'Fsm12345';

export const PROJECT_TYPES = [
  'TEKNOFEST',
  'Bitirme Projesi',
  'Akademik/Kongre Çalışması',
  'Bağımsız Girişim',
];

export const PROJECT_STATUSES = {
  RECRUITING: 'Takım Arıyor',
  ONGOING: 'Devam Ediyor',
  DONE: 'Tamamlandı',
};

export const FACULTIES = [
  {
    id: 'myo',
    name: 'Meslek Yüksekokulu (Cevizlibağ)',
    departments: [
      'Bilgisayar Programcılığı',
      'Bilişim Güvenliği Teknolojisi',
      'Grafik Tasarımı',
      'Adalet',
      'Sivil Havacılık Kabin Hizmetleri',
      'Çocuk Gelişimi',
    ],
  },
  {
    id: 'muh',
    name: 'Mühendislik Fakültesi',
    departments: [
      'Bilgisayar Mühendisliği',
      'Yazılım Mühendisliği',
      'Elektrik-Elektronik Mühendisliği',
      'Biyomedikal Mühendisliği',
      'İnşaat Mühendisliği',
    ],
  },
  {
    id: 'mim',
    name: 'Mimarlık ve Tasarım Fakültesi',
    departments: [
      'Mimarlık',
      'İç Mimarlık',
      'Şehir ve Bölge Planlama',
    ],
  },
  {
    id: 'gst',
    name: 'Güzel Sanatlar Fakültesi',
    departments: [
      'Grafik Tasarımı',
      'Geleneksel Türk Sanatları',
      'Resim',
    ],
  },
  {
    id: 'itbf',
    name: 'İnsan ve Toplum Bilimleri Fakültesi',
    departments: [
      'Psikoloji',
      'Tarih',
      'Türk Dili ve Edebiyatı',
      'Siyaset Bilimi ve Uluslararası İlişkiler',
    ],
  },
  {
    id: 'iif',
    name: 'İslami İlimler Fakültesi',
    departments: [
      'İslami İlimler (%100 Arapça)',
      'İslami İlimler (%30 Arapça)',
    ],
  },
  {
    id: 'hukuk',
    name: 'Hukuk Fakültesi',
    departments: [
      'Hukuk',
    ],
  },
  {
    id: 'egitim',
    name: 'Eğitim Fakültesi',
    departments: [
      'Rehberlik ve Psikolojik Danışmanlık',
      'Okul Öncesi Öğretmenliği',
      'Özel Eğitim Öğretmenliği',
      'Türkçe Öğretmenliği',
    ],
  },
];

export const DEPARTMENTS = FACULTIES.flatMap((f) =>
  f.departments.map((d) => ({ name: d, faculty: f.name, facultyId: f.id }))
);

export const FSMVU_EVENTS = [
  {
    id: 'e1',
    title: 'FSMVÜ Bilişim Günleri & Hackathon 2026',
    club: 'Yazılım ve İnovasyon Kulübü',
    campus: 'Cevizlibağ Kampüsü',
    location: 'Merkez Konferans Salonu',
    category: 'Hackathon & Yarışma',
    date: '14 Kasım 2026',
    time: '09:30 - 18:30',
    type: 'Yarışma',
    badge: 'Büyük Etkinlik',
    spots: 120,
    registered: 94,
    description: '36 saatlik kesintisiz kodlama maratonu, yapay zekâ, mobil ve web kategorilerinde üniversite içi takımlar yarışıyor. Sektör lideri mentörler ve sürpriz ödüller seni bekliyor!',
    image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'e2',
    title: 'TEKNOFEST 2027 Takım Eşleşme & AR-GE Fikir Çalıştayı',
    club: 'AR-GE ve İnovasyon Topluluğu',
    campus: 'Haliç Kampüsü',
    location: 'D Blok Çok Amaçlı Amfi',
    category: 'Çalıştay',
    date: '21 Kasım 2026',
    time: '14:00 - 17:30',
    type: 'Çalıştay',
    badge: 'TEKNOFEST',
    spots: 80,
    registered: 65,
    description: 'İHA, Savaşan İHA, Sağlıkta Yapay Zekâ ve İnsansız Su Altı Sistemleri kategorileri için ekip arkadaşı arayanlar buluşuyor. Proje fikirlerini sun, takımını tamamla!',
    image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'e3',
    title: 'Yapay Zekâ ve Büyük Dil Modelleri (LLM) Sektör Semineri',
    club: 'Bilişim Teknolojileri Kulübü',
    campus: 'Cevizlibağ Kampüsü',
    location: 'A Blok Amfi 1',
    category: 'Seminer & Konferans',
    date: '28 Kasım 2026',
    time: '13:30 - 16:30',
    type: 'Seminer',
    badge: 'Kariyer',
    spots: 150,
    registered: 132,
    description: 'Büyük teknoloji şirketlerinden davetli kıdemli mühendislerle üretken yapay zekâ, model ince ayarı ve yazılım mühendisliğinde yeni nesil iş akışları.',
    image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'e4',
    title: 'MYO Bilgisayar Programcılığı Proje Sergisi ve Demo Day',
    club: 'Meslek Yüksekokulu Koordinatörlüğü',
    campus: 'Cevizlibağ Kampüsü',
    location: 'MYO Fuaye Alanı',
    category: 'Sergi & Fuar',
    date: '5 Aralık 2026',
    time: '11:00 - 16:00',
    type: 'Sergi',
    badge: 'MYO Özel',
    spots: 200,
    registered: 178,
    description: 'Önlisans Bilgisayar Programcılığı öğrencilerinin dönem boyunca geliştirdiği web, mobil ve veritabanı projelerinin sektör temsilcilerine sergileneceği özel gün.',
    image: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'e5',
    title: 'Girişimcilik ve Kuluçka Merkezi Bilgilendirme Buluşması',
    club: 'Girişimcilik ve Liderlik Kulübü',
    campus: 'Üsküdar Atik Valide Yerleşkesi',
    location: 'Tarihi Konferans Salonu',
    category: 'Girişimcilik',
    date: '12 Aralık 2026',
    time: '14:00 - 16:00',
    type: 'Buluşma',
    badge: 'Kuluçka',
    spots: 90,
    registered: 48,
    description: 'TÜBİTAK 1512 BİGG ve üniversite kuluçka merkezi fonlama süreçleri hakkında uzman yatırımcılar ve patent danışmanlarıyla interaktif soru-cevap seansı.',
    image: 'https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=800&auto=format&fit=crop&q=80',
  },
  {
    id: 'e6',
    title: 'UI/UX Tasarım Sprint & Figma Workshop',
    club: 'Tasarım Topluluğu',
    campus: 'Kandilli Yerleşkesi',
    location: 'Tasarım Stüdyosu 2',
    category: 'Workshop',
    date: '19 Aralık 2026',
    time: '13:00 - 17:00',
    type: 'Workshop',
    badge: 'Atölye',
    spots: 40,
    registered: 38,
    description: 'Kullanıcı araştırmasından interaktif prototip testlerine kadar baştan sona bir mobil uygulama arayüzü tasarımı atölyesi.',
    image: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?w=800&auto=format&fit=crop&q=80',
  },
];

export const SKILLS = [
  'Mobil Yazılım',
  'Backend',
  'Frontend',
  'UI/UX Tasarım',
  'Veri Analizi',
  'Yapay Zekâ',
  'Siber Güvenlik',
  'Gömülü Sistemler',
  'Görüntü İşleme',
  'DevOps',
  'Grafik Tasarım',
  'Proje Yönetimi',
  'Teknik Yazarlık',
];

/* ------------------------------------------------------------------ */
/* Kullanıcılar                                                        */
/* ------------------------------------------------------------------ */
export const users = [
  {
    id: 'u1',
    name: 'Elif Naz Kaya',
    role: ROLES.STUDENT,
    email: 'elif.kaya@stu.fsm.edu.tr',
    password: DEMO_PASSWORD,
    department: 'Bilgisayar Mühendisliği',
    faculty: 'Mühendislik Fakültesi',
    year: '3. Sınıf',
    headline: 'Mobil geliştirici adayı · Sürdürülebilirlik meraklısı',
    bio: 'Flutter ve React Native ile kampüs odaklı çözümler geliştiriyorum. Bitirme projemde atık yönetimini dijitalleştirmeye çalışıyorum. Yeni takım arkadaşlarıyla tanışmaktan keyif alırım.',
    avatar: 'https://i.pravatar.cc/160?img=47',
    cover: 'https://picsum.photos/seed/fsm-cover-u1/1200/320',
    skills: ['Mobil Yazılım', 'UI/UX Tasarım', 'Backend'],
    interests: ['Sürdürülebilirlik', 'Açık Kaynak', 'Hackathon'],
    links: { github: 'https://github.com/elifnazkaya', linkedin: 'https://www.linkedin.com/in/elifnazkaya' },
  },
  {
    id: 'u2',
    name: 'Mehmet Ali Demir',
    role: ROLES.CLUB_REP,
    email: 'mehmetali.demir@stu.fsm.edu.tr',
    password: DEMO_PASSWORD,
    department: 'Bilgisayar Mühendisliği',
    faculty: 'Mühendislik Fakültesi',
    year: '4. Sınıf',
    club: 'FSM Yazılım Topluluğu',
    headline: 'FSM Yazılım Topluluğu Başkanı · Full-stack',
    bio: 'Topluluk etkinlikleri, hackathonlar ve öğrenci girişimleri için ekip kuruyorum. React, Node.js ve bulut mimarileri üzerinde çalışıyorum.',
    avatar: 'https://i.pravatar.cc/160?img=12',
    cover: 'https://picsum.photos/seed/fsm-cover-u2/1200/320',
    skills: ['Frontend', 'Backend', 'DevOps', 'Proje Yönetimi'],
    interests: ['Girişimcilik', 'Topluluk Yönetimi', 'Bulut Mimarisi'],
    links: { github: 'https://github.com/mehmetalidemir', linkedin: 'https://www.linkedin.com/in/mehmetalidemir' },
  },
  {
    id: 'u3',
    name: 'Doç. Dr. Zeynep Aydın',
    role: ROLES.ACADEMIC,
    email: 'zeynep.aydin@fsm.edu.tr',
    password: DEMO_PASSWORD,
    department: 'Bilgisayar Mühendisliği',
    faculty: 'Mühendislik Fakültesi',
    year: 'Doçent',
    headline: 'Doçent · Eğitim teknolojileri ve makine öğrenmesi',
    bio: 'Eğitim teknolojileri, uyarlanabilir öğrenme sistemleri ve açıklanabilir yapay zekâ üzerine çalışıyorum. TEKNOFEST ve lisans bitirme projelerinde danışmanlık veriyorum.',
    avatar: 'https://i.pravatar.cc/160?img=45',
    cover: 'https://picsum.photos/seed/fsm-cover-u3/1200/320',
    skills: ['Yapay Zekâ', 'Veri Analizi', 'Teknik Yazarlık'],
    interests: ['Eğitim Teknolojileri', 'Açıklanabilir YZ', 'Öğrenci Danışmanlığı'],
    links: { github: 'https://github.com/zaydin-lab', linkedin: 'https://www.linkedin.com/in/zeynepaydin' },
  },
  {
    id: 'u4',
    name: 'Burak Yıldız',
    role: ROLES.STUDENT,
    email: 'burak.yildiz@stu.fsm.edu.tr',
    password: DEMO_PASSWORD,
    department: 'Bilgisayar Programcılığı',
    faculty: 'Meslek Yüksekokulu',
    year: '2. Sınıf',
    headline: 'Frontend geliştirici · Oyunlaştırma tutkunu',
    bio: 'Web ve mobil arayüzler geliştiriyorum. Öğrenmeyi eğlenceli hâle getiren uygulamalar tasarlamak en büyük motivasyonum.',
    avatar: 'https://i.pravatar.cc/160?img=15',
    cover: 'https://picsum.photos/seed/fsm-cover-u4/1200/320',
    skills: ['Frontend', 'Mobil Yazılım', 'UI/UX Tasarım'],
    interests: ['Oyunlaştırma', 'Dil Öğrenimi', 'Web Animasyonları'],
    links: { github: 'https://github.com/burakyildiz', linkedin: 'https://www.linkedin.com/in/burakyildiz' },
  },
  {
    id: 'u5',
    name: 'Ayşe Nur Çelik',
    role: ROLES.STUDENT,
    email: 'aysenur.celik@stu.fsm.edu.tr',
    password: DEMO_PASSWORD,
    department: 'Grafik Tasarımı',
    faculty: 'Güzel Sanatlar ve Tasarım Fakültesi',
    year: '3. Sınıf',
    headline: 'UI/UX ve marka tasarımcısı',
    bio: 'Kullanıcı deneyimi, tipografi ve görsel kimlik üzerine çalışıyorum. Yazılımcılarla birlikte ürün tasarlamayı seviyorum.',
    avatar: 'https://i.pravatar.cc/160?img=44',
    cover: 'https://picsum.photos/seed/fsm-cover-u5/1200/320',
    skills: ['UI/UX Tasarım', 'Grafik Tasarım'],
    interests: ['Tipografi', 'Marka Kimliği', 'Tasarım Sistemleri'],
    links: { github: 'https://github.com/aysenurcelik', linkedin: 'https://www.linkedin.com/in/aysenurcelik' },
  },
  {
    id: 'u6',
    name: 'Emre Can Şahin',
    role: ROLES.STUDENT,
    email: 'emrecan.sahin@stu.fsm.edu.tr',
    password: DEMO_PASSWORD,
    department: 'Elektrik-Elektronik Mühendisliği',
    faculty: 'Mühendislik Fakültesi',
    year: '4. Sınıf',
    headline: 'Gömülü sistemler · İHA ve IoT',
    bio: 'Otonom sistemler, sensör füzyonu ve IoT çözümleri geliştiriyorum. TEKNOFEST takımımızın kaptanıyım.',
    avatar: 'https://i.pravatar.cc/160?img=33',
    cover: 'https://picsum.photos/seed/fsm-cover-u6/1200/320',
    skills: ['Gömülü Sistemler', 'Görüntü İşleme', 'Veri Analizi'],
    interests: ['İHA', 'Robotik', 'Akıllı Tarım'],
    links: { github: 'https://github.com/emrecansahin', linkedin: 'https://www.linkedin.com/in/emrecansahin' },
  },
  {
    id: 'u7',
    name: 'Prof. Dr. Hakan Öztürk',
    role: ROLES.ACADEMIC,
    email: 'hakan.ozturk@fsm.edu.tr',
    password: DEMO_PASSWORD,
    department: 'Endüstri Mühendisliği',
    faculty: 'Mühendislik Fakültesi',
    year: 'Profesör',
    headline: 'Profesör · Yöneylem araştırması ve lojistik',
    bio: 'Tedarik zinciri optimizasyonu ve karar destek sistemleri üzerine çalışıyorum. Veri odaklı akademik projeler için disiplinler arası ekipler arıyorum.',
    avatar: 'https://i.pravatar.cc/160?img=60',
    cover: 'https://picsum.photos/seed/fsm-cover-u7/1200/320',
    skills: ['Veri Analizi', 'Proje Yönetimi', 'Teknik Yazarlık'],
    interests: ['Lojistik', 'Optimizasyon', 'Karar Destek Sistemleri'],
    links: { github: 'https://github.com/hozturk-ie', linkedin: 'https://www.linkedin.com/in/hakanozturk' },
  },
  {
    id: 'u8',
    name: 'Selin Arslan',
    role: ROLES.CLUB_REP,
    email: 'selin.arslan@stu.fsm.edu.tr',
    password: DEMO_PASSWORD,
    department: 'Grafik Tasarımı',
    faculty: 'Güzel Sanatlar ve Tasarım Fakültesi',
    year: '3. Sınıf',
    club: 'FSM Tasarım Topluluğu',
    headline: 'FSM Tasarım Topluluğu Temsilcisi · Ürün tasarımı',
    bio: 'Kampüs etkinliklerinin dijital deneyimlerini tasarlıyorum. Tasarımcı ve geliştiricileri bir araya getiren projeler yürütüyorum.',
    avatar: 'https://i.pravatar.cc/160?img=49',
    cover: 'https://picsum.photos/seed/fsm-cover-u8/1200/320',
    skills: ['UI/UX Tasarım', 'Grafik Tasarım', 'Proje Yönetimi'],
    interests: ['Etkinlik Tasarımı', 'Prototipleme', 'Kullanıcı Araştırması'],
    links: { github: 'https://github.com/selinarslan', linkedin: 'https://www.linkedin.com/in/selinarslan' },
  },
  {
    id: 'u9',
    name: 'Yusuf Emir Koç',
    role: ROLES.STUDENT,
    email: 'yusufemir.koc@stu.fsm.edu.tr',
    password: DEMO_PASSWORD,
    department: 'Bilgisayar Mühendisliği',
    faculty: 'Mühendislik Fakültesi',
    year: '4. Sınıf',
    headline: 'Siber güvenlik · CTF oyuncusu',
    bio: 'Sızma testi, ağ güvenliği ve CTF yarışmaları ile ilgileniyorum. Kampüs altyapısı için savunma odaklı araçlar geliştiriyorum.',
    avatar: 'https://i.pravatar.cc/160?img=52',
    cover: 'https://picsum.photos/seed/fsm-cover-u9/1200/320',
    skills: ['Siber Güvenlik', 'Backend', 'DevOps'],
    interests: ['CTF', 'Sızma Testi', 'Ağ Güvenliği'],
    links: { github: 'https://github.com/yusufemirkoc', linkedin: 'https://www.linkedin.com/in/yusufemirkoc' },
  },
  {
    id: 'u10',
    name: 'Dr. Öğr. Üyesi Merve Karaca',
    role: ROLES.ACADEMIC,
    email: 'merve.karaca@fsm.edu.tr',
    password: DEMO_PASSWORD,
    department: 'Bilgisayar Mühendisliği',
    faculty: 'Mühendislik Fakültesi',
    year: 'Dr. Öğr. Üyesi',
    headline: 'Doğal dil işleme ve bilgi erişimi',
    bio: 'Türkçe doğal dil işleme, metin madenciliği ve büyük dil modelleri üzerine araştırmalar yürütüyorum. Lisans öğrencileriyle ortak yayın üretmeyi hedefliyorum.',
    avatar: 'https://i.pravatar.cc/160?img=32',
    cover: 'https://picsum.photos/seed/fsm-cover-u10/1200/320',
    skills: ['Yapay Zekâ', 'Veri Analizi', 'Backend'],
    interests: ['Doğal Dil İşleme', 'Bilgi Erişimi', 'Akademik Yayıncılık'],
    links: { github: 'https://github.com/mkaraca-nlp', linkedin: 'https://www.linkedin.com/in/mervekaraca' },
  },
];

/** Hızlı demo girişi için örnek hesaplar */
export const DEMO_ACCOUNTS = [
  { role: ROLES.STUDENT, email: 'elif.kaya@stu.fsm.edu.tr' },
  { role: ROLES.CLUB_REP, email: 'mehmetali.demir@stu.fsm.edu.tr' },
  { role: ROLES.ACADEMIC, email: 'zeynep.aydin@fsm.edu.tr' },
];

/* ------------------------------------------------------------------ */
/* Projeler / Akış gönderileri                                         */
/* ------------------------------------------------------------------ */
const img = (seed) => `https://picsum.photos/seed/${seed}/960/600`;

export const projects = [
  {
    id: 'p1',
    title: 'Akıllı Tarım için Otonom İHA ile Bitki Hastalığı Tespiti',
    summary:
      'Multispektral kamera taşıyan otonom İHA ile tarım arazilerinde bitki hastalıklarını erken aşamada tespit eden bir sistem geliştiriyoruz.',
    description:
      'TEKNOFEST kapsamında geliştirdiğimiz sistem; İHA üzerindeki kamera verisini gömülü bir bilgisayarda gerçek zamanlı işleyerek hastalıklı bitki bölgelerini haritalıyor. Çiftçiye sunulacak mobil arayüz ve rapor modülü için takım arkadaşları arıyoruz.',
    goal: 'Hastalık tespit doğruluğunu %92 üzerine çıkarmak ve sahada gerçek çiftçi verisiyle pilot test yapmak.',
    type: 'TEKNOFEST',
    status: PROJECT_STATUSES.RECRUITING,
    ownerId: 'u6',
    advisorId: 'u3',
    department: 'Elektrik-Elektronik Mühendisliği',
    image: img('fsm-project-uav'),
    accent: ['#1a2a44', '#2b6cb0'],
    tags: ['Yapay Zekâ', 'Görüntü İşleme', 'Gömülü Sistemler'],
    technologies: ['Python', 'PyTorch', 'OpenCV', 'Jetson Nano', 'ROS'],
    lookingFor: [
      { role: 'Yapay Zekâ Geliştiricisi', skills: ['Yapay Zekâ', 'Görüntü İşleme'], count: 1 },
      { role: 'Mobil Arayüz Geliştiricisi', skills: ['Mobil Yazılım', 'UI/UX Tasarım'], count: 1 },
    ],
    team: [
      { userId: 'u6', role: 'Takım Kaptanı · Gömülü Sistemler' },
      { userId: 'u9', role: 'Veri Güvenliği' },
    ],
    deliverables: ['Prototip İHA', 'Hastalık tespit modeli', 'Çiftçi raporlama paneli'],
    createdAt: hoursAgo(3),
    likes: 128,
    comments: [
      { id: 'c1', userId: 'u3', text: 'Model değerlendirmesinde saha verisini ayrı bir doğrulama kümesi olarak tutmanızı öneririm.', createdAt: hoursAgo(2) },
      { id: 'c2', userId: 'u1', text: 'Mobil tarafında katkı verebilirim, detayları konuşalım mı?', createdAt: hoursAgo(1) },
    ],
  },
  {
    id: 'p2',
    title: 'Kampüs Atık Yönetimi ve Geri Dönüşüm Mobil Uygulaması',
    summary:
      'Öğrencilerin geri dönüşüm noktalarını haritada bulduğu, atık miktarını takip ettiği ve ödül kazandığı bir mobil uygulama.',
    description:
      'Bitirme projesi olarak geliştirdiğimiz uygulama; QR kod ile atık kutusu doğrulama, kampüs haritası, bölümler arası geri dönüşüm liderlik tablosu ve ödül sistemi içeriyor. Backend API ve veri görselleştirme için destek arıyoruz.',
    goal: 'Dönem sonunda 500 aktif kullanıcıya ulaşan pilot sürüm yayınlamak.',
    type: 'Bitirme Projesi',
    status: PROJECT_STATUSES.RECRUITING,
    ownerId: 'u1',
    advisorId: 'u3',
    department: 'Bilgisayar Mühendisliği',
    image: img('fsm-project-recycle'),
    accent: ['#0f766e', '#2b6cb0'],
    tags: ['Mobil Yazılım', 'Backend', 'UI/UX Tasarım'],
    technologies: ['Flutter', 'Firebase', 'Node.js', 'PostgreSQL', 'Figma'],
    lookingFor: [
      { role: 'Backend Geliştirici', skills: ['Backend', 'DevOps'], count: 1 },
      { role: 'Veri Görselleştirme Uzmanı', skills: ['Veri Analizi'], count: 1 },
    ],
    team: [
      { userId: 'u1', role: 'Proje Sahibi · Mobil Geliştirici' },
      { userId: 'u5', role: 'UI/UX Tasarımcı' },
    ],
    deliverables: ['Mobil uygulama (iOS/Android)', 'Yönetici paneli', 'Bitirme raporu'],
    createdAt: hoursAgo(9),
    likes: 94,
    comments: [
      { id: 'c3', userId: 'u8', text: 'Arayüz akışını birlikte gözden geçirebiliriz, tasarım topluluğu olarak destek verelim.', createdAt: hoursAgo(6) },
    ],
  },
  {
    id: 'p3',
    title: 'Türkçe Akademik Metinler için Otomatik Özetleme ve Anahtar Kelime Çıkarımı',
    summary:
      'Türkçe makale ve tezler için ince ayarlanmış dil modelleriyle özetleme yapan, kongre bildirisi hazırlığına yönelik bir araştırma çalışması.',
    description:
      'Çalışma; veri seti oluşturma, model ince ayarı ve insan değerlendirmesi aşamalarından oluşuyor. Ulusal bir kongreye bildiri göndermeyi planlıyoruz. Veri etiketleme ve deney altyapısı için lisans öğrencileri arıyoruz.',
    goal: 'Dönem sonunda bir ulusal kongreye bildiri göndermek ve veri setini açık erişime sunmak.',
    type: 'Akademik/Kongre Çalışması',
    status: PROJECT_STATUSES.RECRUITING,
    ownerId: 'u10',
    advisorId: 'u10',
    department: 'Bilgisayar Mühendisliği',
    image: img('fsm-project-nlp'),
    accent: ['#1a2a44', '#4a8bd6'],
    tags: ['Yapay Zekâ', 'Veri Analizi', 'Backend'],
    technologies: ['Python', 'Hugging Face', 'Transformers', 'Pandas', 'LaTeX'],
    lookingFor: [
      { role: 'Veri Mühendisi', skills: ['Veri Analizi', 'Backend'], count: 2 },
      { role: 'Akademik Yazım Desteği', skills: ['Teknik Yazarlık'], count: 1 },
    ],
    team: [{ userId: 'u10', role: 'Araştırma Yürütücüsü' }],
    deliverables: ['Açık erişimli veri seti', 'Kongre bildirisi', 'Model kartı'],
    createdAt: hoursAgo(20),
    likes: 61,
    comments: [
      { id: 'c4', userId: 'u9', text: 'Veri toplama hattında yardımcı olabilirim.', createdAt: hoursAgo(14) },
    ],
  },
  {
    id: 'p4',
    title: 'StudyBuddy — Ders Çalışma Arkadaşı Eşleştirme Platformu',
    summary:
      'Aynı derse çalışan öğrencileri program ve çalışma stillerine göre eşleştiren, kampüs odaklı bir web girişimi.',
    description:
      'StudyBuddy, ders bazlı çalışma gruplarını otomatik oluşturur; ortak takvim, kaynak paylaşımı ve görev takibi sunar. Girişim olarak büyütmeyi ve üniversite kuluçka merkezine başvurmayı hedefliyoruz.',
    goal: 'MVP’yi bu dönem yayınlamak ve kuluçka merkezi ön başvurusunu tamamlamak.',
    type: 'Bağımsız Girişim',
    status: PROJECT_STATUSES.RECRUITING,
    ownerId: 'u2',
    advisorId: null,
    department: 'Bilgisayar Mühendisliği',
    image: img('fsm-project-studybuddy'),
    accent: ['#2b6cb0', '#1a2a44'],
    tags: ['Frontend', 'Backend', 'UI/UX Tasarım'],
    technologies: ['React', 'Node.js', 'MongoDB', 'Tailwind', 'Docker'],
    lookingFor: [
      { role: 'Frontend Geliştirici', skills: ['Frontend'], count: 1 },
      { role: 'Ürün Tasarımcısı', skills: ['UI/UX Tasarım', 'Grafik Tasarım'], count: 1 },
    ],
    team: [
      { userId: 'u2', role: 'Kurucu · Full-stack' },
      { userId: 'u4', role: 'Frontend Geliştirici' },
    ],
    deliverables: ['Web uygulaması MVP', 'Pitch deck', 'Kullanıcı araştırma raporu'],
    createdAt: hoursAgo(30),
    likes: 142,
    comments: [
      { id: 'c5', userId: 'u5', text: 'Marka kimliği ve arayüz tarafında ilgileniyorum, mesaj atıyorum.', createdAt: hoursAgo(27) },
      { id: 'c6', userId: 'u7', text: 'Eşleştirme algoritması için optimizasyon açısından katkı sunabilirim.', createdAt: hoursAgo(20) },
    ],
  },
  {
    id: 'p5',
    title: 'Kampüs Ağı için Otomatik Zafiyet Tarama ve Raporlama Aracı',
    summary:
      'Kampüs içi web servislerini düzenli tarayıp risk skoruyla raporlayan, savunma odaklı bir siber güvenlik aracı.',
    description:
      'Araç; açık port ve servis keşfi, bilinen zafiyet eşleştirme ve yönetici paneli bileşenlerinden oluşuyor. TEKNOFEST Siber Güvenlik kategorisine başvuru hazırlığındayız. Panel arayüzü ve raporlama için ekip arkadaşı arıyoruz.',
    goal: 'TEKNOFEST ön eleme raporunu teslim etmek ve çalışan bir demo sunmak.',
    type: 'TEKNOFEST',
    status: PROJECT_STATUSES.RECRUITING,
    ownerId: 'u9',
    advisorId: 'u10',
    department: 'Bilgisayar Mühendisliği',
    image: img('fsm-project-cyber'),
    accent: ['#13203a', '#2b6cb0'],
    tags: ['Siber Güvenlik', 'Backend', 'Frontend'],
    technologies: ['Go', 'Python', 'Nmap', 'React', 'Docker'],
    lookingFor: [
      { role: 'Frontend Geliştirici', skills: ['Frontend', 'UI/UX Tasarım'], count: 1 },
      { role: 'Teknik Yazar', skills: ['Teknik Yazarlık'], count: 1 },
    ],
    team: [{ userId: 'u9', role: 'Takım Kaptanı · Güvenlik' }],
    deliverables: ['Tarama motoru', 'Yönetici paneli', 'TEKNOFEST ön eleme raporu'],
    createdAt: hoursAgo(44),
    likes: 87,
    comments: [],
  },
  {
    id: 'p6',
    title: 'FSMVÜ Kurumsal Kimlik ve Marka Rehberi — Dijital Platform',
    summary:
      'Üniversite birimleri için marka kılavuzu, logo kullanım kuralları ve hazır şablonları tek yerde sunan etkileşimli bir tasarım sistemi.',
    description:
      'Bitirme projem kapsamında tasarım token’ları, bileşen kütüphanesi ve şablon galerisi içeren bir dijital rehber hazırlıyorum. Bu rehberi canlı bir web sitesine dönüştürecek bir frontend geliştiriciye ihtiyacım var.',
    goal: 'Tasarım sistemini canlıya almak ve kampüs birimlerinde kullanıma açmak.',
    type: 'Bitirme Projesi',
    status: PROJECT_STATUSES.RECRUITING,
    ownerId: 'u5',
    advisorId: 'u8',
    department: 'Grafik Tasarımı',
    image: img('fsm-project-brand'),
    accent: ['#1a2a44', '#4a8bd6'],
    tags: ['UI/UX Tasarım', 'Frontend', 'Grafik Tasarım'],
    technologies: ['Figma', 'Storybook', 'React', 'CSS Variables'],
    lookingFor: [{ role: 'Frontend Geliştirici', skills: ['Frontend'], count: 1 }],
    team: [{ userId: 'u5', role: 'Proje Sahibi · Tasarımcı' }],
    deliverables: ['Tasarım sistemi (Figma)', 'Bileşen kütüphanesi', 'Marka rehberi sitesi'],
    createdAt: hoursAgo(52),
    likes: 73,
    comments: [
      { id: 'c7', userId: 'u4', text: 'Bileşen kütüphanesini React ile kurmaya hazırım.', createdAt: hoursAgo(48) },
    ],
  },
  {
    id: 'p7',
    title: 'Lojistik Optimizasyonu için Etkileşimli Veri Analitiği Panosu',
    summary:
      'Rota ve stok verilerini görselleştiren, senaryo analizi yapabilen akademik bir karar destek paneli.',
    description:
      'Çalışma, bir lojistik firmasından alınan anonimleştirilmiş veriyle rota optimizasyonu sonuçlarını karşılaştırıyor. Sonuçlar bir uluslararası kongre bildirisine dönüştürülecek. Veri görselleştirme ve istatistik bilgisi olan öğrenciler aranıyor.',
    goal: 'Karar destek panelini tamamlamak ve kongre bildirisini hazırlamak.',
    type: 'Akademik/Kongre Çalışması',
    status: PROJECT_STATUSES.ONGOING,
    ownerId: 'u7',
    advisorId: 'u7',
    department: 'Endüstri Mühendisliği',
    image: img('fsm-project-logistics'),
    accent: ['#2b6cb0', '#13203a'],
    tags: ['Veri Analizi', 'Frontend'],
    technologies: ['Python', 'Plotly', 'SQL', 'Streamlit'],
    lookingFor: [{ role: 'Veri Görselleştirme Asistanı', skills: ['Veri Analizi', 'Frontend'], count: 1 }],
    team: [
      { userId: 'u7', role: 'Araştırma Yürütücüsü' },
      { userId: 'u6', role: 'Veri Mühendisi' },
    ],
    deliverables: ['Karar destek panosu', 'Kongre bildirisi'],
    createdAt: hoursAgo(70),
    likes: 38,
    comments: [],
  },
  {
    id: 'p8',
    title: 'Kampüs Etkinlik Takip ve Bilet Uygulaması',
    summary:
      'Kulüp etkinliklerini tek yerde toplayan, QR bilet ve yoklama sunan, kulüp temsilcileri için tasarlanmış bir uygulama.',
    description:
      'Tasarım Topluluğu olarak etkinlik duyurularını ve katılım yönetimini dijitalleştiriyoruz. Prototip hazır; geliştirme için mobil ve backend becerisi olan arkadaşlar arıyoruz.',
    goal: 'Dönem içinde en az 10 kulübün kullandığı bir pilot sürüm yayınlamak.',
    type: 'Bağımsız Girişim',
    status: PROJECT_STATUSES.RECRUITING,
    ownerId: 'u8',
    advisorId: null,
    department: 'Grafik Tasarımı',
    image: img('fsm-project-events'),
    accent: ['#2b6cb0', '#4a8bd6'],
    tags: ['Mobil Yazılım', 'UI/UX Tasarım', 'Backend'],
    technologies: ['React Native', 'Firebase', 'Figma'],
    lookingFor: [
      { role: 'Mobil Geliştirici', skills: ['Mobil Yazılım'], count: 1 },
      { role: 'Backend Geliştirici', skills: ['Backend'], count: 1 },
    ],
    team: [{ userId: 'u8', role: 'Proje Sahibi · Ürün Tasarımı' }],
    deliverables: ['Mobil uygulama', 'Kulüp yönetim paneli'],
    createdAt: hoursAgo(96),
    likes: 66,
    comments: [
      { id: 'c8', userId: 'u1', text: 'React Native tecrübem var, prototipi inceleyebilir miyim?', createdAt: hoursAgo(90) },
    ],
  },
  {
    id: 'p9',
    title: 'IoT Tabanlı Akıllı Sınıf Enerji İzleme Sistemi',
    summary:
      'Sınıflardaki aydınlatma ve iklimlendirme tüketimini sensörlerle izleyip tasarruf önerileri üreten bir sistem.',
    description:
      'Bitirme projesi kapsamında geliştirilen sistem; ESP32 tabanlı sensör düğümleri, MQTT altyapısı ve web tabanlı bir izleme panosundan oluşuyor. Veri analizi ve pano geliştirme için destek arıyoruz.',
    goal: 'Üç sınıfta pilot kurulum yapmak ve tüketim verisini bir dönem boyunca toplamak.',
    type: 'Bitirme Projesi',
    status: PROJECT_STATUSES.ONGOING,
    ownerId: 'u6',
    advisorId: 'u7',
    department: 'Elektrik-Elektronik Mühendisliği',
    image: img('fsm-project-iot'),
    accent: ['#0f766e', '#1a2a44'],
    tags: ['Gömülü Sistemler', 'Backend', 'Veri Analizi'],
    technologies: ['ESP32', 'MQTT', 'InfluxDB', 'Grafana', 'C++'],
    lookingFor: [{ role: 'Veri Analisti', skills: ['Veri Analizi'], count: 1 }],
    team: [
      { userId: 'u6', role: 'Proje Sahibi · Donanım' },
      { userId: 'u9', role: 'Ağ ve Güvenlik' },
    ],
    deliverables: ['Sensör düğümleri', 'İzleme panosu', 'Tasarruf analiz raporu'],
    createdAt: hoursAgo(120),
    likes: 52,
    comments: [],
  },
  {
    id: 'p10',
    title: 'Uyarlanabilir Öğrenme Asistanı — Eğitim Teknolojileri Yarışması',
    summary:
      'Öğrencinin hata örüntülerine göre soru ve açıklama üreten, kişiselleştirilmiş bir öğrenme asistanı.',
    description:
      'TEKNOFEST Eğitim Teknolojileri kategorisine hazırladığımız asistan, öğrenci cevaplarından bilgi eksiklerini çıkarıyor ve kısa tekrar modülleri öneriyor. Ön yüz geliştirme ve kullanıcı testi için takım arkadaşları arıyoruz.',
    goal: 'Yarışma finalinde canlı demo sunmak ve en az 100 öğrenciyle pilot yapmak.',
    type: 'TEKNOFEST',
    status: PROJECT_STATUSES.RECRUITING,
    ownerId: 'u3',
    advisorId: 'u3',
    department: 'Bilgisayar Mühendisliği',
    image: img('fsm-project-edtech'),
    accent: ['#1a2a44', '#2b6cb0'],
    tags: ['Yapay Zekâ', 'Frontend', 'UI/UX Tasarım'],
    technologies: ['React', 'FastAPI', 'scikit-learn', 'PostgreSQL'],
    lookingFor: [
      { role: 'Frontend Geliştirici', skills: ['Frontend'], count: 1 },
      { role: 'Kullanıcı Araştırmacısı', skills: ['UI/UX Tasarım'], count: 1 },
    ],
    team: [
      { userId: 'u3', role: 'Danışman' },
      { userId: 'u4', role: 'Frontend Geliştirici' },
    ],
    deliverables: ['Öğrenme asistanı prototipi', 'Pilot sonuç raporu', 'Yarışma sunumu'],
    createdAt: hoursAgo(150),
    likes: 109,
    comments: [
      { id: 'c9', userId: 'u2', text: 'Frontend için topluluktan birkaç arkadaşı yönlendirebilirim.', createdAt: hoursAgo(140) },
    ],
  },
  {
    id: 'p11',
    title: 'Siber Tehdit İstihbaratı için Grafik Tabanlı Analiz Çerçevesi',
    summary:
      'Tehdit göstergelerini grafik veri yapısıyla ilişkilendirerek saldırı kampanyalarını görselleştiren bir araştırma çalışması.',
    description:
      'Açık kaynak tehdit istihbaratı akışlarını graf veritabanında birleştiriyor ve anomali tespiti için grafik algoritmaları deniyoruz. Sonuçları bir akademik kongreye sunmayı planlıyoruz.',
    goal: 'Deneysel sonuçları tamamlayıp bildiri taslağını hazırlamak.',
    type: 'Akademik/Kongre Çalışması',
    status: PROJECT_STATUSES.RECRUITING,
    ownerId: 'u10',
    advisorId: 'u10',
    department: 'Bilgisayar Mühendisliği',
    image: img('fsm-project-threat'),
    accent: ['#13203a', '#4a8bd6'],
    tags: ['Siber Güvenlik', 'Veri Analizi', 'Yapay Zekâ'],
    technologies: ['Neo4j', 'Python', 'NetworkX', 'STIX/TAXII'],
    lookingFor: [{ role: 'Graf Analizi Araştırma Asistanı', skills: ['Veri Analizi', 'Siber Güvenlik'], count: 2 }],
    team: [
      { userId: 'u10', role: 'Araştırma Yürütücüsü' },
      { userId: 'u9', role: 'Araştırma Asistanı' },
    ],
    deliverables: ['Analiz çerçevesi', 'Kongre bildirisi'],
    createdAt: hoursAgo(200),
    likes: 44,
    comments: [],
  },
  {
    id: 'p12',
    title: 'Oyunlaştırılmış Dil Öğrenme Uygulaması “Kelimelik”',
    summary:
      'Günlük mini görevler, seri takibi ve arkadaşlarla yarışma modlarıyla İngilizce kelime öğrenmeyi eğlenceli hâle getiren bir uygulama.',
    description:
      'Kelimelik, aralıklı tekrar algoritması ve oyunlaştırma öğeleriyle çalışıyor. İlk sürüm tamamlandı; şimdi içerik üretimi ve ses/telaffuz özellikleri için yeni takım arkadaşları arıyoruz.',
    goal: 'İlk 1.000 indirmeye ulaşmak ve geri bildirimle ikinci sürümü planlamak.',
    type: 'Bağımsız Girişim',
    status: PROJECT_STATUSES.ONGOING,
    ownerId: 'u4',
    advisorId: null,
    department: 'Bilgisayar Programcılığı',
    image: img('fsm-project-language'),
    accent: ['#2b6cb0', '#1a2a44'],
    tags: ['Mobil Yazılım', 'UI/UX Tasarım', 'Frontend'],
    technologies: ['React Native', 'Expo', 'Supabase', 'Lottie'],
    lookingFor: [{ role: 'Ses/Telaffuz Modülü Geliştiricisi', skills: ['Yapay Zekâ', 'Mobil Yazılım'], count: 1 }],
    team: [
      { userId: 'u4', role: 'Kurucu · Geliştirici' },
      { userId: 'u5', role: 'Tasarımcı' },
    ],
    deliverables: ['Mobil uygulama v2', 'İçerik havuzu', 'Büyüme planı'],
    createdAt: hoursAgo(260),
    likes: 81,
    comments: [
      { id: 'c10', userId: 'u8', text: 'Etkinlik tanıtımı için topluluk kanallarımızı kullanabiliriz.', createdAt: hoursAgo(250) },
    ],
  },
];

/* ------------------------------------------------------------------ */
/* Sorgu yardımcıları                                                  */
/* ------------------------------------------------------------------ */
export const getUserById = (id) => users.find((u) => u.id === id) || null;
export const getProjectById = (id) => projects.find((p) => p.id === id) || null;
