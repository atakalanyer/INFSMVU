/**
 * FSMVÜ Proje Ağı (INFSMVU) — API İstemcisi
 * Express.js API rotaları (/api/...) ile tam entegre haberleşmeyi sağlar.
 */

const API_BASE = '/api';

export function getAuthHeader() {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function apiRequest(endpoint, options = {}) {
  const isFormData = options.body instanceof FormData;
  const headers = {
    ...getAuthHeader(),
    ...(options.headers || {}),
  };

  // FormData durumunda Content-Type'ı tarayıcı otomatik belirlemelidir (boundary için)
  if (!isFormData && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  const contentType = res.headers.get('content-type') || '';
  const data = contentType.includes('application/json')
    ? await res.json().catch(() => ({}))
    : await res.text().catch(() => '');

  if (!res.ok) {
    const errorMsg =
      (typeof data === 'object' && (data.mesaj || data.error)) ||
      (typeof data === 'string' && data) ||
      `Hata: ${res.status} ${res.statusText}`;
    const err = new Error(errorMsg);
    err.status = res.status;
    err.data = data;
    throw err;
  }

  return data;
}

// Kimlik Doğrulama Servisleri
export const authApi = {
  login: (email, password) =>
    apiRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  register: (payload) =>
    apiRequest('/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  verify: (email, code) =>
    apiRequest('/auth/verify', {
      method: 'POST',
      body: JSON.stringify({ email, code }),
    }),

  verifyByToken: (token) => apiRequest(`/auth/verify/${token}`),

  resend: (email) =>
    apiRequest('/auth/resend', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),
};

// Projeler
export const projectsApi = {
  getAll: (params = {}) => {
    const query = new URLSearchParams();
    if (params.status) query.append('status', params.status);
    if (params.category) query.append('category', params.category);
    if (params.project_type) query.append('project_type', params.project_type);
    if (params.q) query.append('q', params.q);
    const qs = query.toString();
    return apiRequest(`/projects${qs ? `?${qs}` : ''}`);
  },

  getById: (id) => apiRequest(`/projects/${id}`),

  create: (projectData) =>
    apiRequest('/projects', {
      method: 'POST',
      body: JSON.stringify(projectData),
    }),

  update: (id, projectData) =>
    apiRequest(`/projects/${id}`, {
      method: 'PUT',
      body: JSON.stringify(projectData),
    }),

  delete: (id) =>
    apiRequest(`/projects/${id}`, {
      method: 'DELETE',
    }),

  apply: (projectId, message) =>
    apiRequest(`/projects/${projectId}/apply`, {
      method: 'POST',
      body: JSON.stringify({ message }),
    }),

  withdrawApplication: (projectId) =>
    apiRequest(`/projects/${projectId}/apply`, {
      method: 'DELETE',
    }),

  getApplications: (projectId) => apiRequest(`/projects/${projectId}/applications`),

  decideApplication: (appId, status) =>
    apiRequest(`/projects/applications/${appId}`, {
      method: 'PUT',
      body: JSON.stringify({ status }), // 'accepted' | 'rejected'
    }),

  removeMember: (projectId, userId) =>
    apiRequest(`/projects/${projectId}/members/${userId}`, {
      method: 'DELETE',
    }),

  getMatches: (projectId) => apiRequest(`/projects/${projectId}/matches`),
};

// Etkinlikler
export const eventsApi = {
  getAll: (params = {}) => {
    const query = new URLSearchParams();
    if (params.club_id) query.append('club_id', params.club_id);
    if (params.category) query.append('category', params.category);
    if (params.when) query.append('when', params.when);
    if (params.mine) query.append('mine', '1');
    if (params.q) query.append('q', params.q);
    const qs = query.toString();
    return apiRequest(`/events${qs ? `?${qs}` : ''}`);
  },

  getCategories: () => apiRequest('/events/categories'),

  getById: (id) => apiRequest(`/events/${id}`),

  // FormData içeren POST isteği (afiş için)
  create: (formData) =>
    apiRequest('/events', {
      method: 'POST',
      body: formData,
    }),

  // FormData içeren PUT isteği
  update: (id, formData) =>
    apiRequest(`/events/${id}`, {
      method: 'PUT',
      body: formData,
    }),

  delete: (id) =>
    apiRequest(`/events/${id}`, {
      method: 'DELETE',
    }),

  register: (eventId) =>
    apiRequest(`/events/${eventId}/register`, {
      method: 'POST',
    }),

  unregister: (eventId) =>
    apiRequest(`/events/${eventId}/register`, {
      method: 'DELETE',
    }),

  getAttendees: (eventId) => apiRequest(`/events/${eventId}/attendees`),
};

// Gönderiler & Yorumlar
export const postsApi = {
  getAll: (page = 1, limit = 20, type = null) => {
    const qs = new URLSearchParams({ page, limit });
    if (type) qs.append('type', type);
    return apiRequest(`/posts?${qs.toString()}`);
  },

  getById: (id) => apiRequest(`/posts/${id}`),

  create: (postData) =>
    apiRequest('/posts', {
      method: 'POST',
      body: JSON.stringify(postData),
    }),

  delete: (id) =>
    apiRequest(`/posts/${id}`, {
      method: 'DELETE',
    }),

  like: (postId) =>
    apiRequest(`/posts/${postId}/like`, {
      method: 'POST',
    }),

  unlike: (postId) =>
    apiRequest(`/posts/${postId}/like`, {
      method: 'DELETE',
    }),

  getComments: (postId) => apiRequest(`/posts/${postId}/comments`),

  addComment: (postId, content, parent_comment_id = null) =>
    apiRequest(`/posts/${postId}/comments`, {
      method: 'POST',
      body: JSON.stringify({ content, parent_comment_id }),
    }),

  deleteComment: (commentId) =>
    apiRequest(`/posts/comments/${commentId}`, {
      method: 'DELETE',
    }),
};

// Kullanıcı & Profil Servisleri
export const usersApi = {
  getMe: () => apiRequest('/users/me'),

  updateMe: (profileData) =>
    apiRequest('/users/me', {
      method: 'PUT',
      body: JSON.stringify(profileData),
    }),

  addSkill: (skill_id, level = 1) =>
    apiRequest('/users/me/skills', {
      method: 'POST',
      body: JSON.stringify({ skill_id, level }),
    }),

  removeSkill: (skillId) =>
    apiRequest(`/users/me/skills/${skillId}`, {
      method: 'DELETE',
    }),

  search: (q = '', skill_id = null) => {
    const qs = new URLSearchParams();
    if (q) qs.append('q', q);
    if (skill_id) qs.append('skill_id', skill_id);
    return apiRequest(`/users/search?${qs.toString()}`);
  },

  getById: (id) => apiRequest(`/users/${id}`),

  follow: (id) =>
    apiRequest(`/users/${id}/follow`, {
      method: 'POST',
    }),

  unfollow: (id) =>
    apiRequest(`/users/${id}/follow`, {
      method: 'DELETE',
    }),

  getFollowers: (id) => apiRequest(`/users/${id}/followers`),
  getFollowing: (id) => apiRequest(`/users/${id}/following`),
};

// Bildirimler
export const notificationsApi = {
  getAll: (unreadOnly = false) =>
    apiRequest(`/notifications${unreadOnly ? '?unread=1' : ''}`),

  getUnreadCount: () => apiRequest('/notifications/unread-count'),

  readAll: () =>
    apiRequest('/notifications/read-all', {
      method: 'PUT',
    }),

  readOne: (id) =>
    apiRequest(`/notifications/${id}/read`, {
      method: 'PUT',
    }),
};

// Kulüpler
export const clubsApi = {
  getAll: () => apiRequest('/clubs'),
  getById: (id) => apiRequest(`/clubs/${id}`),
  create: (clubData) =>
    apiRequest('/clubs', {
      method: 'POST',
      body: JSON.stringify(clubData),
    }),
  update: (id, clubData) =>
    apiRequest(`/clubs/${id}`, {
      method: 'PUT',
      body: JSON.stringify(clubData),
    }),
  join: (id) =>
    apiRequest(`/clubs/${id}/join`, {
      method: 'POST',
    }),
  leave: (id) =>
    apiRequest(`/clubs/${id}/leave`, {
      method: 'DELETE',
    }),
};

// Lookups (Departmanlar & Yetenekler)
export const lookupApi = {
  getDepartments: () => apiRequest('/lookup/departments'),
  getSkills: () => apiRequest('/lookup/skills'),
};
