# INFSMVU – FSMVÜ Proje Ağı & Kampüs Sosyal Platformu

Bu proje, **Fatih Sultan Mehmet Vakıf Üniversitesi (FSMVÜ)** öğrencileri, kulüpleri ve akademisyenleri için geliştirilmiş, gerçek Microsoft SQL Server veritabanı ve Gmail SMTP bildirim otomasyonu ile çalışan kapsamlı bir sosyal iş birliği platformudur.

---

## 🏛️ Mimari ve Teknolojiler

- **Frontend**: React 18, Vite, React Router v6, FSMVÜ kurumsal kimliğine özel CSS mimarisi
- **Backend**: Node.js, Express.js 5, JWT kimlik doğrulama, Multer afiş yükleme
- **Veritabanı**: Microsoft SQL Server (SSMS 21 uyumlu)
- **E-posta Otomasyonu**: Nodemailer + Gmail App Password ile gerçek zamanlı OTP ve etkinlik bildirimleri

---

## 🚀 Yerel Kurulum Adımları (Windows)

### 1. Veritabanını Hazırlama (Microsoft SQL Server / SSMS)
1. SQL Server Management Studio (SSMS) uygulamasını açın ve SQL Server sunucunuza bağlanın.
2. `schema_mssql.sql` dosyasını SSMS'te açıp **F5** ile çalıştırın. Bu işlem `FSMVU_CampusNet` veritabanını ve 19 ana tabloyu oluşturur.
3. Ardından `backend/scripts/migrate_v2.sql` dosyasını SSMS'te açıp **F5** ile çalıştırarak proje detay alanlarını ekleyin.

### 2. Backend Kurulumu ve Yapılandırması
Terminal 1'de:
```bash
cd backend
npm install
```

`backend/.env.example` dosyasını `backend/.env` olarak kopyalayın:
```bash
copy .env.example .env
```

`.env` dosyasını açıp kendi ortamınıza göre güncelleyin:
```env
PORT=3000
DB_SERVER=localhost
DB_NAME=FSMVU_CampusNet
DB_USER=sa
DB_PASSWORD=VeritabaniSifreniz
JWT_SECRET=super_secret_jwt_key_fsmvu_2026

# Gmail SMTP Ayarları (Google App Password)
SMTP_USER=ornek@gmail.com
SMTP_PASS=uygulama_sifresi
MAIL_FROM=ornek@gmail.com
ALLOW_DEV_EMAIL_CODE=true
```

Örnek verileri (kullanıcılar, kulüpler ve etkinlikler) yüklemek için:
```bash
node scripts/seed.js
```

Backend sunucusunu başlatın:
```bash
npm start
# veya geliştirme modunda:
npm run dev
```

### 3. Frontend Kurulumu ve Başlatma
Terminal 2'de:
```bash
cd frontend
npm install
npm run dev
```

Tarayıcınızda açın: **`http://localhost:5173`**

---

## 👤 Varsayılan Test Hesapları (Şifre: `Fsm12345`)

Giriş ekranında yer alan tek tıkla demo doldurma butonlarını kullanabilir veya aşağıdaki hesaplarla giriş yapabilirsiniz:

| Rol | E-posta | Yetkiler |
| :--- | :--- | :--- |
| **Öğrenci** | `elif.kaya@stu.fsm.edu.tr` | Proje oluşturma, başvuru, etkinliklere kayıt olma, profil düzenleme |
| **Kulüp Temsilcisi** | `mehmetali.demir@stu.fsm.edu.tr` | Kulüp adına etkinlik yayınlama, afiş yükleme, katılımcı listesini yönetme |
| **Akademisyen** | `zeynep.aydin@fsm.edu.tr` | Kulüp danışmanlığı, proje takımlarına rehberlik etme |
| **Yönetici (Admin)** | `admin@fsm.edu.tr` | Kulüp temsilcisi atama, tüm etkinlik ve kullanıcıları denetleme |

---

## 🔒 Güvenlik & Rol Denetimi

- **Öğrenciler doğrudan API üzerinden dahi etkinlik oluşturamaz** (`etkinlikYonetebilirMi` ara katmanı ile engellenir).
- **Yalnızca yöneticiler kulüp temsilcisi rolü verebilir** (`/api/admin/club-representatives`).
- **Kurumsal e-posta kısıtı**: Öğrenci ve mezunlar `@stu.fsm.edu.tr`, akademisyenler `@fsm.edu.tr` uzantısıyla kayıt olmak zorundadır.
